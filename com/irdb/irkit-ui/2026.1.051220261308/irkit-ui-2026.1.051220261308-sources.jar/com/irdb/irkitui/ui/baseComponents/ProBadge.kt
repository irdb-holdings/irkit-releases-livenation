package com.irdb.irkitui.ui.baseComponents

import android.content.res.Configuration
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.size
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.irdb.irkitui.theme.IRKitThemeAccessor
import com.irdb.irkitui.theme.IRKitUITheme

@Composable
fun ProBadge() {
    val colors = IRKitThemeAccessor.colors

    Icon(
        imageVector = Icons.Filled.CheckCircle,
        contentDescription = "Pro User",
        tint = colors.badgeBackground,
        modifier = Modifier.size(14.dp)
    )
}

@Preview(name = "Light Mode")
@Composable
private fun ProBadgePreviewLight() {
    IRKitUITheme {
        ProBadge()
    }
}

@Preview(
    name = "Dark Mode",
    uiMode = Configuration.UI_MODE_NIGHT_YES
)
@Composable
private fun ProBadgePreviewDark() {
    IRKitUITheme {
        ProBadge()
    }
}
