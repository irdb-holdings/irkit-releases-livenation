package com.irdb.irkit.dto

import com.google.gson.annotations.SerializedName

data class EnvironmentInformationDto(
    @SerializedName("environment")
    val environment: String,

    @SerializedName("urlToIREngine")
    val urlToIREngine: String,

    @SerializedName("APIKeyForIREngine")
    val apiKeyForIREngine: String,

    @SerializedName("expires")
    val expires: Long
)
