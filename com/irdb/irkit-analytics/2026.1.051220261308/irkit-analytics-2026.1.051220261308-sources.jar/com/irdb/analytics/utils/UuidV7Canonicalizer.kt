package com.irdb.analytics.utils

import java.util.Locale

/**
 * Canonicalizes UUIDv7 strings to lowercase RFC-4122 format.
 *
 * Accepted input formats:
 * - canonical dashed (any case): xxxxxxxx-xxxx-7xxx-[89ab]xxx-xxxxxxxxxxxx
 * - compact 32-hex (any case): xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
 *
 * Returns null when the input is not a UUIDv7 or has an invalid variant nibble.
 */
internal object UuidV7Canonicalizer {
    private val canonicalV7Regex = Regex(
        "^[0-9a-f]{8}-[0-9a-f]{4}-7[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$"
    )

    private val compactHexRegex = Regex("^[0-9a-f]{32}$")

    fun canonicalizeOrNull(raw: String?): String? {
        val trimmed = raw?.trim()?.lowercase(Locale.US) ?: return null
        if (trimmed.isEmpty()) return null

        if (canonicalV7Regex.matches(trimmed)) return trimmed

        val compact = trimmed.replace("-", "")
        if (!compactHexRegex.matches(compact)) return null
        if (compact[12] != '7') return null
        if (compact[16] !in charArrayOf('8', '9', 'a', 'b')) return null

        val dashed = buildString(36) {
            append(compact, 0, 8)
            append('-')
            append(compact, 8, 12)
            append('-')
            append(compact, 12, 16)
            append('-')
            append(compact, 16, 20)
            append('-')
            append(compact, 20, 32)
        }
        return if (canonicalV7Regex.matches(dashed)) dashed else null
    }
}
