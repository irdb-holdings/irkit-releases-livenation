/**
 * Image recognition and processing engine.
 * 
 * This package will contain:
 * - IREngine: Main recognition engine
 * - ImageProcessor: Image analysis and processing
 * - Recognition algorithms and models
 * - Camera integration utilities
 */
package com.irdb.irkit.engine