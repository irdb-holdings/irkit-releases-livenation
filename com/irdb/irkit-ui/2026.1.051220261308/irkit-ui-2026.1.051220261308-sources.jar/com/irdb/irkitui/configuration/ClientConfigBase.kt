package com.irdb.irkitui.configuration

import com.irdb.irkitui.theme.IRKitTheme
import com.irdb.irkitui.theme.IRKitThemePresets

/**
 * Abstract base class defining all required configuration fields for IRKit clients.
 * Each client (IRCODE, KSL, etc.) must provide implementations
 * with Dev, Staging, and Production variants.
 */
abstract class ClientConfigBase {

    abstract val clientName: String

    /**
     * Base URL for backend API calls (Firebase Cloud Functions).
     * Used for:
     * - Analytics: POST {backendUrl}/Statistics for event tracking
     * - IRKit: Various backend API endpoints
     * Example: "https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_43"
     */
    abstract val backendUrl: String

    /**
     * URL for the IREngine image recognition service.
     * Used for scanning/matching images against the IRCODE database.
     * Example: "https://dev.backend.irdb.com/v1"
     */
    abstract val irEngineUrl: String

    /**
     * API key for authenticating with the IREngine image recognition service.
     * Sent as the "APIKeyForIREngine" header on all IREngine API calls.
     * This is different from analyticsApiKey - they are separate services.
     */
    abstract val irkitSubscriptionKey: String

    /**
     * API key for authenticating with the Analytics/Statistics service.
     * Sent as the header specified by analyticsApiKeyHeaderName (default: "sdkapikey")
     * on all analytics event POST requests to {backendUrl}/Statistics.
     * This is different from irkitSubscriptionKey - they are separate services.
     */
    abstract val analyticsApiKey: String

    /**
     * HTTP header name used to send the analytics API key.
     * Default: "sdkapikey"
     */
    abstract val analyticsApiKeyHeaderName: String

    /**
     * Company name used to dynamically build the sessionSource analytics parameter.
     * sessionSource is built as "Android-{companyName}-{bucketName}"
     * e.g., companyName "ksl" with bucket "ksldemo" → "Android-ksl-ksldemo"
     */
    abstract val companyName: String

    /**
     * Analytics bucket/namespace for grouping events.
     * Included in every analytics event payload as "bucketName".
     * Used for organizing analytics data by client (e.g., "ksldemo", "ircode").
     */
    //TODO: this is not used anymore, remove it
    abstract val analyticsBucketName: String

    /**
     * Environment identifier (e.g., "development", "staging", "production").
     * Used for environment-specific behavior and logging.
     */
    abstract val environment: String

    /**
     * Encryption key for securing locally stored preferences/data.
     * Used by IRKit for encrypting sensitive cached data.
     */
    abstract val prefsEncryptionKey: String

    /**
     * Salt value used with prefsEncryptionKey for encryption.
     * Combined with the key to strengthen encryption security.
     */
    abstract val prefsEncryptionSalt: String

    // ============================================
    // Segmentation
    // ============================================

    /**
     * Master switch for the ONNX segmentation pipeline.
     * When enabled, camera frames are processed through the segmentation model
     * to produce intelligent bounding-box crops before uploading to IREngine.
     * When disabled, the existing center-crop is used.
     *
     * Self-tuning may auto-disable this at runtime on devices too slow for inference.
     * Default: true (enabled for all clients).
     */
    open val segmentationEnabled: Boolean
        get() = true

    /**
     * Whether to show the segmentation bounding box overlay on the camera preview.
     * Draws a yellow rectangle where the model detected an object.
     * Only meaningful when [segmentationEnabled] is true.
     * Default: false (hidden in production).
     */
    open val showSegmentationBoundingBox: Boolean
        get() = false

    // ============================================
    // UI Theming
    // ============================================

    /**
     * Theme configuration for IRKit-UI components.
     * Defines colors and typography for all UI elements.
     *
     * Defaults to [IRKitThemePresets.Dark] which matches the current iOS-style appearance.
     * Clients can override to use alternative themes:
     * - [IRKitThemePresets.Blue] - Blue accent variant
     * - [IRKitThemePresets.Light] - Light mode (placeholder)
     * - Custom theme by creating a new [IRKitTheme] instance
     *
     * Example:
     * ```kotlin
     * object MyClientConfig : ClientConfigBase() {
     *     override val theme get() = IRKitThemePresets.Blue
     * }
     * ```
     */
    open val theme: IRKitTheme
        get() = IRKitThemePresets.Dark

    /**
     * Controls where the close button appears on the expanded image detail view.
     * Default: [ExpandedCloseButtonPlacement.TopEnd] (top-right corner).
     */
    open val expandedCloseButtonPlacement: ExpandedCloseButtonPlacement
        get() = ExpandedCloseButtonPlacement.topRight

    open val skipNotifiationCards: Boolean = false
}
