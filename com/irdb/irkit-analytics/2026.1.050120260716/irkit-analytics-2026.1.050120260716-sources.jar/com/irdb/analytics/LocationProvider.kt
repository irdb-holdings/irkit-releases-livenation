package com.irdb.analytics

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Looper
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority

/**
 * Automatically detects and provides user location for analytics when permissions are available.
 *
 * Matches the iOS flow documented in `docs/address_ip.md` §2.7: subscribe to
 * [FusedLocationProviderClient.requestLocationUpdates] once at init time and
 * keep the freshest fix in memory in [lastLocation]. Each analytics event then
 * reads `lastLocation` as a cheap in-memory value at build time — no 5-minute
 * caches, no suspending hops, no stale-coordinate problem when the user walks
 * during a session.
 *
 * Client apps don't need to pass location data — the library handles it
 * automatically.
 *
 * ### When Google Play Services / fused location is unavailable (§A.1)
 *
 * `LocationServices.getFusedLocationProviderClient(context)` returns a client
 * object on devices without GMS (Amazon Fire, Huawei post-2019, Chinese-market
 * ROMs, GrapheneOS, etc.), but `requestLocationUpdates` throws. When that
 * happens we fail soft: log **once** with a distinctive tag, set
 * [fusedAvailable] to false so subsequent reads short-circuit, and surface the
 * reason via [locationUnavailableReason] so the Playground debug panel can
 * distinguish "no location" (coverage issue) from "fused broken" (device
 * issue). Expected field rate: <1% of installs.
 */
internal class LocationProvider(
    private val context: Context,
    private val logger: AnalyticsLogger
) {
    private val fusedLocationClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    // Freshest location fix delivered by the fused provider stream. Read
    // directly by AnalyticsClient.buildEventParameters at event build time,
    // so keep this hot — no caches, no suspending work.
    @Volatile private var lastLocation: Location? = null

    @Volatile private var fusedAvailable: Boolean = true

    // Populated when requestLocationUpdates throws on a non-GMS device.
    // Null on healthy devices. Exposed via [locationUnavailableReason] so
    // AnalyticsDebugInfo can surface it to QA.
    @Volatile private var unavailableReason: String? = null

    private val request: LocationRequest = LocationRequest.Builder(
        Priority.PRIORITY_BALANCED_POWER_ACCURACY,
        0L
    )
        .setMinUpdateDistanceMeters(0f)
        .setMinUpdateIntervalMillis(0L)
        .build()

    private val callback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.lastLocation?.let { fresh ->
                lastLocation = fresh
                logger.logDebug("📍 [Location] update: lat=${fresh.latitude}, lng=${fresh.longitude}")
            }
        }
    }

    private var updatesStarted: Boolean = false

    init {
        startUpdatesIfPermitted()
    }

    /**
     * Start location updates when permission is granted. Safe to call more
     * than once — the second call is a no-op while updates are already
     * running. Called from [init], and can be called again after a runtime
     * permission grant (currently there's no explicit hook for that; users
     * who grant mid-session pick up coordinates after the next app cold
     * start, matching current behavior).
     */
    private fun startUpdatesIfPermitted() {
        if (updatesStarted) return
        if (!hasLocationPermission()) {
            logger.logDebug("📍 [Location] No permission — skipping stream subscribe")
            return
        }

        try {
            @Suppress("MissingPermission")
            fusedLocationClient.requestLocationUpdates(
                request,
                callback,
                Looper.getMainLooper()
            )
            updatesStarted = true
            logger.logDebug("📍 [Location] Subscribed to fused location updates")

            // Seed lastLocation with a best-effort lastKnown read so the
            // very first event after cold start has a value even before
            // the stream has produced a callback. Non-blocking.
            try {
                @Suppress("MissingPermission")
                fusedLocationClient.lastLocation
                    .addOnSuccessListener { seed ->
                        if (seed != null && lastLocation == null) {
                            lastLocation = seed
                            logger.logDebug("📍 [Location] Seeded lastLocation from lastKnown: lat=${seed.latitude}, lng=${seed.longitude}")
                        }
                    }
            } catch (_: Exception) {
                // lastLocation seed is best-effort only
            }
        } catch (e: SecurityException) {
            handleUnavailable(e)
        } catch (e: Exception) {
            // Covers com.google.android.gms.common.api.ApiException and any
            // other runtime failure on non-GMS devices (Amazon Fire, Huawei,
            // de-googled ROMs). Using generic Exception avoids a hard compile
            // dependency on the GMS exception type here.
            handleUnavailable(e)
        }
    }

    private fun handleUnavailable(e: Throwable) {
        fusedAvailable = false
        updatesStarted = false
        val reason = e.message ?: e.javaClass.simpleName
        unavailableReason = reason
        logger.logDebug("📍 [Location] Fused location unavailable on this device — analytics events will omit locationLat/locationLng. Reason: $reason")
    }

    /**
     * Stop the location stream. Tie to a process-level shutdown hook when
     * analytics is being torn down. Analytics on iOS never stops location
     * updates, so the default expectation is "always on while the process
     * lives".
     */
    fun stopUpdates() {
        if (!updatesStarted) return
        try {
            fusedLocationClient.removeLocationUpdates(callback)
            logger.logDebug("📍 [Location] Stopped fused location updates")
        } catch (e: Exception) {
            logger.logDebug("📍 [Location] Error stopping updates: ${e.message}")
        }
        updatesStarted = false
    }

    /**
     * Check if location permissions are granted.
     */
    fun hasLocationPermission(): Boolean {
        val fineLocationGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        val coarseLocationGranted = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        return fineLocationGranted || coarseLocationGranted
    }

    /**
     * Cheap non-suspending accessor for the latest fused location fix.
     * Mirrors iOS reading `UserData.shared.currentLocation` at request-build
     * time. Returns null when permission is denied, fused is unavailable on
     * the device, or the stream hasn't produced a fix yet.
     */
    fun getCurrentLocation(): Location? {
        if (!hasLocationPermission()) return null
        return lastLocation
    }

    /**
     * Reason string captured when `requestLocationUpdates` threw — null on
     * healthy devices. Surface on the Playground debug panel so QA can tell
     * "no location" (coverage issue) from "fused broken" (device issue) at a
     * glance.
     */
    fun locationUnavailableReason(): String? = unavailableReason

    /**
     * Clear the last known location. Rarely useful outside of tests; the
     * continuous stream will overwrite it on the next callback anyway.
     */
    fun clearCache() {
        lastLocation = null
    }
}
