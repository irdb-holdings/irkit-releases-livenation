package com.irdb.analytics

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * LEGACY: Deduplication for view/compressed events.
 * 
 * NOTE: This class is now DEPRECATED in favor of ViewEventBuffer which handles
 * buffering AND deduplication together with the new pattern:
 * - Buffer events when card appears
 * - Send with duration when user takes action
 * 
 * This class is kept for backward compatibility with old trackViewEvent() calls
 * but new code should use bufferViewEvent() and sendBufferedViewEvent() instead.
 * 
 * Old Pattern (DEPRECATED):
 * Prevents repeated view/compressed submissions for the same imageID when the
 * same compressed view is shown consecutively (e.g. from recomposition or periodic callbacks).
 *
 * Rule: Only allow one view/compressed per imageId until a different imageId is viewed
 * or the view is cleared. Same imageId viewed again consecutively = skip.
 *
 * Examples:
 * - A → A → A (same image on screen, caller fires repeatedly) → sends 1 view/compressed
 * - A → B → A → sends 3 (each is different from previous)
 * - A → (dismiss) → A (same image recognized again later) → sends 2 (clear/reset between allows resend)
 */
@Deprecated("Use ViewEventBuffer instead for new buffered event pattern")
internal class ViewCompressedDeduplicator {
    private val mutex = Mutex()

    private var lastViewCompressedImageId: String? = null

    /**
     * @param imageId imageID for the compressed view
     * @return true if this view/compressed should be sent (first or different from last), false to skip
     */
    suspend fun shouldSubmitViewCompressed(imageId: String): Boolean = mutex.withLock {
        if (imageId == lastViewCompressedImageId) {
            false
        } else {
            lastViewCompressedImageId = imageId
            true
        }
    }

    suspend fun markViewCompressedSubmitted(imageId: String) {
        mutex.withLock {
            lastViewCompressedImageId = imageId
        }
    }

    /**
     * Clear state so the same imageId can emit view/compressed again (e.g. after user dismisses).
     */
    suspend fun clear() {
        mutex.withLock {
            lastViewCompressedImageId = null
        }
    }
}
