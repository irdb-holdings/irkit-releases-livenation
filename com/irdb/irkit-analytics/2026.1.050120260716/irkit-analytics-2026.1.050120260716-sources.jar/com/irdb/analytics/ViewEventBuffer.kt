package com.irdb.analytics

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Buffers view events (compressed/expanded) until user action triggers send.
 * 
 * New Pattern:
 * - When notification card appears → Buffer view event (don't send yet)
 * - When user takes action (expand, dismiss, click link, etc.) → Send buffered event WITH duration
 * - Only one event buffered at a time
 * - Deduplication: Skip buffering if same imageId already buffered (not yet sent)
 * 
 * Examples:
 * - Card appears (compressed) → Buffer → User expands → Send compressed with duration
 * - Card appears (compressed) → Buffer → User ignores → Send compressed with duration
 * - Card expanded → Buffer expanded → User clicks product link → Send expanded with duration
 */
internal class ViewEventBuffer(
    private val logger: AnalyticsLogger
) {
    
    /**
     * Represents a buffered view event waiting to be sent.
     *
     * @property viewType The type of view (compressed, expanded, full)
     * @property viewSource The source of the view (liveScan, snapshot, etc.)
     * @property imageId The imageID being viewed (for deduplication)
     * @property campaignId Optional campaign ID
     * @property campaignName Optional campaign name
     * @property userIDOwner Optional owner user ID (for matched content)
     * @property usernameOwner Optional owner username (for matched content)
     * @property imageUrlOfScan URL of image submitted by user to make the match (required after match)
     * @property startTimestamp When the view started (for duration calculation)
     * @property trackingId Optional tracking ID for ImageLifecycleTracker lookup
     * @property additionalParams Additional parameters to include in event
     */
    data class BufferedViewEvent(
        val viewType: ViewType,
        val viewSource: ViewSource,
        val imageId: String?,
        val campaignId: String?,
        val campaignName: String?,
        val userIDOwner: String?,
        val usernameOwner: String?,
        val imageUrlOfScan: String?,
        val startTimestamp: Long,
        val trackingId: String?,
        val additionalParams: Map<String, Any>
    )
    
    private val mutex = Mutex()
    
    // Currently buffered event (only one at a time)
    private var bufferedEvent: BufferedViewEvent? = null
    
    // Last sent imageId for deduplication tracking
    // Cleared when buffer is cleared (card dismissed)
    private var lastSentImageId: String? = null
    
    /**
     * Check if we should buffer a view event for the given imageId and viewType.
     * 
     * Deduplication Rules:
     * - If same imageId is already buffered (not sent yet), skip buffering
     * - If different imageId, allow buffering (send previous first)
     * - If same imageId was sent and then cleared, allow buffering again
     * 
     * @param imageId The imageID to check
     * @param viewType The view type (compressed, expanded, full)
     * @return true if should buffer, false if should skip (duplicate)
     */
    suspend fun shouldBuffer(imageId: String?, viewType: ViewType): Boolean = mutex.withLock {
        return@withLock shouldBufferInternal(imageId, viewType)
    }
    
    /**
     * Buffer a view event to be sent later when user takes action.
     * 
     * @param event The view event to buffer
     * @return true if buffered successfully, false if skipped (duplicate)
     */
    suspend fun bufferViewEvent(event: BufferedViewEvent): Boolean = mutex.withLock {
        // Check deduplication (must not re-lock inside mutex)
        if (!shouldBufferInternal(event.imageId, event.viewType)) {
            return@withLock false
        }
        
        // If there's already a buffered event, log warning (shouldn't happen in normal flow)
        bufferedEvent?.let { existing ->
            logger.logDebug("⚠️ [ViewBuffer] Replacing buffered event: ${existing.viewType.value} for imageId=${existing.imageId}")
        }
        
        // Buffer the new event
        bufferedEvent = event
        logger.logDebug("📊 [ViewBuffer] Buffered ${event.viewType.value} event for imageId=${event.imageId}, trackingId=${event.trackingId}")
        
        return@withLock true
    }

    private fun shouldBufferInternal(imageId: String?, viewType: ViewType): Boolean {
        if (imageId == null) {
            // No imageId - always allow buffering
            return true
        }

        val currentBuffered = bufferedEvent
        if (currentBuffered != null && currentBuffered.imageId == imageId && currentBuffered.viewType == viewType) {
            // Same imageId and viewType already buffered - skip
            logger.logDebug("📊 [ViewBuffer] Skipping duplicate buffer for imageId=$imageId, viewType=${viewType.value}")
            return false
        }

        // Different imageId or viewType - allow buffering
        return true
    }
    
    /**
     * Send the buffered view event with calculated duration and timeToDisplay.
     * 
     * @param getDuration Lambda to calculate duration from start timestamp
     * @param getTimeToDisplay Lambda to get timeToDisplay from ImageLifecycleTracker
     * @return The buffered event that was sent, or null if no event was buffered
     */
    suspend fun sendBufferedEvent(
        getDuration: (startTimestamp: Long) -> Long,
        getTimeToDisplay: (trackingId: String?) -> Long?
    ): BufferedViewEvent? = mutex.withLock {
        val event = bufferedEvent ?: run {
            logger.logDebug("📊 [ViewBuffer] No buffered event to send")
            return@withLock null
        }
        
        // Calculate duration
        val duration = getDuration(event.startTimestamp)
        
        // Get timeToDisplay from ImageLifecycleTracker
        val timeToDisplay = getTimeToDisplay(event.trackingId)
        
        logger.logDebug("📊 [ViewBuffer] Sending buffered ${event.viewType.value} event for imageId=${event.imageId}, duration=${duration}, timeToDisplay=${timeToDisplay}")
        
        // Update last sent imageId for deduplication tracking
        event.imageId?.let { lastSentImageId = it }
        
        // Clear buffer after retrieving event
        bufferedEvent = null
        
        return@withLock event
    }
    
    /**
     * Get the currently buffered event without removing it.
     * Used for inspection/debugging.
     */
    suspend fun getBufferedEvent(): BufferedViewEvent? = mutex.withLock {
        return@withLock bufferedEvent
    }
    
    /**
     * Clear the buffer without sending.
     * Called when card is dismissed or user navigates away.
     * Also clears deduplication tracking to allow same imageId again.
     */
    suspend fun clearBuffer() = mutex.withLock {
        bufferedEvent?.let { event ->
            logger.logDebug("📊 [ViewBuffer] Clearing buffer for ${event.viewType.value} event, imageId=${event.imageId}")
        }
        bufferedEvent = null
        lastSentImageId = null
    }
    
    /**
     * Check if there's a buffered event waiting to be sent.
     */
    suspend fun hasBufferedEvent(): Boolean = mutex.withLock {
        return@withLock bufferedEvent != null
    }
}
