package com.irdb.analytics

import android.app.Activity
import android.app.Application
import android.os.Bundle
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking

/**
 * Automatically tracks app lifecycle events (session start/stop).
 * Uses Application.ActivityLifecycleCallbacks to detect when app moves to foreground/background.
 * This avoids needing lifecycle-process dependency.
 */
internal class LifecycleTracker(
    private val analyticsClient: AnalyticsClient,
    private val config: AnalyticsConfig,
    private val logger: AnalyticsLogger,
    private val userPreferences: UserPreferences
) : Application.ActivityLifecycleCallbacks {
    
    private var sessionStartTime: Long = 0
    private var isFirstLaunch: Boolean = true
    private var activityCount: Int = 0
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    
    /**
     * Initialize lifecycle tracking
     */
    fun initialize(application: Application) {
        if (!config.autoTrackLifecycle) {
            logger.logDebug("Lifecycle tracking disabled")
            return
        }
        
        application.registerActivityLifecycleCallbacks(this)
        logger.logDebug("✅ Lifecycle tracking initialized")
    }
    
    /**
     * App moved to foreground (activity started)
     */
    override fun onActivityStarted(activity: Activity) {
        activityCount++
        if (activityCount == 1) {
            // First activity started - app moved to foreground
            sessionStartTime = System.currentTimeMillis()
            
            // CRITICAL: Capture isFirstLaunch value BEFORE launching coroutine
            // The coroutine runs asynchronously, so we need to preserve the value
            val shouldTrackSessionStart = isFirstLaunch
            
            logger.logDebug("🚀 App foregrounded (isFirstLaunch: $isFirstLaunch)")
            
            // Set to false AFTER capturing the value
            isFirstLaunch = false
            
            scope.launch {
                try {
                    logger.logDebug("🔄 [Lifecycle] Coroutine started, shouldTrackSessionStart=$shouldTrackSessionStart")
                    
                    // Resume all timers (in case they were paused)
                    analyticsClient.onAppForegrounded()
                    logger.logDebug("🔄 [Lifecycle] onAppForegrounded() completed")
                    
                    // Track session started event (only if first launch, otherwise it's a resume)
                    if (shouldTrackSessionStart) {
                        logger.logDebug("📊 [Lifecycle] Tracking SESSION_STARTED event...")
                        // Generate and persist a fresh sessionTrackingID before emitting
                        // sessionStarted so the event and subsequent events share one ID.
                        analyticsClient.onSessionStarted()
                        analyticsClient.trackSessionStartedStatusEvent()
                        logger.logDebug("📊 [Lifecycle] SESSION_STARTED event tracked")
                        logger.logDebug("📊 [Lifecycle] Session timer started")
                    } else {
                        logger.logDebug("📊 [Lifecycle] Skipping SESSION_STARTED (not first launch)")
                    }
                } catch (e: Exception) {
                    logger.logError("❌ [Lifecycle] Error in onActivityStarted coroutine", e)
                }
            }
        }
    }
    
    /**
     * App moved to background (all activities stopped)
     *
     * CRITICAL: Uses runBlocking to ensure ALL operations complete before this callback returns.
     * This guarantees that when Android's lifecycle callback returns:
     * 1. Session-ended event is persisted to SQLite cache
     * 2. All cached events are flushed to the server (with timeout)
     * 3. Pending session state is saved to SharedPreferences (for crash recovery)
     */
    override fun onActivityStopped(activity: Activity) {
        // DIAGNOSTIC: Always log at error level so it shows regardless of filters
        Log.e("LifecycleTracker", "🛑 onActivityStopped called, activityCount=$activityCount")

        activityCount--
        if (activityCount == 0) {
            // All activities stopped - app moved to background
            val sessionEndTime = System.currentTimeMillis()
            val sessionDuration = sessionEndTime - sessionStartTime

            Log.e("LifecycleTracker", "🛑 App backgrounding - starting sync operations")
            logger.logDebug("⏹️ [Lifecycle] Session stop started (duration: ${sessionDuration}ms)")

            // Use runBlocking with IO dispatcher to ensure ALL operations complete before callback returns
            // CRITICAL: Must use Dispatchers.IO to avoid deadlock - lifecycle callbacks run on Main thread,
            // and blocking Main while trying to use Main dispatcher would cause deadlock
            runBlocking(Dispatchers.IO) {
                try {
                    Log.e("LifecycleTracker", "🛑 Inside runBlocking - starting sync operations")
                    logger.logDebug("🔄 [Lifecycle] Session stop started (runBlocking)")

                    // 1. Pause all timers synchronously
                    analyticsClient.onAppBackgroundedSync()
                    logger.logDebug("🔄 [Lifecycle] Timers paused")

                    // 2. Get session data
                    val globalDuration = analyticsClient.getGlobalSessionDuration()
                    val currentSessionId = analyticsClient.getCurrentSessionTrackingId()
                    logger.logDebug("🔄 [Lifecycle] Session ID: $currentSessionId, Global duration: ${globalDuration}ms")

                    // 3. Save pending session SYNCHRONOUSLY (for crash recovery)
                    // Uses commit() which blocks until write completes
                    val saved = userPreferences.savePendingSessionEndSync(
                        sessionTrackingId = currentSessionId,
                        sessionEndTimestamp = sessionEndTime,
                        sessionStartTimestamp = sessionStartTime,
                        globalDuration = globalDuration
                    )
                    logger.logDebug("💾 [Lifecycle] Pending session saved (sync): $saved")

                    // 4. Track session-ended SYNCHRONOUSLY
                    // This persists the event to SQLite cache before returning
                    analyticsClient.trackSessionStoppedStatusEventSync(
                        durationMs = sessionDuration
                    )
                    logger.logDebug("📊 [Lifecycle] SESSION_STOPPED event tracked (sync)")

                    // 5. Flush ALL cached events with timeout
                    // 2 second timeout prevents indefinite blocking on network issues
                    val flushed = analyticsClient.flushSync(timeoutMs = 2000L)
                    logger.logDebug("🔄 [Lifecycle] Flush completed (sync): $flushed")

                    // 6. Clear pending session (events were sent successfully or are in cache)
                    // Even if flush times out, event is in SQLite and will be sent on next app launch
                    userPreferences.clearPendingSessionEnd()
                    logger.logDebug("🗑️ [Lifecycle] Pending session cleared")

                } catch (e: Exception) {
                    Log.e("LifecycleTracker", "🛑 Exception in runBlocking: ${e.message}", e)
                    logger.logError("❌ [Lifecycle] Error in onActivityStopped (runBlocking)", e)
                    // Even on error, the pending session was saved (step 3), so recovery is possible
                }
            }

            Log.e("LifecycleTracker", "🛑 runBlocking completed - session stop finished")
            logger.logDebug("⏹️ [Lifecycle] Session stop completed")
        }
    }
    
    // Unused callbacks
    override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
    override fun onActivityResumed(activity: Activity) {}
    
    /**
     * Activity paused - save session state as a fallback for force-kill scenarios.
     * This ensures we can recover session end even if onActivityStopped() is never called.
     *
     * CRITICAL: Uses runBlocking to ensure session state is saved before the callback returns.
     * This is a safety net - if app is force-killed while in foreground, we'll have session state saved.
     */
    override fun onActivityPaused(activity: Activity) {
        // Only save if we have an active session (activityCount > 0 means app is still in foreground)
        // This is a safety net - if app is force-killed while in foreground, we'll have session state saved
        if (activityCount > 0 && sessionStartTime > 0) {
            // Use runBlocking with IO dispatcher to ensure save completes before callback returns
            // CRITICAL: Must use Dispatchers.IO to avoid deadlock on Main thread
            runBlocking(Dispatchers.IO) {
                try {
                    val currentTime = System.currentTimeMillis()
                    val currentSessionId = analyticsClient.getCurrentSessionTrackingId()
                    val globalDuration = analyticsClient.getGlobalSessionDuration()

                    // Save session state SYNCHRONOUSLY (will be overwritten by onActivityStopped if it runs)
                    val saved = userPreferences.savePendingSessionEndSync(
                        sessionTrackingId = currentSessionId,
                        sessionEndTimestamp = currentTime,
                        sessionStartTimestamp = sessionStartTime,
                        globalDuration = globalDuration
                    )
                    logger.logDebug("💾 [Pause] Saved session state as fallback (sync): $saved")
                } catch (e: Exception) {
                    logger.logError("❌ [Pause] Error saving session state", e)
                }
            }
        }
    }
    
    override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
    override fun onActivityDestroyed(activity: Activity) {}
}
