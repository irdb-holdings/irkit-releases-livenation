package com.irdb.irkitui.internal

import android.content.Context

/**
 * Internal utility for detecting the official IRKit app.
 * This is NOT part of the public API and should not be used by clients.
 */
internal object AppDetection {
    private val OFFICIAL_PACKAGE_NAMES = setOf(
        "com.irdb.irkitdemo",      // Legacy package name
        "com.ircode.app",           // Production/default
        "com.irdb.ircode.dev",      // Dev flavor
        "com.irdb.ircode.staging"   // Staging flavor
    )
    
    /**
     * Returns true if running in the official IRKit app.
     * Internal use only - not exposed to library clients.
     */
    fun isOfficialApp(context: Context): Boolean {
        return context.packageName in OFFICIAL_PACKAGE_NAMES
    }
}
