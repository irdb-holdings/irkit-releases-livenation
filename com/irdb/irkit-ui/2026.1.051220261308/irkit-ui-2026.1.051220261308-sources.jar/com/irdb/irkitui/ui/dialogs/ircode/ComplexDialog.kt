@file:OptIn(ExperimentalMaterial3Api::class)

package com.irdb.irkitui.ui.dialogs.ircode

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex

@Composable
fun ComplexDialog(
    onDismiss: () -> Unit,
    topContent: @Composable () -> Unit,
    middleContent: @Composable () -> Unit,
    bottomContent: @Composable () -> Unit,
    topRoundedCorners: Boolean = false,
    showTopBar: Boolean = true,
    isDarkMode: Boolean = false,
    modifier: Modifier = Modifier
) {
    val configuration = LocalConfiguration.current
    val screenHeight = configuration.screenHeightDp.dp
    val density = LocalDensity.current

    // Track IME visibility
    val keyboardHeight = with(density) { WindowInsets.ime.getBottom(density).toDp() }
    val isKeyboardVisible = keyboardHeight > 0.dp

    // Bottom sheet position state
    var bottomSheetOffset by remember {
        mutableFloatStateOf(if (showTopBar) 0.6f else 0.5f)
    } // Start at appropriate position based on top bar visibility
    val minOffset = if (showTopBar) 0.3f else 0.1f // Can go much higher when no top bar
    val maxOffset = 0.85f // Can't go lower than 85% from top

    // Preserve and restore the sheet position around keyboard visibility changes
    var lastOffsetBeforeKeyboard by remember { mutableFloatStateOf(if (showTopBar) 0.6f else 0.5f) }
    LaunchedEffect(isKeyboardVisible) {
        if (isKeyboardVisible) {
            lastOffsetBeforeKeyboard = bottomSheetOffset
            bottomSheetOffset = minOffset
        } else {
            bottomSheetOffset = lastOffsetBeforeKeyboard.coerceIn(minOffset, maxOffset)
        }
    }

    // Animated offset for smooth transitions
    val animatedOffset by animateFloatAsState(
        targetValue = bottomSheetOffset,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "bottom_sheet_offset"
    )

    // Handle back button
    BackHandler {
        onDismiss()
    }

    // Use a full-screen overlay instead of Dialog to extend behind system bars
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 1f))
            .zIndex(1000f)
    ) {
        // Top Section (Inverted Bottom Sheet) - Only show if). Only show if showTopBar is true
        if (showTopBar) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(screenHeight * 0.25f)
                    .zIndex(3f)
                    .background(
                        if (isDarkMode) Color.Black else Color.White,
                        shape = if (topRoundedCorners) {
                            RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp)
                        } else {
                            RoundedCornerShape(0.dp)
                        }
                    )
                    .shadow(
                        elevation = 8.dp,
                        shape = if (topRoundedCorners) {
                            RoundedCornerShape(bottomStart = 16.dp, bottomEnd = 16.dp)
                        } else {
                            RoundedCornerShape(0.dp)
                        }
                    )
            ) {
                topContent()
            }
        }

        // Middle Section (Behind bottom sheet)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .zIndex(1f)
                .background(if (isDarkMode) Color.Black else Color.White)
        ) {
            middleContent()
        }

        // Bottom Section (Draggable Bottom Sheet)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight()
                .graphicsLayer {
                    translationY = (screenHeight * animatedOffset).toPx()
                }
                .zIndex(2f)
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight(),
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
                color = if (isDarkMode) Color.Black else Color.White,
                shadowElevation = 16.dp
            ) {
                // Nested scroll connection to allow dragging anywhere in content to move the sheet
                val screenHeightPx = with(density) { screenHeight.toPx() }
                val nestedScrollConnection = remember {
                    object : NestedScrollConnection {
                        override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                            val dy = available.y
                            return if (dy < 0 && bottomSheetOffset > minOffset) {
                                val deltaOffset = dy / screenHeightPx
                                bottomSheetOffset = (bottomSheetOffset + deltaOffset).coerceIn(minOffset, maxOffset)
                                Offset(0f, dy)
                            } else {
                                Offset.Zero
                            }
                        }

                        override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                            val dy = available.y
                            return if (dy > 0 && bottomSheetOffset < maxOffset) {
                                val deltaOffset = dy / screenHeightPx
                                bottomSheetOffset = (bottomSheetOffset + deltaOffset).coerceIn(minOffset, maxOffset)
                                Offset(0f, dy)
                            } else {
                                Offset.Zero
                            }
                        }
                    }
                }

                Column(modifier = Modifier
                    .nestedScroll(nestedScrollConnection)
                    .testTag("ComplexDialog_bottomSheetContent")) {
                    // Drag Handle
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                            .testTag("ComplexDialog_bottomSheetDragHandle")
                            .pointerInput(Unit) {
                                detectDragGestures(
                                    onDragEnd = {
                                        // Snap to nearest position if needed
                                        if (bottomSheetOffset < minOffset) {
                                            bottomSheetOffset = minOffset
                                        } else if (bottomSheetOffset > maxOffset) {
                                            bottomSheetOffset = maxOffset
                                        }
                                    }
                                ) { _, dragAmount ->
                                    val screenHeightPx = (screenHeight).toPx()
                                    val deltaOffset = dragAmount.y / screenHeightPx
                                    val newOffset = (bottomSheetOffset + deltaOffset).coerceIn(minOffset, maxOffset)
                                    bottomSheetOffset = newOffset
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .width(40.dp)
                                .height(4.dp)
                                .background(
                                    if (isDarkMode) Color.White.copy(alpha = 0.3f) else Color.Gray.copy(alpha = 0.3f),
                                    RoundedCornerShape(2.dp)
                                )
                        )
                    }

                    // Bottom Content with keyboard padding
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(screenHeight * (1f - animatedOffset))
                            // We manage the sheet position when the IME opens.
                            // Apply only a tiny visual gap instead of the full ime padding here.
                    ) {
                        // Apply a 5.dp gap when keyboard is visible
                        Box(modifier = Modifier.padding(bottom = if (isKeyboardVisible) 5.dp else 0.dp)) {
                            bottomContent()
                        }
                    }
                }
            }
        }
    }
}
