package com.irdb.irkitui

/**
 * Public build and environment information for the IRKit libraries.
 *
 * Access via [IRKitUI.getBuildInfo]. This is available regardless of initialization state
 * since the values are baked into the library at build time.
 */
data class IRKitBuildInfo(
    /** Environment the library was built for (e.g., "development", "staging", "production") */
    val environment: String,
    /** Library version (e.g., "2026.1") */
    val libraryVersion: String,
    /** Company name this build is configured for (e.g., "ksl", "irdb") */
    val companyName: String,
    /** Backend URL the library points to */
    val backendUrl: String,
    /** IR Engine URL the library points to */
    val irEngineUrl: String,
    /** Client name from configuration (e.g., "KSL", "IRCODE") */
    val clientName: String = ""
)
