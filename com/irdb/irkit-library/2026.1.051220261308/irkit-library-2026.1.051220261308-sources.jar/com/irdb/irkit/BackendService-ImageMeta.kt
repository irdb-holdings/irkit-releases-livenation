package com.irdb.irkit

import android.util.Log
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.irdb.irkit.dto.EditableImageDto
import com.irdb.irkit.response.ImageMetaResponse
import com.irdb.irkit.utils.ErrorCodeTranslator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

suspend fun BackendService.ImageMeta(
        imageId: String,
        userid: Int,
        editableImage: EditableImageDto,
        localTest: Boolean = false
): Boolean =
        withContext(Dispatchers.IO) {
            val endpoint = "/ImageMeta"
            //
            // https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_43/ImageMeta

            val requestBody = editableImage.toImageMetaRequest()

            // If local test is enabled, just print the JSON and return success
            if (localTest) {
                val gson = Gson()
                val prettyJson = gson.toJson(requestBody)
                Log.d("LOCAL_TEST", "=== ImageMeta Request Body (Local Test Mode) ===")
                Log.d("LOCAL_TEST", "Endpoint: $endpoint")
                Log.d("LOCAL_TEST", "Image ID: $imageId")
                Log.d("LOCAL_TEST", "User ID: $userid")
                Log.d("LOCAL_TEST", "Request Body:")
                Log.d("LOCAL_TEST", prettyJson)
                Log.d("LOCAL_TEST", "=== End Local Test ===")
                return@withContext true
            }

            // Use a more flexible approach to handle both object and string responses
            val request =
                    request<BaseResponse<Any>>(
                            endpoint = endpoint,
                            method = HttpMethod.POST,
                            bodyParameters = requestBody,
                            headerParameters = mapOf("associated-user-id" to userid.toString()),
                            responseType = object : TypeToken<BaseResponse<Any>>() {}.type
                    )

            if (!request.succeeded || request.payload == null) {
                Log.e("BackendServiceError", request.errorMessage.toString())
                throw BackendServiceError.ServerError(request.errorMessage)
            }

            val response = requireNotNull(request.payload) { "Payload should not be null after null check" }

            // Check if the server returned an error message in the response
            if (!response.completed && response.errorMessage.isNotEmpty()) {
                val message = ErrorCodeTranslator.translate(response.errorMessage)

                Log.e("BackendServiceError", "Server returned error: ${message}")
                throw BackendServiceError.ServerError(message)
            }

            // Handle the Results field which could be either a string error or an object
            when (val results = response.results) {
                is String -> {
                    // Server returned an error message in the Results field
                    Log.e("BackendServiceError", "Server returned error in Results field: $results")
                    throw BackendServiceError.ServerError(results)
                }
                is Map<*, *> -> {
                    // Try to parse as ImageMetaResponse and return immediately on success
                    val gson = Gson()
                    val jsonElement = gson.toJsonTree(results)
                    val imageMetaResponse =
                            gson.fromJson(jsonElement, ImageMetaResponse::class.java)
                    return@withContext imageMetaResponse.finished
                }
                else -> {
                    Log.e(
                            "BackendServiceError",
                            "Unexpected Results type: ${results?.javaClass?.simpleName}"
                    )
                    throw BackendServiceError.ServerError("Invalid response format from server")
                }
            }
        }
