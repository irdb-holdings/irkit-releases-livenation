package com.irdb.irkit.utils

import android.content.Context
import com.irdb.irkit.R


/**
 * Translates error codes to human-readable messages. Designed to support localization by reading
 * from string resources.
 */
object ErrorCodeTranslator {

    /**
     * Translates an error code to a human-readable message.
     *
     * @param errorCode The error code to translate (e.g., "notValidOwner1")
     * @param context The context to access string resources for localization
     * @return The translated error message, or the original error code if no translation is found
     */

    fun translate(errorCode: String, context: Context): String {
        return when (errorCode) {
            "notValidOwner1" -> context.getString(R.string.error_not_valid_owner)
            "invalidImageFormat" -> context.getString(R.string.error_invalid_image_format)
            "imageTooLarge" -> context.getString(R.string.error_image_too_large)
            "uploadFailed" -> context.getString(R.string.error_upload_failed)
            "networkError" -> context.getString(R.string.error_network_error)
            "serverError" -> context.getString(R.string.error_server_error)
            "authenticationFailed" -> context.getString(R.string.error_authentication_failed)
            "permissionDenied" -> context.getString(R.string.error_permission_denied)
            "resourceNotFound" -> context.getString(R.string.error_resource_not_found)
            "rateLimitExceeded" -> context.getString(R.string.error_rate_limit_exceeded)
            "invalidRequest" -> context.getString(R.string.error_invalid_request)
            "timeoutError" -> context.getString(R.string.error_timeout)
            "quotaExceeded" -> context.getString(R.string.error_quota_exceeded)
            "maintenanceMode" -> context.getString(R.string.error_maintenance_mode)
            "versionDeprecated" -> context.getString(R.string.error_version_deprecated)
            "failedToLoadNoti" -> context.getString(R.string.error_failed_to_load_notifications)
            "ER_PARSE_ERROR" -> context.getString(R.string.error_parse_error)
            else -> errorCode // Return original code if no translation found
        }
    }

    /**
     * Translates an error code to a human-readable message without context. Uses hardcoded English
     * strings as fallback when context is not available.
     *
     * @param errorCode The error code to translate
     * @return The translated error message, or the original error code if no translation is found
     */
    fun translate(errorCode: String): String {
        return when (errorCode) {
            "notValidOwner1" -> "You are not the valid owner of this content"
            "invalidImageFormat" -> "Invalid image format"
            "imageTooLarge" -> "Image is too large"
            "uploadFailed" -> "Upload failed"
            "networkError" -> "Network error occurred"
            "serverError" -> "Server error occurred"
            "authenticationFailed" -> "Authentication failed"
            "permissionDenied" -> "Permission denied"
            "resourceNotFound" -> "Resource not found"
            "rateLimitExceeded" -> "Rate limit exceeded"
            "invalidRequest" -> "Invalid request"
            "timeoutError" -> "Request timed out"
            "quotaExceeded" -> "Quota exceeded"
            "maintenanceMode" -> "System is under maintenance"
            "versionDeprecated" -> "App version is deprecated"
            "failedToLoadNoti" -> "Failed to load notifications"
            "ER_PARSE_ERROR" -> "Error parsing server response"
            else -> errorCode // Return original code if no translation found
        }
    }

    /**
     * Checks if an error code has a translation available.
     *
     * @param errorCode The error code to check
     * @return true if a translation exists, false otherwise
     */
    fun hasTranslation(errorCode: String): Boolean {
        return when (errorCode) {
            "notValidOwner1",
            "invalidImageFormat",
            "imageTooLarge",
            "uploadFailed",
            "networkError",
            "serverError",
            "authenticationFailed",
            "permissionDenied",
            "resourceNotFound",
            "rateLimitExceeded",
            "invalidRequest",
            "timeoutError",
            "quotaExceeded",
            "maintenanceMode",
            "versionDeprecated",
            "failedToLoadNoti",
            "ER_PARSE_ERROR" -> true
            else -> false
        }
    }

    /**
     * Gets all supported error codes.
     *
     * @return List of all error codes that have translations
     */
    fun getSupportedErrorCodes(): List<String> {
        return listOf(
                "notValidOwner1",
                "invalidImageFormat",
                "imageTooLarge",
                "uploadFailed",
                "networkError",
                "serverError",
                "authenticationFailed",
                "permissionDenied",
                "resourceNotFound",
                "rateLimitExceeded",
                "invalidRequest",
                "timeoutError",
                "quotaExceeded",
                "maintenanceMode",
                "versionDeprecated",
                "failedToLoadNoti",
                "ER_PARSE_ERROR"
        )
    }
}
