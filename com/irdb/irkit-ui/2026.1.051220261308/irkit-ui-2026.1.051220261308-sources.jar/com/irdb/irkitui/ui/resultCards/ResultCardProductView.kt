package com.irdb.irkitui.ui.resultCards

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.irdb.analytics.ViewSource
import com.irdb.irkit.IRKit
import com.irdb.irkit.ImageModel
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.dto.ProductInCampaignDto
import com.irdb.irkit.dto.UserDto
import com.irdb.irkit.enums.ImageStatus
import com.irdb.irkitui.CameraMode
import com.irdb.irkitui.trackLinkClick
import com.irdb.irkitui.ui.components.CollapsedContent
import com.irdb.irkitui.ui.components.ContentMetaLinksView
import com.irdb.irkitui.ui.components.ProductItemView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun ResultCardProductView(
    image: ImageModel,
    products: List<ProductInCampaignDto>,
    onBuyProductTapped: (ProductInCampaignDto) -> Unit,
    onClick: (MetaContent.Link) -> Unit,
    modifier: Modifier = Modifier,
    useLazyColumn: Boolean = true,
    onlyShowProducts: Boolean = false,
    viewSource: ViewSource? = null,
    viewType: String? = "expanded",
    cameraMode: CameraMode? = null
) {
    var otherProducts by remember { mutableStateOf<List<ProductInCampaignDto>>(emptyList()) }
    var isLoadingOtherProducts by remember { mutableStateOf(false) }

    LaunchedEffect(image.campaignId) {
        if (otherProducts.isEmpty() && image.campaignId > 0) {
            isLoadingOtherProducts = true
            try {
                withContext(Dispatchers.IO) { // Move network call to IO dispatcher
                    val productsDto = IRKit.getInstance().getProducts(image.campaignId)

                    // Move back to main thread for UI updates
                    withContext(Dispatchers.Main) {
                        // Filter out existing products
                        otherProducts = productsDto.filter { newProduct ->
                            !products.any { existingProduct ->
                                newProduct.title == existingProduct.title &&
                                    newProduct.imageUrl == existingProduct.imageUrl
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                // Handle error
            } finally {
                isLoadingOtherProducts = false
            }
        }
    }

    Column(
        modifier = modifier.fillMaxWidth()
    ) {
        if (!onlyShowProducts) {
            // Sticky header
            CollapsedContent(image = image, isExpanded = true)
            HorizontalDivider(
                modifier = Modifier.padding(vertical = 4.dp, horizontal = 8.dp),
                color = Color.Gray.copy(alpha = 0.3f)
            )
        }

        // Content - either LazyColumn or regular Column based on useLazyColumn parameter
        if (useLazyColumn) {
            LazyColumn(
                contentPadding = PaddingValues(4.dp),
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                item {
                    image.getLinks()?.let {
                        Row(
                            horizontalArrangement = Arrangement.Start,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            ContentMetaLinksView(
                                image = image,
                                onClick = { link ->
                                    // Track analytics before calling the callback
                                    trackLinkClick(
                                        link = link,
                                        image = image,
                                        viewSource = viewSource,
                                        viewType = viewType,
                                        cameraMode = cameraMode
                                    )
                                    // Call the original callback
                                    onClick(link)
                                },
                                resourceProvider = null  // Simplified for now - will use default icons
                            )
                        }
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(10.dp))
                }

                items(products) { product ->
                    ProductItemView(
                        product = product,
                        onBuyTapped = { clickedProduct ->
                            onBuyProductTapped(clickedProduct)
                        }
                    )
                }

                if (isLoadingOtherProducts) {
                    item {
                        CircularProgressIndicator(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                                .wrapContentWidth(Alignment.CenterHorizontally),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                } else if (otherProducts.isNotEmpty()) {
                    item {
                        HorizontalDivider(
                            modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 8.dp),
                            color = Color.Gray.copy(alpha = 0.3f)
                        )
                        Text(
                            text = "You might be also interested in",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.padding(vertical = 5.dp, horizontal = 5.dp)
                        )
                    }

                    items(otherProducts) { product ->
                        ProductItemView(
                            product = product,
                            onBuyTapped = { clickedProduct ->
                                onBuyProductTapped(clickedProduct)
                            }
                        )
                    }
                }
            }
        } else {
            // Use regular Column when inside another scrollable container
            Column(
                modifier = Modifier.padding(4.dp)
            ) {
                if (!onlyShowProducts) {
                    image.getLinks()?.let {
                        Row(
                            horizontalArrangement = Arrangement.Start,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            ContentMetaLinksView(
                                image = image,
                                onClick = { link ->
                                    // Track analytics before calling the callback
                                    trackLinkClick(
                                        link = link,
                                        image = image,
                                        viewSource = viewSource,
                                        viewType = viewType,
                                        cameraMode = cameraMode
                                    )
                                    // Call the original callback
                                    onClick(link)
                                },
                                resourceProvider = null  // Simplified for now - will use default icons
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                products.forEach { product ->
                    ProductItemView(
                        product = product,
                        onBuyTapped = { clickedProduct ->
                            onBuyProductTapped(clickedProduct)
                        }
                    )
                }

                if (isLoadingOtherProducts) {
                    CircularProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                            .wrapContentWidth(Alignment.CenterHorizontally),
                        color = MaterialTheme.colorScheme.primary
                    )
                } else if (otherProducts.isNotEmpty()) {
                    HorizontalDivider(
                        modifier = Modifier.padding(start = 4.dp, end = 4.dp, top = 8.dp),
                        color = Color.Gray.copy(alpha = 0.3f)
                    )
                    Text(
                        text = "You might be also interested in",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.padding(vertical = 5.dp, horizontal = 5.dp)
                    )

                    otherProducts.forEach { product ->
                        ProductItemView(
                            product = product,
                            onBuyTapped = { clickedProduct ->
                                onBuyProductTapped(clickedProduct)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
private fun ResultCardProductViewPreview() {
    val mockProducts = listOf(
        ProductInCampaignDto(
            id = "",
            title = "Sample Product 1",
            imageUrl = "https://example.com/image.jpg",
            linkToFollow = "https://example.com"
        ),
        ProductInCampaignDto(
            id = "",
            title = "Sample Product 2",
            imageUrl = "https://example.com/image.jpg",
            linkToFollow = "https://example.com"
        ),
        ProductInCampaignDto(
            id = "",
            title = "Sample Product 3",
            imageUrl = "https://example.com/image.jpg",
            linkToFollow = "https://example.com"
        )
    )

    val previewImage = ImageModel.FullImage(
        title = "Mock Recognition Result",
        description = "Mock description that is long enough to show multiple lines of text and demonstrate the ellipsis behavior",
        imageId = "",
        displayImageUrl = "https://upload.wikimedia.org/wikipedia/en/f/f7/Inside_Out_2_poster.jpg",
        campaignId = 1,
        campaignName = "1",
        products = emptyList(),
        metaItems = emptyList(),
        location = null,
        imageSize = 0,
        imageHeight = 0,
        imageWidth = 0,
        bucketName = "",
        trackingId = "",
        imageUser = UserDto(
            email = "",
            phone = "",
            userId = 2,
            fullName = "",
            userName = "",
            profileUrl = ""
        ),
        isFromManualCapture = false,
        imageStatus = ImageStatus.PUBLISH
    )

    ResultCardProductView(
        image = previewImage,
        products = mockProducts,
        onBuyProductTapped = { },
        onClick = { },
        modifier = Modifier
    )
}
