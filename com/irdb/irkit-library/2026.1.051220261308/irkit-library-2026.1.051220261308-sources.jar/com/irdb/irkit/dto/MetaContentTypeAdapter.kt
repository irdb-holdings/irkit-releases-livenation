package com.irdb.irkit.dto

import com.google.gson.JsonDeserializationContext
import com.google.gson.JsonDeserializer
import com.google.gson.JsonElement
import java.lang.reflect.Type

class MetaContentTypeAdapter : JsonDeserializer<MetaContent> {
    override fun deserialize(
        json: JsonElement,
        typeOfT: Type,
        context: JsonDeserializationContext
    ): MetaContent {
        val jsonObject = json.asJsonObject

        return when {
            jsonObject.has("cardType") -> MetaContent.CardType(
                jsonObject.get("cardType").asString
            )
            jsonObject.has("title") -> MetaContent.Title(
                jsonObject.get("title").asString
            )
            jsonObject.has("description") -> MetaContent.Description(
                jsonObject.get("description").asString
            )
            jsonObject.has("links") -> {
                val links = jsonObject.getAsJsonArray("links")
                if (links.size() > 0) {
                    val firstLink = links[0].asJsonObject
                    MetaContent.Link(
                        url = firstLink.get("url")?.asString ?: "",
                        title = firstLink.get("title")?.asString ?: "",
                        privateDetails = firstLink.get("privateDetails")?.asBoolean ?: false,
                        icon = firstLink.get("icon")?.asString ?: "",
                        onScanDisplay = firstLink.get("onScanDisplay")?.asBoolean ?: false,
                        openInNewWindow = firstLink.get("openInNewWindow")?.asBoolean ?: false
                    )
                } else {
                    MetaContent.Custom(emptyMap())
                }
            }
            jsonObject.has("embeddedVideo") -> MetaContent.EmbeddedVideo(
                jsonObject.get("embeddedVideo").asString
            )
            jsonObject.has("tags") -> MetaContent.Tags(
                jsonObject.getAsJsonArray("tags").map { it.asString }
            )
            else -> MetaContent.Custom(
                jsonObject.entrySet().associate {
                    it.key to it.value.asString
                }
            )
        }
    }
}
