package com.irdb.irkit

import android.util.Log
import com.google.gson.reflect.TypeToken
import com.irdb.irkit.UserService.TAG
import com.irdb.irkit.dto.UserDataDTO
import com.irdb.irkit.dto.UpgradeToCreatorRequest
import com.irdb.irkit.dto.UpdateUserVerificationRequest
import com.irdb.irkit.dto.UpgradeError
import com.irdb.irkit.response.UserResponse

/**
 * Upgrade current user to Creator account
 * Backend validates that email and phone are verified before upgrading
 *
 * @return UserDataDTO with updated userType = "Pro"
 * @throws BackendServiceError.ServerError if upgrade fails
 */
suspend fun UserService.upgradeToCreator(): UserDataDTO {
    val endpoint = "/User"

    if (BackendService.isDebugMode()) {
        Log.d(TAG, "-- IRCode::upgradeToCreator --")
        Log.d(TAG, "Upgrading user to Creator account")
    }

    val requestBody = UpgradeToCreatorRequest()

    val response =
        BackendService.request<BaseResponse<UserResponse>>(
            endpoint = endpoint,
            method = HttpMethod.PUT,
            bodyParameters = requestBody,
            responseType = object : TypeToken<BaseResponse<UserResponse>>() {}.type
        )

    if (!response.succeeded || response.payload == null) {
        Log.e(TAG, "Failed to upgrade to creator: ${response.errorMessage}")
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    val userResponse = payload.results

    val userData = try {
        // Access user property - this will throw NPE if user is null (deserialized as null by Gson)
        val user = userResponse.user
        // Verify user is not null by accessing a property
        user.userType // This will throw NPE if user was deserialized as null
        user
    } catch (e: NullPointerException) {
        Log.e(TAG, "Failed to upgrade to creator: User data is null in response", e)
        throw BackendServiceError.ServerError("User data not found in response")
    }

    if (BackendService.isDebugMode()) {
        Log.d(TAG, "Successfully upgraded to creator: userType=${userData.userType}")
    }

    val userDataDto = UserDataDTO.fromUserResponse(userData)

    // Verify upgrade was successful
    if (userDataDto.userType != "Pro") {
        Log.w(TAG, "Upgrade API succeeded but userType is not 'Pro': ${userDataDto.userType}")
    }

    return userDataDto
}

/**
 * Update user data with email/phone verification status
 * This is called after Firebase verification is complete
 *
 * @param phone Phone number in E.164 format (e.g., +12392108166)
 * @param email Email address
 * @param emailVerified Whether email is verified
 * @param phoneVerified Whether phone is verified
 * @return UserDataDTO with updated verification status
 * @throws BackendServiceError.ServerError if update fails
 */
suspend fun UserService.updateUserVerification(
    phone: String? = null,
    email: String? = null,
    emailVerified: Boolean? = null,
    phoneVerified: Boolean? = null
): UserDataDTO {
    val endpoint = "/User"

    if (BackendService.isDebugMode()) {
        Log.d(TAG, "-- IRCode::updateUserVerification --")
        Log.d(TAG, "phone=$phone, email=$email, emailVerified=$emailVerified, phoneVerified=$phoneVerified")
    }

    val requestBody = UpdateUserVerificationRequest(
        phone = phone,
        email = email,
        emailVerified = emailVerified,
        phoneVerified = phoneVerified
    )

    val response =
        BackendService.request<BaseResponse<UserResponse>>(
            endpoint = endpoint,
            method = HttpMethod.PUT,
            bodyParameters = requestBody,
            responseType = object : TypeToken<BaseResponse<UserResponse>>() {}.type
        )

    if (!response.succeeded || response.payload == null) {
        Log.e(TAG, "Failed to update user verification: ${response.errorMessage}")
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    val userResponse = payload.results

    val userData = try {
        // Access user property - this will throw NPE if user is null (deserialized as null by Gson)
        val user = userResponse.user
        // Verify user is not null by accessing a property
        user.userType // This will throw NPE if user was deserialized as null
        user
    } catch (e: NullPointerException) {
        Log.e(TAG, "Failed to update user verification: User data is null in response", e)
        throw BackendServiceError.ServerError("User data not found in response")
    }

    val userDataDto = UserDataDTO.fromUserResponse(userData)

    if (BackendService.isDebugMode()) {
        Log.d(TAG, "User verification updated: emailVerified=${userDataDto.emailVerified}, phoneVerified=${userDataDto.phoneVerified}")
    }

    return userDataDto
}

/**
 * Parse error code from backend response to UpgradeError
 * Used for error handling during upgrade flow
 */
fun UserService.parseUpgradeError(errorString: String?): UpgradeError {
    return when (errorString?.lowercase()) {
        "emailnotverified" -> UpgradeError.EmailNotVerified
        "phonenotverified" -> UpgradeError.PhoneNotVerified
        "phoneverified" -> UpgradeError.PhoneNotVerified
        "notsignedin" -> UpgradeError.NotSignedIn
        "invalidphone" -> UpgradeError.InvalidPhone
        else -> UpgradeError.UnknownError(errorString ?: "Unknown error")
    }
}
