package com.irdb.irkitui.ui.baseComponents

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import coil.ImageLoader
import coil.disk.DiskCache
import coil.memory.MemoryCache

/**
 * Composable function to get a configured ImageLoader.
 *
 * Tries to use the app's ImageLoaderEntryPoint if available (via Hilt),
 * otherwise falls back to creating a default ImageLoader with sensible defaults.
 *
 * The ImageLoader is remembered across recompositions for performance.
 */
@Composable
fun rememberImageLoader(): ImageLoader {
    val context = LocalContext.current
    return remember(context) {
        getOrCreateImageLoader(context)
    }
}

/**
 * Gets the ImageLoader from the app's entry point or creates a default one.
 */
private fun getOrCreateImageLoader(context: Context): ImageLoader {
    // Try to get ImageLoader from Hilt entry point if app provides one
    try {
        val entryPoint = getImageLoaderEntryPoint(context)
        if (entryPoint != null) {
            return entryPoint.imageLoader()
        }
    } catch (e: Exception) {
        // Entry point not available, use default
    }

    // Fall back to default ImageLoader with caching
    return createDefaultImageLoader(context)
}

/**
 * Attempts to get the ImageLoaderEntryPoint from Hilt.
 * Returns null if Hilt is not available or entry point is not installed.
 */
private fun getImageLoaderEntryPoint(context: Context): ImageLoaderEntryPoint? {
    return try {
        // Try to use Hilt's EntryPointAccessors via reflection
        // This avoids a hard dependency on Hilt in the library
        val entryPointsClass = Class.forName("dagger.hilt.android.EntryPointAccessors")
        val fromApplicationMethod = entryPointsClass.getMethod(
            "fromApplication",
            Context::class.java,
            Class::class.java
        )
        entryPointsClass.cast(
            fromApplicationMethod.invoke(null, context.applicationContext, ImageLoaderEntryPoint::class.java)
        ) as? ImageLoaderEntryPoint
    } catch (e: Exception) {
        // Hilt not available or entry point not installed
        null
    }
}

/**
 * Creates a default ImageLoader with reasonable caching settings.
 */
private fun createDefaultImageLoader(context: Context): ImageLoader {
    return ImageLoader.Builder(context)
        .memoryCache {
            MemoryCache.Builder(context)
                .maxSizePercent(0.25) // Use 25% of app memory for image cache
                .build()
        }
        .diskCache {
            DiskCache.Builder()
                .directory(context.cacheDir.resolve("image_cache"))
                .maxSizePercent(0.02) // Use 2% of disk space
                .build()
        }
        .crossfade(true)
        .build()
}
