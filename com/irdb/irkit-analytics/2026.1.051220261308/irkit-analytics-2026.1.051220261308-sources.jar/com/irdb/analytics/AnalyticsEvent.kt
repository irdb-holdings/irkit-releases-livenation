package com.irdb.analytics

/**
 * Event type definitions for analytics tracking.
 * These enums match the Analytics Doc requirements.
 */

/**
 * Type of scan event
 */
enum class ScanType(val value: String) {
    CREATOR("creator"),
    LIVE("live"),
    SNAPSHOT("snapshot"),
    CAPTURE_BUTTON("captureButton")
}

/**
 * Type of view event
 * 
 * View events now use buffered pattern:
 * - When notification card appears → Buffer view event (don't send yet)
 * - When user takes action (expand, dismiss, click link) → Send buffered event WITH duration and timeToDisplay
 * 
 * timeToDisplay field:
 * - Measures time from image recognition complete to notification card display
 * - Calculated as: NOTIFICATION_DISPLAYED timestamp - RECOGNITION_COMPLETE timestamp
 * - Included automatically in all view events when trackingId is provided
 * - Unit: milliseconds
 */
enum class ViewType(val value: String) {
    COMPRESSED("compressed"),
    EXPANDED("expanded"),
    FULL("full")
}

/**
 * Source of view event
 */
enum class ViewSource(val value: String) {
    UNDEFINED("undefined"),
    LIVE_SCAN("liveScan"),
    SNAPSHOT("snapshot"),
    CREATOR("creator"),
    SIMILAR("similar"),
    HISTORY("history"),
    SAVE("save"),
    MY_IRCODES("myIrcodes"),
    TRASH("trash"),
    PROFILE("profile"),
    LIST_VIEW("listView"),
    LIVE_SEARCH("liveSearch")   // Result view after tapping live search preview
}

/**
 * Type of button press event
 */
enum class ButtonType(val value: String) {
    PRODUCT("product"),
    LINK("link"),
    LINK_TO_SITE("linkToSite"),
    SHUTTER("shutter"),
    PROFILE("profile"),
    X("X"),
    SAVE("save"),
    SHARE("share"),
    FLASH_LIGHT("flashLight"),
    PHOTO_ALBUM("photoAlbum"),
    TAG("tag"),
    EXPANDED("expanded"),      // When user expands view
    LIVE("live"),               // Live scan button
    LIVE_RESULT("liveResult"),  // User taps live search preview result
    TAPPED("tapped"),           // v2.1 link event — user tapped match bar to open microsite
    AUTO_OPEN("autoOpen")       // v2.1 link event — scan-to-site auto-launched microsite
}

/**
 * Source of button press event
 */
enum class ButtonSource(val value: String) {
    UNDEFINED("undefined"),
    HOME_VIEW("homeView"),
    PROFILE_VIEW("profileView"),
    IRCODE_VIEW("IRCodeView")
}

/**
 * Type of status event
 */
enum class StatusType(val value: String) {
    SESSION_STARTED("sessionStarted"),
    SESSION_STOPPED("sessionStopped"),
    IMAGE_SAVED("imageSaved"),
    IMAGE_SHARED("imageShared"),
    IMAGE_REMOVED("imageRemoved"),
    IMAGE_FAVORITED("imageFavorited"),
    IMAGE_UNFAVORITED("imageUnfavorited"),
    USER_ACCOUNT_CREATED("userAccountCreated"),
    USER_PROFILE_VIEWED("userProfileViewed"),
    NEW_USER("newUser"),              // First run on device
    IRCODE_CREATED("IRCODECreated"),  // IR code created
    IRCODE_REMOVED("IRCODERemoved"),  // IR code removed
    TIME_TO_DISPLAY("timeToDisplay")  // Time from recognition to display
}

/**
 * Network type for device info
 */
enum class NetworkType(val value: String) {
    OFFLINE("offline"),
    WIFI("wifi"),
    CELLULAR_2G("cellular2g"),
    CELLULAR_3G("3g"),
    CELLULAR_4G("4g"),
    CELLULAR_5G("5g"),
    ETHERNET("ethernet"),
    UNKNOWN("unknown")
}

