package com.irdb.irkitui.components

import android.annotation.SuppressLint
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun ScanningEffect(
    isActive: Boolean,
    content: @Composable () -> Unit
) {
    val animationKey by rememberUpdatedState(isActive)

    val scanAnimationY by produceState(initialValue = 1f, key1 = animationKey) {
        if (isActive) {
            while (true) {
                // Move from bottom to top
                animate(
                    initialValue = 1f,
                    targetValue = 0f,
                    animationSpec = tween(
                        durationMillis = 2000,
                        easing = LinearEasing
                    )
                ) { newValue, _ ->
                    this.value = newValue
                }

                // Pause at the top
                delay(1500) // 1.5 second pause at the top

                // Instantly move back to bottom
                this.value = 1f

                // Small delay before starting next scan
                delay(500) // 0.5 second pause at the bottom
            }
        } else {
            this.value = 1f
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        content()
        if (isActive) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawGrid()
                drawScanningLine(scanAnimationY)
            }
        }
    }
}

@Composable
private fun animateScanningLine(): State<Float> {
    val infiniteTransition = rememberInfiniteTransition()
    return infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f, // Reduced to 2 phases for simpler timing
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 4000, // 1000ms up + 2000ms pause
                easing = LinearEasing
            ),
            repeatMode = RepeatMode.Restart
        )
    )
}

private fun DrawScope.drawGrid() {
    val gridSpacing = 20.dp.toPx()
    val gridColor = Color.White.copy(alpha = 0.25f)

    for (x in 0..size.width.toInt() step gridSpacing.toInt()) {
        drawLine(
            color = gridColor,
            start = Offset(x.toFloat(), 0f),
            end = Offset(x.toFloat(), size.height),
            strokeWidth = 1f
        )
    }

    for (y in 0..size.height.toInt() step gridSpacing.toInt()) {
        drawLine(
            color = gridColor,
            start = Offset(0f, y.toFloat()),
            end = Offset(size.width, y.toFloat()),
            strokeWidth = 1f
        )
    }
}

private fun DrawScope.drawScanningLine(progress: Float) {
    val scanLineHeight = 100.dp.toPx()

    // Progress now directly represents position from bottom (1f) to top (0f)
    val y = lerp(0f, size.height, progress)

    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color.Transparent,
                Color.White.copy(alpha = 0.8f),
                Color.Transparent
            ),
            startY = y - scanLineHeight / 2,
            endY = y + scanLineHeight / 2
        ),
        topLeft = Offset(0f, y - scanLineHeight / 2),
        size = size.copy(height = scanLineHeight),
        blendMode = BlendMode.Plus
    )
}

// Extension function to use the scanning effect
@SuppressLint("ModifierFactoryUnreferencedReceiver")
fun Modifier.scanningEffect(isActive: Boolean): Modifier = composed {
    val scanAnimationY by animateScanningLine()

    Modifier.drawWithContent {
        drawContent()
        if (isActive) {
            drawGrid()
            drawScanningLine(scanAnimationY)
        }
    }
}

// Helper function to linearly interpolate between two values
private fun lerp(start: Float, stop: Float, fraction: Float): Float {
    return start + fraction * (stop - start)
}
