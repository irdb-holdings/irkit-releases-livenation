package com.irdb.analytics

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Provider for fetching and caching the device's public IP address.
 *
 * Fetches from the `/myip` endpoint and caches in SharedPreferences (via
 * [UserPreferences]). Cache is invalidated on `onSessionStarted()` and on
 * network transport changes (see [NetworkMonitor] / `onTransportChanged`).
 *
 * ### iOS parity notes (docs/address_ip.md)
 *
 * - §3.1 rule 3: in-flight guard via [fetchInFlight] so concurrent callers
 *   never launch overlapping GETs.
 * - §3.1 rule 5: anonymous GET — no `sdkapikey` or custom headers on the
 *   `/myip` request.
 * - §3.1: JSON response parsing accepts `ip`, `IP`, or `address` keys.
 * - §3.5 (doc calls out iOS bug here): we add a 30 s negative-cache cooldown
 *   so a truly unreachable `/myip` doesn't cost ~2 minutes per event.
 *
 * We deliberately **keep** the SharedPreferences cache (diverges from iOS
 * memory-only) because it makes cold-start events stamp correctly if the
 * transport hasn't changed and the last run already resolved an IP.
 */
internal class IpAddressProvider(
    private val config: AnalyticsConfig,
    private val userPreferences: UserPreferences,
    private val logger: AnalyticsLogger
) {
    companion object {
        private const val MAX_RETRY_ATTEMPTS = 3
        private const val RETRY_DELAY_MS = 1000L // 1 second base delay, multiplied by attempt number
        private const val FAILURE_COOLDOWN_MS = 30_000L
    }

    // Derive once at init rather than calling substringBeforeLast on every
    // request. Also lets clients override via AnalyticsConfig.myIpUrl without
    // having to mangle apiEndpoint string shapes.
    private val myIpUrl: String = config.myIpUrl
        ?: run {
            val base = config.apiEndpoint.substringBeforeLast("/")
            "$base/myip"
        }

    // iOS §3.1 rule 3: prevent overlapping /myip GETs across concurrent
    // callers. First caller wins; concurrent callers get null this event and
    // pick up the cached value on the next one.
    private val fetchInFlight = AtomicBoolean(false)

    // Timestamp of the last failed 3-attempt cycle. 0 = no recent failure.
    // Short-circuits subsequent getIpAddress() calls for FAILURE_COOLDOWN_MS
    // so a prolonged /myip outage doesn't cost ~2 min per event.
    @Volatile private var lastFailureAt: Long = 0L

    /**
     * Timestamp of the last exhausted failure, for debug surfaces. 0 when
     * `/myip` is currently healthy. Resets on [clearCache] (session start,
     * network transport change).
     */
    fun getLastFailureAt(): Long = lastFailureAt

    /**
     * Purely in-memory read of the cached IP. No network, no coroutine
     * hops. Used by [AnalyticsRepository] to late-bind `locationIP` onto
     * events at send time — per the primary goal of
     * `docs/address_ip.md`: every event that gets sent after `/myip` has
     * ever resolved carries the field.
     */
    fun getCachedIpAddressSync(): String? = userPreferences.loadCachedIpAddress()

    /**
     * Get the cached IP address, or fetch from the server if not cached.
     *
     * @return The IP address string, or null if unavailable.
     */
    suspend fun getIpAddress(): String? = withContext(Dispatchers.IO) {
        // First, check if we have a cached IP address
        val cachedIp = userPreferences.loadCachedIpAddress()
        if (cachedIp != null) {
            logger.logDebug("🌐 [IP] Using cached IP address: $cachedIp")
            return@withContext cachedIp
        }

        // Negative-cache cooldown: if we just exhausted 3 attempts, skip the
        // network for FAILURE_COOLDOWN_MS. Sessions / transport changes call
        // clearCache() which also zeros lastFailureAt, so a new network
        // bypasses the cooldown immediately.
        val sinceFailure = System.currentTimeMillis() - lastFailureAt
        if (lastFailureAt != 0L && sinceFailure < FAILURE_COOLDOWN_MS) {
            logger.logDebug("🌐 [IP] In failure cooldown (${sinceFailure}ms since last fail), returning null")
            return@withContext null
        }

        // iOS §3.1 rule 3: only one in-flight fetch at a time.
        if (!fetchInFlight.compareAndSet(false, true)) {
            logger.logDebug("🌐 [IP] Fetch already in-flight, returning null for this caller")
            return@withContext null
        }

        try {
            logger.logDebug("🌐 [IP] No cached IP found, fetching from server...")

            for (attempt in 1..MAX_RETRY_ATTEMPTS) {
                val fetchedIp = fetchIpFromServer()
                if (fetchedIp != null) {
                    userPreferences.saveCachedIpAddress(fetchedIp)
                    lastFailureAt = 0L
                    logger.logDebug("🌐 [IP] Fetched and cached IP address: $fetchedIp (attempt $attempt)")
                    return@withContext fetchedIp
                }
                if (attempt < MAX_RETRY_ATTEMPTS) {
                    val delayMs = RETRY_DELAY_MS * attempt
                    logger.logDebug("🌐 [IP] Attempt $attempt failed, retrying in ${delayMs}ms...")
                    kotlinx.coroutines.delay(delayMs)
                }
            }

            // All retries failed - do NOT fall back to local/private IP
            // detection. Private IPs (10.x, 192.168.x) cause the backend to
            // derive garbage lat/long values. Start the cooldown instead.
            lastFailureAt = System.currentTimeMillis()
            logger.logDebug("🌐 [IP] All $MAX_RETRY_ATTEMPTS attempts failed, entering ${FAILURE_COOLDOWN_MS}ms cooldown")
            return@withContext null
        } finally {
            fetchInFlight.set(false)
        }
    }

    /**
     * Fetch IP address from the `/myip` endpoint. Anonymous GET — no
     * sdkapikey or custom headers (iOS §3.1 rule 5).
     *
     * @return The IP address string, or null if the request fails.
     */
    private suspend fun fetchIpFromServer(): String? = withContext(Dispatchers.IO) {
        var connection: HttpURLConnection? = null

        return@withContext try {
            logger.logDebug("🌐 [IP] Fetching IP from: $myIpUrl")

            val url = URL(myIpUrl)
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "GET"
            connection.doInput = true

            connection.setRequestProperty("Accept", "application/json")
            // iOS §3.1 rule 5: anonymous GET. Deliberately NOT setting
            // sdkapikey / customHeaders here.

            connection.connectTimeout = config.connectTimeout.inWholeMilliseconds.toInt()
            connection.readTimeout = config.readTimeout.inWholeMilliseconds.toInt()

            val responseCode = connection.responseCode

            if (responseCode in 200..299) {
                val responseBody = connection.inputStream?.let { inputStream ->
                    BufferedReader(InputStreamReader(inputStream, "UTF-8")).use { reader ->
                        reader.readText()
                    }
                } ?: ""

                connection.disconnect()
                connection = null

                val ipAddress = parseIpResponse(responseBody)

                if (ipAddress != null) {
                    logger.logDebug("🌐 [IP] Successfully fetched IP: $ipAddress")
                } else {
                    logger.logError("🌐 [IP] Failed to parse IP from response: $responseBody")
                }

                ipAddress
            } else {
                val errorBody = connection.errorStream?.let { errorStream ->
                    BufferedReader(InputStreamReader(errorStream, "UTF-8")).use { reader ->
                        reader.readText()
                    }
                } ?: ""

                connection.disconnect()
                connection = null

                logger.logError("🌐 [IP] HTTP error $responseCode when fetching IP: $errorBody")
                null
            }
        } catch (e: Exception) {
            connection?.disconnect()
            logger.logError("🌐 [IP] Exception when fetching IP from server: ${e.message}", e)
            null
        }
    }

    private fun parseIpResponse(responseBody: String): String? {
        return parseIpResponseRaw(responseBody) { logger.logError(it) }
    }

    /**
     * Clear the cached IP address AND reset the failure cooldown so that
     * the next `getIpAddress()` call on the new transport / session
     * bypasses the cooldown and re-fetches immediately.
     */
    fun clearCache() {
        userPreferences.clearCachedIpAddress()
        lastFailureAt = 0L
        logger.logDebug("🌐 [IP] Cleared cached IP address and failure cooldown")
    }
}

/**
 * Parse an `/myip` response body into an IP address string.
 *
 * Accepts both plain text (`99.96.118.62` or `2607:fb90:abcd:1234::5`)
 * and JSON wrappers using any of the keys `ip`, `IP`, or `address`
 * (iOS parity, `docs/address_ip.md` §3.1). Validates via
 * [InetAddress.getByName] so both IPv4 and IPv6 families are accepted.
 *
 * Pure function — decoupled from [AnalyticsLogger] so it can be covered by
 * JVM unit tests without Android runtime. The optional [onError] callback
 * lets callers hook their logging.
 */
internal fun parseIpResponseRaw(responseBody: String, onError: ((String) -> Unit)? = null): String? {
    val trimmed = responseBody.trim()
    if (trimmed.isEmpty()) return null

    // Extract candidate: JSON `{"ip":"..."}` / `{"IP":"..."}` /
    // `{"address":"..."}` payload, or the trimmed body itself.
    val candidate = if (trimmed.startsWith("{")) {
        // Accept any of the iOS-compatible keys, in order of preference.
        val regex = """"(?:ip|IP|address)"\s*:\s*"([^"]+)"""".toRegex()
        val match = regex.find(trimmed)
        match?.groupValues?.get(1) ?: run {
            onError?.invoke("🌐 [IP] JSON response missing \"ip\"/\"IP\"/\"address\" field: $trimmed")
            return null
        }
    } else {
        trimmed
    }

    // Validate using InetAddress so both IPv4 and IPv6 are accepted.
    // Reject hostnames/garbage before calling [InetAddress.getByName] so we
    // never trigger a DNS lookup on a body we don't trust. Length bound
    // [7..45] covers "0.0.0.0" through the maximum IPv6 colon-hex form and
    // catches pathological inputs (e.g. 500 colons) in O(1).
    if (candidate.length !in 7..45 || !IP_LITERAL_REGEX.matches(candidate)) {
        onError?.invoke("🌐 [IP] Response is not a numeric IP literal: $candidate")
        return null
    }
    return try {
        InetAddress.getByName(candidate)
        candidate
    } catch (e: Exception) {
        onError?.invoke("🌐 [IP] Failed to validate IP address: $candidate (${e.message})")
        null
    }
}

private val IP_LITERAL_REGEX = Regex("^[0-9a-fA-F:.]+$")
