package com.irdb.irkit


import android.util.Log
import com.google.gson.reflect.TypeToken

import com.irdb.irkit.dto.UserDataDTO
import com.irdb.irkit.response.UserResponse

suspend fun UserService.createAnonymousUser(): UserDataDTO {
    val endpoint = "/User"

    if (BackendService.isDebugMode()) {
        Log.d(TAG, "-- IRCode::createAnonymousUser --")
    }
    val response =
        BackendService.request<BaseResponse<UserResponse>>(
            endpoint = endpoint,
            method = HttpMethod.POST,
            responseType = object : TypeToken<BaseResponse<UserResponse>>() {}.type
        )

    if (!response.succeeded || response.payload == null) {
        Log.e(TAG, "Failed to create anonymous user: ${response.errorMessage}")
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    if (BackendService.isDebugMode()) {
        val ur = payload.results
        Log.d(TAG, ur.user.describeContents())
    }

    val userDataDto =
        UserDataDTO.fromUserResponse(
            payload.results.user
        )
    return userDataDto
}
