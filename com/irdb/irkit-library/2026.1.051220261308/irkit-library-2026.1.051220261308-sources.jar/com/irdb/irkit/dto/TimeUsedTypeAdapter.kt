package com.irdb.irkit.dto

import android.util.Log
import com.google.gson.TypeAdapter
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonWriter

class TimeUsedTypeAdapter : TypeAdapter<Double>() {
    override fun write(out: JsonWriter, value: Double?) {
        out.value(value)
    }

    override fun read(reader: JsonReader): Double {
        try {
            val token = reader.peek()
            return when (token) {
                com.google.gson.stream.JsonToken.NUMBER -> reader.nextDouble()
                com.google.gson.stream.JsonToken.STRING -> {
                    val stringValue = reader.nextString().trim()
                    if (stringValue.endsWith("ms")) {
                        // Extract the numeric value before "ms" and convert to seconds
                        stringValue.substringBefore("ms").trim().toDouble() / 1000.0
                    } else {
                        stringValue.toDouble()
                    }
                }
                else -> {
                    Log.e("TimeUsedTypeAdapter", "Unexpected token type: $token")
                    0.0
                }
            }
        } catch (e: Exception) {
            Log.e("TimeUsedTypeAdapter", "Error parsing timeUsed value: ${e.message}", e)
            return 0.0
        }
    }
}