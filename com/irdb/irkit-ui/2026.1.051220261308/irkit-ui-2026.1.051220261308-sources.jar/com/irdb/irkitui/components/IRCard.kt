package com.irdb.irkitui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

object IRCardDimens {
    val padding = 16.dp
    val cornerRadius = 12.dp
    val elevation = 4.dp
}

@Composable
fun IRCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(IRCardDimens.cornerRadius),
        elevation = CardDefaults.cardElevation(defaultElevation = IRCardDimens.elevation)
    ) {
        androidx.compose.foundation.layout.Column(
            modifier = Modifier.padding(IRCardDimens.padding)
        ) {
            content()
        }
    }
}
