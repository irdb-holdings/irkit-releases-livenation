package com.irdb.irkitui.ui.bottomsheets

import android.content.res.Configuration
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.irdb.irkitui.R
import com.irdb.irkitui.theme.IRKitThemeAccessor
import com.irdb.irkitui.theme.IRKitUITheme
import com.irdb.irkitui.ui.components.OptionCard

object CreateIRCodeBottomSheetDimens {
    val horizontalPadding = 32.dp
    val verticalPadding = 40.dp
    val textSpacing = 20.dp
    val optionSpacing = 24.dp
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateIRCodeBottomSheet(
    onTakePhotoClick: () -> Unit,
    onChoosePhotoClick: () -> Unit,
    onDismiss: () -> Unit
) {
    val colors = IRKitThemeAccessor.colors
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = colors.background,
        contentColor = colors.textPrimary,
        dragHandle = null
    ) {
        CreateIRCodeContent(
            onTakePhotoClick = onTakePhotoClick,
            onChoosePhotoClick = onChoosePhotoClick
        )
    }
}

@Composable
private fun CreateIRCodeContent(
    onTakePhotoClick: () -> Unit,
    onChoosePhotoClick: () -> Unit
) {
    val colors = IRKitThemeAccessor.colors
    val typography = IRKitThemeAccessor.typography

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal = CreateIRCodeBottomSheetDimens.horizontalPadding,
                vertical = CreateIRCodeBottomSheetDimens.verticalPadding
            )
    ) {
        // Title - Centered
        Text(
            text = stringResource(R.string.create_ircode_title),
            style = typography.displayLarge,
            color = colors.textPrimary,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = CreateIRCodeBottomSheetDimens.textSpacing),
            textAlign = TextAlign.Center
        )

        // Subtitle - Centered
        Text(
            text = stringResource(R.string.create_ircode_subtitle),
            style = typography.bodyLarge,
            color = colors.textSecondary,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = CreateIRCodeBottomSheetDimens.verticalPadding),
            textAlign = TextAlign.Center
        )

        // Take Photo Option
        OptionCard(
            iconResId = R.drawable.baseline_camera_alt_24,
            title = stringResource(R.string.create_ircode_take_photo),
            subtitle = stringResource(R.string.create_ircode_take_photo_subtitle),
            onClick = onTakePhotoClick,
            isEnabled = true
        )

        Spacer(modifier = Modifier.height(CreateIRCodeBottomSheetDimens.optionSpacing))

        // Choose Photo Option
        OptionCard(
            iconResId = R.drawable.baseline_photo_library_24,
            title = stringResource(R.string.create_ircode_choose_photo),
            subtitle = stringResource(R.string.create_ircode_choose_photo_subtitle),
            onClick = onChoosePhotoClick,
            isEnabled = true
        )

        Spacer(modifier = Modifier.height(CreateIRCodeBottomSheetDimens.optionSpacing))
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewCreateIRCodeBottomSheet() {
    IRKitUITheme {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = IRKitThemeAccessor.colors.background
        ) {
            CreateIRCodeContent(
                onTakePhotoClick = {},
                onChoosePhotoClick = {}
            )
        }
    }
}

@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
fun PreviewCreateIRCodeBottomSheetDark() {
    IRKitUITheme(darkTheme = true) {
        Surface(
            modifier = Modifier.fillMaxSize(),
            color = IRKitThemeAccessor.colors.background
        ) {
            CreateIRCodeContent(
                onTakePhotoClick = {},
                onChoosePhotoClick = {}
            )
        }
    }
}
