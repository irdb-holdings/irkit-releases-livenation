package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName
import com.irdb.irkit.dto.LensDto

data class LensResponse(
    @SerializedName("lenses")
    val lenses: List<LensDto>? = null,

    @SerializedName("associatedUserID")
    val associatedUserId: Int? = null,

    @SerializedName("lensSearchList")
    val lensSearchList: List<Map<String, String?>>? = null,

    @SerializedName("searchString")
    val searchString: String? = null
)
