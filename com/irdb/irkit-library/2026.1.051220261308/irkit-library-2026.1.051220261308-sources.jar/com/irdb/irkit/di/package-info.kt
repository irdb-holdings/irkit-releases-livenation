/**
 * Dependency injection modules using Hilt.
 * 
 * This package will contain:
 * - Hilt modules for service provision
 * - Binding configurations
 * - Singleton and scoped providers
 * - Network module configurations
 */
package com.irdb.irkit.di