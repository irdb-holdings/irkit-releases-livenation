package com.irdb.analytics

import android.content.Context
import android.content.SharedPreferences
import com.irdb.analytics.models.PendingSessionEnd
import com.irdb.analytics.utils.SessionTrackingIdGenerator

/**
 * Helper class to persist userID and session state in the analytics library.
 * Uses SharedPreferences to store data so it's available across app restarts.
 */
internal class UserPreferences(private val context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences(
        PREFS_NAME,
        Context.MODE_PRIVATE
    )
    
    companion object {
        private const val PREFS_NAME = "analytics_user_prefs"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_PENDING_SESSION_ID = "pending_session_id"
        private const val KEY_PENDING_SESSION_END_TIME = "pending_session_end_time"
        private const val KEY_PENDING_SESSION_START_TIME = "pending_session_start_time"
        private const val KEY_PENDING_SESSION_DURATION = "pending_session_duration"
        private const val KEY_CACHED_IP_ADDRESS = "cached_ip_address"
        private const val KEY_ANONYMOUS_USER_ID = "anonymous_user_id"
        private const val KEY_CACHED_BUCKET_PREFIX = "cached_bucket_"
    }
    
    /**
     * Save userID to SharedPreferences.
     * If userId is null or empty, it will be cleared.
     */
    fun saveUserId(userId: String?) {
        prefs.edit().apply {
            if (userId.isNullOrEmpty()) {
                remove(KEY_USER_ID)
            } else {
                putString(KEY_USER_ID, userId)
            }
            apply()
        }
    }
    
    /**
     * Load persisted userID from SharedPreferences.
     * Returns null if no userID is stored.
     */
    fun loadUserId(): String? {
        return prefs.getString(KEY_USER_ID, null)?.takeIf { it.isNotEmpty() }
    }
    
    /**
     * Clear persisted userID (on logout).
     */
    fun clearUserId() {
        prefs.edit().remove(KEY_USER_ID).apply()
    }

    /**
     * Get or create a persistent anonymous user ID (UUIDv7).
     * Used as the userID when no Firebase user is available (client apps).
     * This ID persists across sessions and survives logout/clearUserContext.
     */
    @Synchronized
    fun getOrCreateAnonymousUserId(): String {
        val existing = prefs.getString(KEY_ANONYMOUS_USER_ID, null)
        if (!existing.isNullOrEmpty()) {
            // Migrate old format (32 hex chars without hyphens) to standard UUID format
            if (existing.length == 32 && !existing.contains("-")) {
                val formatted = "${existing.substring(0, 8)}-${existing.substring(8, 12)}-${existing.substring(12, 16)}-${existing.substring(16, 20)}-${existing.substring(20)}".lowercase()
                prefs.edit().putString(KEY_ANONYMOUS_USER_ID, formatted).commit()
                return formatted
            }
            return existing
        }
        val newId = SessionTrackingIdGenerator.generate()
        prefs.edit().putString(KEY_ANONYMOUS_USER_ID, newId).commit()
        return newId
    }

    /**
     * Save pending session end state for next app start.
     * This is called when the app goes to background to ensure we can send
     * a session-ended event even if the app is killed, crashed, or force-stopped.
     * 
     * @param sessionTrackingId The session tracking ID (UUIDv7) of the session that ended
     * @param sessionEndTimestamp When the session ended (milliseconds since epoch)
     * @param sessionStartTimestamp When the session started (milliseconds since epoch)
     * @param globalDuration Total duration from the global session timer (milliseconds)
     */
    fun savePendingSessionEnd(
        sessionTrackingId: String,
        sessionEndTimestamp: Long,
        sessionStartTimestamp: Long,
        globalDuration: Long
    ) {
        prefs.edit().apply {
            putString(KEY_PENDING_SESSION_ID, sessionTrackingId)
            putLong(KEY_PENDING_SESSION_END_TIME, sessionEndTimestamp)
            putLong(KEY_PENDING_SESSION_START_TIME, sessionStartTimestamp)
            putLong(KEY_PENDING_SESSION_DURATION, globalDuration)
            apply()
        }
    }

    /**
     * Synchronously save pending session end state for next app start.
     * Uses commit() instead of apply() to block until the write completes.
     * This is critical for ensuring session state is persisted before the app can be killed.
     *
     * @param sessionTrackingId The session tracking ID (UUIDv7) of the session that ended
     * @param sessionEndTimestamp When the session ended (milliseconds since epoch)
     * @param sessionStartTimestamp When the session started (milliseconds since epoch)
     * @param globalDuration Total duration from the global session timer (milliseconds)
     * @return true if the commit was successful, false otherwise
     */
    fun savePendingSessionEndSync(
        sessionTrackingId: String,
        sessionEndTimestamp: Long,
        sessionStartTimestamp: Long,
        globalDuration: Long
    ): Boolean {
        return prefs.edit().apply {
            putString(KEY_PENDING_SESSION_ID, sessionTrackingId)
            putLong(KEY_PENDING_SESSION_END_TIME, sessionEndTimestamp)
            putLong(KEY_PENDING_SESSION_START_TIME, sessionStartTimestamp)
            putLong(KEY_PENDING_SESSION_DURATION, globalDuration)
        }.commit()  // commit() blocks until write completes and returns success/failure
    }

    /**
     * Load pending session end state from previous app session.
     * Returns null if no pending session end exists.
     * 
     * @return PendingSessionEnd if session ended without sending event, null otherwise
     */
    fun loadPendingSessionEnd(): PendingSessionEnd? {
        val sessionTrackingId = prefs.getString(KEY_PENDING_SESSION_ID, null)
            ?.takeIf { it.isNotEmpty() } ?: return null
        
        val sessionEndTimestamp = prefs.getLong(KEY_PENDING_SESSION_END_TIME, 0L)
        val sessionStartTimestamp = prefs.getLong(KEY_PENDING_SESSION_START_TIME, 0L)
        val globalDuration = prefs.getLong(KEY_PENDING_SESSION_DURATION, 0L)
        
        // Validate timestamps
        if (sessionEndTimestamp <= 0 || sessionStartTimestamp <= 0) {
            return null
        }
        
        return PendingSessionEnd(
            sessionTrackingId = sessionTrackingId,
            sessionEndTimestamp = sessionEndTimestamp,
            sessionStartTimestamp = sessionStartTimestamp,
            globalDuration = globalDuration
        )
    }
    
    /**
     * Clear pending session end state after successfully sending the event.
     * This should be called after the deferred session-ended event is queued.
     */
    fun clearPendingSessionEnd() {
        prefs.edit().apply {
            remove(KEY_PENDING_SESSION_ID)
            remove(KEY_PENDING_SESSION_END_TIME)
            remove(KEY_PENDING_SESSION_START_TIME)
            remove(KEY_PENDING_SESSION_DURATION)
            apply()
        }
    }
    
    /**
     * Save cached IP address to SharedPreferences.
     * This IP address is fetched from the /myip endpoint and reused for all analytics events.
     * 
     * @param ipAddress The IP address to cache
     */
    fun saveCachedIpAddress(ipAddress: String?) {
        prefs.edit().apply {
            if (ipAddress.isNullOrEmpty()) {
                remove(KEY_CACHED_IP_ADDRESS)
            } else {
                putString(KEY_CACHED_IP_ADDRESS, ipAddress)
            }
            apply()
        }
    }
    
    /**
     * Load cached IP address from SharedPreferences.
     * Returns null if no IP address is cached.
     * 
     * @return The cached IP address, or null if not available
     */
    fun loadCachedIpAddress(): String? {
        return prefs.getString(KEY_CACHED_IP_ADDRESS, null)?.takeIf { it.isNotEmpty() }
    }
    
    /**
     * Clear cached IP address.
     * This forces a fresh fetch from the /myip endpoint on the next request.
     */
    fun clearCachedIpAddress() {
        prefs.edit().remove(KEY_CACHED_IP_ADDRESS).apply()
    }

    /**
     * Load the last-known analytics bucket for a given client company.
     *
     * The bucket is normally populated from the server's `/lenses` response at
     * lens-open. Caching it across launches lets returning users ship analytics
     * with the correct bucket from event #1, even when the REST backend is slow
     * or offline at startup — because we already know what the server told us
     * last time.
     *
     * Keyed by `companyName` so a developer who switches `-PirkitClient` between
     * runs does not get cross-client bucket pollution.
     *
     * @return the cached bucket name, or null if no successful /lenses has been
     *         seen yet for this company.
     */
    fun loadCachedBucketName(companyName: String): String? {
        if (companyName.isBlank()) return null
        return prefs.getString(KEY_CACHED_BUCKET_PREFIX + companyName.lowercase(), null)
            ?.takeIf { it.isNotEmpty() }
    }

    /**
     * Save the analytics bucket for a given client company.
     *
     * Called from `AnalyticsClient.setBucketName(...)` once `/lenses` returns,
     * so the next launch can skip the pre-resolution buffer entirely.
     */
    fun saveCachedBucketName(companyName: String, bucketName: String?) {
        if (companyName.isBlank()) return
        val key = KEY_CACHED_BUCKET_PREFIX + companyName.lowercase()
        prefs.edit().apply {
            if (bucketName.isNullOrBlank()) {
                remove(key)
            } else {
                putString(key, bucketName)
            }
            apply()
        }
    }
}

