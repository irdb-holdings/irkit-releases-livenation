package com.irdb.irkit.dto

import com.google.gson.annotations.SerializedName

/**
 * Data class representing a notification item from the API.
 * Based on the notification API response structure.
 */
data class NotificationItemDto(
    @SerializedName("notificationID")
    val notificationId: Int = 0,

    @SerializedName("notificationType")
    val notificationType: String = "Unknown",

    @SerializedName("created")
    val created: Long = 0L, // Unix timestamp in seconds

    @SerializedName("information")
    val information: String = "",

    @SerializedName("displayLine")
    val displayLine: String = "",

    @SerializedName("readFlag")
    val readFlag: Boolean = false,

    @SerializedName("ActivityUser")
    val activityUser: ActivityUserDto? = null,

    @SerializedName("imageID")
    val imageId: String = "",

    @SerializedName("imageUrl")
    val imageUrl: String = ""
) {
    /**
     * Returns the notification message to display.
     * Priority: displayLine > notificationType string
     */
    val displayMessage: String
        get() = if (displayLine.isNotEmpty()) {
            displayLine
        } else {
            // Fallback to notification type string
            notificationType
        }

    /**
     * Returns true if this notification is unread
     */
    val isUnread: Boolean
        get() = !readFlag
}

