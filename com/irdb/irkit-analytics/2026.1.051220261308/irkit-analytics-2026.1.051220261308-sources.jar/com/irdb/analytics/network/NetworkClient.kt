package com.irdb.analytics.network

import android.util.Log
import com.irdb.analytics.AnalyticsConfig
import com.irdb.analytics.AnalyticsLogger
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import kotlin.time.Duration

/**
 * Network client using HttpURLConnection (built into Android, no external dependencies).
 * Matches the pattern used in irkit-library.
 */
internal object NetworkClient {
    // Equivalent to Json { explicitNulls = false; encodeDefaults = false }:
    // omit null keys globally and only serialize fields that are explicitly present.
    private val analyticsJson = Gson()
    
    /**
     * Get required parameters for an event based on eventType and context
     */
    private fun getRequiredParameters(eventType: String, parameters: Map<String, Any?>): List<String> {
        // Base required fields for ALL events
        val baseRequired = listOf("created", "eventType", "sessionTrackingID", "userType", "userID")

        // Common device/location fields (required for most events).
        // locationIP is no longer sent — backend derives it from /Statistics
        // source IP. Per v2.1 §3 Location Fields, locationLat/locationLng
        // travel as HTTP request headers (set in sendEvents), not body fields.
        val commonFields = listOf("userAgent")
        
        return when (eventType) {
            "status" -> {
                val statusType = parameters["statusType"] as? String
                when (statusType) {
                    "sessionStarted" -> baseRequired + listOf(
                        "statusType", "duration", "deviceType", "deviceModel", "osVersion",
                        "sessionSource", "network", "appSource"
                    ) + commonFields
                    
                    "sessionStopped" -> baseRequired + listOf(
                        "statusType", "duration"
                    ) + commonFields
                    
                    "newUser" -> baseRequired + listOf(
                        "statusType"
                    ) + commonFields
                    
                    "userAccountCreated" -> baseRequired + listOf(
                        "statusType", "userID", "username"
                    ) + commonFields + listOf("userProfileUrl")
                    
                    "userProfileViewed" -> baseRequired + listOf(
                        "statusType", "viewSource", "viewType"
                    ) + commonFields + listOf("duration")
                    
                    "IRCODECreated" -> baseRequired + listOf(
                        "statusType", "buttonSource", "category"
                    ) + commonFields + listOf("duration")
                    
                    "IRCODERemoved" -> baseRequired + listOf(
                        "statusType", "buttonSource"
                    ) + commonFields
                    
                    "imageSaved", "imageRemoved", "imageShared", "imageFavorited", "imageUnfavorited" -> 
                        baseRequired + listOf(
                            "statusType", "imageID"
                        ) + commonFields + listOf("viewSource", "duration")
                    
                    else -> baseRequired + listOf("statusType") + commonFields
                }
            }
            
            "scan" -> {
                val matched = parameters["matched"] as? Boolean
                val failed = parameters["failed"] as? Boolean
                val scanType = parameters["scanType"] as? String
                
                when {
                    failed == true -> baseRequired + listOf(
                        "failed", "scanType", "buttonSource", "buttonType", "network", "category", "title"
                    ) + commonFields + listOf("viewSource", "viewType")
                    
                    matched == true -> baseRequired + listOf(
                        "scanType", "matched", "imageID", "network", "viewSource", "duration"
                    ) + commonFields + listOf("bucketName", "imageTitle", "imageUrl", "similarCount")
                    
                    matched == false -> baseRequired + listOf(
                        "matched", "network", "similarCount", "viewSource"
                    ) + commonFields
                    
                    scanType == "snapshot" || scanType == "captureButton" -> baseRequired + listOf(
                        "buttonSource", "buttonType", "scanType", "imageUrlOfScan", "network",
                        "viewSource"
                    ) + commonFields
                    
                    scanType == "creator" -> baseRequired + listOf(
                        "buttonSource", "buttonType", "scanType", "userType", "network", "viewSource"
                    ) + commonFields
                    
                    else -> baseRequired + listOf("scanType", "network") + commonFields
                }
            }
            
            "view" -> {
                val viewType = parameters["viewType"] as? String
                val viewSource = parameters["viewSource"] as? String
                
                val viewBase = baseRequired + listOf("viewType", "viewSource", "duration") + commonFields
                
                when {
                    viewType == "compressed" -> viewBase + listOf("imageID")
                    viewType == "expanded" -> viewBase + listOf("imageID")
                    viewType == "full" -> {
                        when (viewSource) {
                            "similar", "listView" -> viewBase + listOf("similarCount")
                            "history", "save", "myIrcodes", "trash", "profile" -> viewBase
                            else -> viewBase + listOf("imageID")
                        }
                    }
                    else -> viewBase
                }
            }
            
            "buttonPressed" -> {
                val buttonType = parameters["buttonType"] as? String
                
                val buttonBase = baseRequired + listOf("buttonSource", "buttonType") + commonFields
                
                when (buttonType) {
                    "shutter" -> buttonBase + listOf(
                        "scanType", "viewSource", "viewType"
                    )
                    
                    "product" -> buttonBase + listOf(
                        "imageID", "viewSource", "viewType", "duration",
                        "buttonLink", "linkToFollow"
                    )

                    "link", "linkToSite" -> buttonBase + listOf(
                        "viewSource", "viewType", "duration",
                        "buttonLink", "linkToFollow"
                    )

                    "save" -> buttonBase + listOf(
                        "imageID", "viewSource", "viewType", "duration"
                    )

                    "share" -> buttonBase + listOf(
                        "imageID", "viewSource", "viewType", "duration"
                    )
                    
                    "flashLight" -> buttonBase + listOf(
                        "viewSource", "viewType"
                    )
                    
                    "photoAlbum" -> buttonBase
                    
                    "tag" -> buttonBase + listOf(
                        "viewSource", "viewType", "duration", "imageID"
                    )
                    
                    "expanded", "X" -> buttonBase + listOf(
                        "viewSource", "viewType", "duration", "imageID"
                    )
                    
                    else -> buttonBase
                }
            }

            // v2.1 link event — microsite open associated with a matched IRCODE.
            // `tapped` carries match-bar dwell as `duration`; `autoOpen` omits duration
            // because the preview UI is bypassed (no preceding dwell to measure).
            "link" -> {
                val buttonType = parameters["buttonType"] as? String
                val linkBase = baseRequired + listOf(
                    "buttonType", "imageID", "scanTrackingID", "linkToFollow", "viewSource"
                ) + commonFields
                when (buttonType) {
                    "tapped" -> linkBase + listOf("duration")
                    "autoOpen" -> linkBase
                    else -> linkBase
                }
            }

            else -> baseRequired + commonFields
        }
    }
    
    /**
     * Send events to analytics server using HttpURLConnection
     *
     * All blocking network operations are wrapped in withContext(Dispatchers.IO)
     * to ensure they run on a background thread and don't block image recognition coroutines.
     *
     * Per v2.1 §3 Location Fields, locationLat/locationLng travel as HTTP
     * headers (one value per request, applies to all events in the batch).
     */
    suspend fun sendEvents(
        config: AnalyticsConfig,
        payload: EventBatchPayload,
        logger: AnalyticsLogger
    ): NetworkResponse = withContext(Dispatchers.IO) {
        val url = URL(config.apiEndpoint)
        var connection: HttpURLConnection? = null

        return@withContext try {
            connection = url.openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.doOutput = true
            connection.doInput = true

            // Set headers — also build a parallel map so we can emit them to the
            // capture log for the backend team. Keep this map in sync with every
            // setRequestProperty call below.
            val headersForLog = linkedMapOf<String, String>()
            connection.setRequestProperty("Content-Type", "application/json")
            headersForLog["Content-Type"] = "application/json"
            connection.setRequestProperty("Accept", "application/json")
            headersForLog["Accept"] = "application/json"
            connection.setRequestProperty(config.apiKeyHeaderName, config.apiKey)
            headersForLog[config.apiKeyHeaderName] = config.apiKey

            // v2.1 §3 Location Fields: locationLat / locationLng go as HTTP request headers.
            // Pull from the first event in the batch that carries them (all events in a batch
            // share the same device location context). Skip if no event has a fix.
            val firstLat = payload.events.firstNotNullOfOrNull { it.parameters["locationLat"] }
            val firstLng = payload.events.firstNotNullOfOrNull { it.parameters["locationLng"] }
            if (firstLat != null) {
                connection.setRequestProperty("locationLat", firstLat.toString())
                headersForLog["locationLat"] = firstLat.toString()
            }
            if (firstLng != null) {
                connection.setRequestProperty("locationLng", firstLng.toString())
                headersForLog["locationLng"] = firstLng.toString()
            }

            // Add custom headers
            config.customHeaders.forEach { (key, value) ->
                connection.setRequestProperty(key, value)
                headersForLog[key] = value
            }
            
            // Set timeouts
            connection.connectTimeout = config.connectTimeout.inWholeMilliseconds.toInt()
            connection.readTimeout = config.readTimeout.inWholeMilliseconds.toInt()
            
            // Log only required parameters before posting (for debugging)
            payload.events.forEach { event ->
                val eventType = event.eventName
                val requiredParams = getRequiredParameters(eventType, event.parameters)
                
                // Also include match data fields if present (per documentation: match data should be included in subsequent events)
                val matchDataFields = listOf(
                    "imageID", "imageUrl", "imageTitle", "imageUrlOfScan", 
                    "userIDOwner", "usernameOwner", "scanTrackingID"
                )
                val presentMatchFields = matchDataFields.filter { event.parameters.containsKey(it) }
                val allParamsToLog = (requiredParams + presentMatchFields).distinct()
                
                val paramStrings = allParamsToLog.map { paramName ->
                    // Special handling for eventType - it comes from eventName, not parameters
                    val value = if (paramName == "eventType") {
                        eventType
                    } else {
                        event.parameters[paramName]
                    }
                    val valueStr = when (value) {
                        null -> "[NULL]"
                        is String -> value
                        else -> value.toString()
                    }
                    "$paramName:$valueStr"
                }
                val paramLine = paramStrings.joinToString(", ")
                // Log to analytics_debug tag for easy filtering (single line with all parameters)
                Log.d("analytics_debug", paramLine)
                logger.logDebug("📤 Sending event: $eventType - $paramLine")
            }
            
            // Transform events to backend format: convert eventName to eventType
            // Backend expects eventType, not eventName (per analytics_doc.md line 80)
            // Each event should be a flat JSON object with eventType field
            val transformedEvents = payload.events.map { event ->
                // Create a map with all parameters plus eventType (from eventName)
                val eventJson = mutableMapOf<String, Any?>()
                
                // CRITICAL: Backend requires "eventType", not "eventName" (per docs line 80)
                eventJson["eventType"] = event.eventName
                
                // Add all parameters (these already include created, sessionTrackingID, etc.)
                // Per v2.1 §3 Location Fields, locationLat/locationLng are emitted as HTTP
                // headers above — strip them from the body so they aren't duplicated.
                event.parameters.forEach { (key, value) ->
                    if (key != "locationLat" && key != "locationLng" && value != null) {
                        eventJson[key] = value
                    }
                }

                // v2.1: timeToDisplay exists only on first compressed view events.
                if (event.eventName == "scan") {
                    eventJson.remove("timeToDisplay")
                    val category = eventJson["category"] as? String
                    if (category != "additionalMatch") {
                        eventJson.remove("count")
                    }
                }
                
                // Ensure "created" is set (use timestamp if not in parameters)
                if (!eventJson.containsKey("created")) {
                    eventJson["created"] = event.timestamp
                }

                // Ensure status event timestamps/durations are serialized as integer values.
                // Cached events are parsed through Gson as Double and would otherwise
                // produce `1778240000000.0` / `0.0` on the wire.
                if (event.eventName == "status") {
                    eventJson["created"] = normalizeToLong(eventJson["created"])
                    eventJson["duration"] = normalizeToLong(eventJson["duration"])
                }
                
                eventJson
            }
            
            // Determine payload structure based on number of events
            // Docs say "Single event per POST (unless batch endpoints explicitly enabled)"
            // If single event, send flat object; if multiple, send as array or batch structure
            val backendPayload: Any = when {
                transformedEvents.size == 1 -> {
                    // Single event: send as flat object (matches doc examples)
                    transformedEvents.first()
                }
                else -> {
                    // Multiple events: send as array (backend may support batches)
                    // Format: [{"eventType": "...", ...}, {"eventType": "...", ...}]
                    transformedEvents
                }
            }
            
            // Log network call details (POST + Payload + Headers, in that order — the
            // capture script FIFO-pairs Payload→Response, with Headers slotted between
            // them so each /Statistics call has its full request shape in one place).
            logger.logNetworkCall(config.apiEndpoint, analyticsJson.toJson(backendPayload))
            logger.logNetworkHeaders(headersForLog)
            
            // Write request body
            val jsonBody = analyticsJson.toJson(backendPayload)
            // Log the exact JSON payload sent (for debugging server-side mapping issues).
            // Use Log.i so it appears even when logcat level is Info (Debug is often filtered).
            // Filter logcat by "analytics_payload" to see only this.
            val tag = "analytics_payload"
            Log.i(tag, ">>> Sending ${payload.events.size} event(s). Full JSON body:")
            val maxChunk = 3000
            if (jsonBody.length <= maxChunk) {
                Log.i(tag, jsonBody)
            } else {
                jsonBody.chunked(maxChunk).forEachIndexed { i, chunk ->
                    Log.i(tag, "[part ${i + 1}] $chunk")
                }
            }
            try {
                OutputStreamWriter(connection.outputStream, "UTF-8").use { writer ->
                    writer.write(jsonBody)
                    writer.flush()
                }
            } catch (e: Exception) {
                // If writing fails, disconnect and rethrow
                connection.disconnect()
                throw e
            }
            
            // Read response
            val responseCode = try {
                connection.responseCode
            } catch (e: Exception) {
                connection.disconnect()
                throw e
            }
            
            val responseBody = try {
                if (responseCode in 200..299) {
                    // For success responses, read from input stream
                    connection.inputStream?.let { inputStream ->
                        BufferedReader(InputStreamReader(inputStream, "UTF-8")).use { reader ->
                            reader.readText()
                        }
                    } ?: ""
                } else {
                    // For error responses, try error stream first, fallback to input stream
                    val errorStream = connection.errorStream
                    if (errorStream != null) {
                        BufferedReader(InputStreamReader(errorStream, "UTF-8")).use { reader ->
                            reader.readText()
                        }
                    } else {
                        // Fallback to input stream if error stream is null
                        connection.inputStream?.let { inputStream ->
                            BufferedReader(InputStreamReader(inputStream, "UTF-8")).use { reader ->
                                reader.readText()
                            }
                        } ?: ""
                    }
                }
            } catch (e: Exception) {
                // If reading response fails, log but continue with empty body
                logger.logError("Failed to read response body: ${e.message}", e)
                ""
            }
            
            // Extract Retry-After header for rate limiting (429/503)
            val retryAfterSeconds = try {
                connection.getHeaderField("Retry-After")?.toLongOrNull()
            } catch (e: Exception) {
                null
            }
            
            // Disconnect connection after reading response
            connection.disconnect()
            connection = null

            // Parse server-side result envelope for diagnostic logging. GCF
            // analytics endpoint returns HTTP 200 even when the write failed
            // server-side — the real outcome is inside the JSON body under
            // `Completed` / `ErrorMessage`. Log these unconditionally at the
            // Analytics-Params tag so the server team can correlate a given
            // event batch to their GCF request via GCRLog.
            logAnalyticsServerOutcome(payload.events.size, responseCode, responseBody)

            if (responseCode in 200..299) {
                Log.i("analytics_payload", "<<< SUCCESS HTTP $responseCode for ${payload.events.size} event(s)")
                val response = try {
                    analyticsJson.fromJson(responseBody, EventBatchResponse::class.java)
                } catch (e: Exception) {
                    // If response can't be parsed, assume success but log warning
                    logger.logError("Failed to parse success response body: ${e.message}. Response: $responseBody", e)
                    EventBatchResponse(success = true, eventsReceived = payload.events.size)
                }
                logger.logNetworkResponse(responseCode, responseBody.takeIf { it.isNotEmpty() } ?: "Success")
                NetworkResponse.Success(response)
            } else {
                Log.e("analytics_payload", "<<< FAILURE HTTP $responseCode for ${payload.events.size} event(s)")
                // HTTP ERROR - Log with full details
                logger.logError("❌ HTTP ERROR $responseCode when sending ${payload.events.size} events to ${config.apiEndpoint}")
                logger.logError("Response body: ${responseBody.takeIf { it.isNotEmpty() } ?: "[empty]"}")

                // Log retry-after header if present
                retryAfterSeconds?.let {
                    logger.logError("Retry-After header: ${it}s")
                }

                // Log event IDs that failed
                val eventIds = payload.events.map { it.id }
                logger.logError("Failed event IDs: ${eventIds.joinToString(", ")}")
                
                NetworkResponse.Error(responseCode, responseBody, retryAfterSeconds)
            }
        } catch (e: Exception) {
            // Ensure connection is disconnected even if exception occurs
            connection?.disconnect()

            Log.e("analytics_payload", "<<< FAILURE (exception) for ${payload.events.size} event(s): ${e.javaClass.simpleName}: ${e.message}")
            // Log network exception with full details
            logger.logError("❌ NETWORK EXCEPTION when sending ${payload.events.size} events to ${config.apiEndpoint}", e)
            logger.logError("Exception type: ${e.javaClass.simpleName}, Message: ${e.message}")
            
            // Log event IDs that failed
            val eventIds = payload.events.map { it.id }
            logger.logError("Failed event IDs: ${eventIds.joinToString(", ")}")
            
            NetworkResponse.Exception(e)
        }
    }

    /**
     * Emit a server-outcome diagnostic line at tag `Analytics-Params` so the
     * server team can trace a specific batch via [GCRLog] and so any
     * client-visible signal of a write-through failure (HTTP 200 with
     * `Completed:false`) is plainly visible in logcat next to the outgoing
     * event params. No-op on empty response body.
     *
     * Extracted fields (best-effort, lenient to schema drift):
     *  - `GCRLog`        : unique GCF request id — hand this to the server guy
     *  - `Completed`     : true/false — **true != HTTP 2xx**; a 200 can carry `false`
     *  - `ErrorMessage`  : present when Completed is false or server rejected the write
     *  - `Environment`   : "PRODUCTION" / "STAGING" — which GCF replied
     *  - `GCFVersion`    : the exact Cloud Function revision that served us
     */
    private fun logAnalyticsServerOutcome(
        eventCount: Int,
        httpCode: Int,
        responseBody: String
    ) {
        if (responseBody.isBlank()) {
            // Log.i("Analytics-Params", "📡 server response for $eventCount event(s): HTTP $httpCode body=[empty]")
            return
        }
        val gcrLog      = extractStringField(responseBody, "GCRLog")
        val completed   = extractBooleanField(responseBody, "Completed")
        val environment = extractStringField(responseBody, "Environment")
        val gcfVersion  = extractStringField(responseBody, "GCFVersion")
        val errorInline = extractErrorMessage(responseBody)

        val outcome = when {
            completed == true  -> "✅ accepted"
            completed == false -> "❌ REJECTED"
            else               -> "? unknown"
        }
        // Log.i(
        //     "Analytics-Params",
        //     "📡 server response for $eventCount event(s): HTTP $httpCode, " +
        //         "Completed=$completed $outcome, " +
        //         "GCRLog=${gcrLog ?: "[missing]"}, " +
        //         "Env=${environment ?: "[missing]"}, " +
        //         "GCFVersion=${gcfVersion ?: "[missing]"}" +
        //         (errorInline?.let { ", ErrorMessage=$it" } ?: "")
        // )
    }

    // Minimal string-field extraction so the diagnostic log never fails due
    // to Gson schema mismatches. Looks for `"key":"value"` (allows
    // whitespace and escaped quotes inside the value). Returns null if the
    // key isn't present or the value isn't a quoted string.
    private fun extractStringField(body: String, key: String): String? {
        val regex = Regex("\"$key\"\\s*:\\s*\"((?:\\\\\"|[^\"])*)\"")
        return regex.find(body)?.groupValues?.get(1)
    }

    private fun extractBooleanField(body: String, key: String): Boolean? {
        val regex = Regex("\"$key\"\\s*:\\s*(true|false)")
        return regex.find(body)?.groupValues?.get(1)?.toBooleanStrictOrNull()
    }

    // Error payloads come back as either a quoted string or a nested object.
    // Flatten enough of it to surface the error + inner message for logs
    // without pulling in a full JSON parser here.
    private fun extractErrorMessage(body: String): String? {
        val errRegex = Regex("\"error\"\\s*:\\s*\"((?:\\\\\"|[^\"])*)\"")
        val errors = errRegex.findAll(body).map { it.groupValues[1] }.toList()
        return if (errors.isEmpty()) null else errors.joinToString(" / ")
    }

    private fun normalizeToLong(value: Any?): Long {
        return when (value) {
            is Number -> value.toLong()
            is String -> value.trim().toDoubleOrNull()?.toLong() ?: 0L
            else -> 0L
        }
    }
}

/**
 * Network response wrapper
 */
sealed class NetworkResponse {
    data class Success(val response: EventBatchResponse) : NetworkResponse()
    data class Error(
        val statusCode: Int,
        val message: String,
        val retryAfterSeconds: Long? = null  // Retry-After header value (for 429/503)
    ) : NetworkResponse() {
        /**
         * Check if this is a rate limiting error (429 Too Many Requests)
         */
        val isRateLimit: Boolean
            get() = statusCode == 429
        
        /**
         * Check if this is a service unavailable error (503 Service Unavailable)
         */
        val isServiceUnavailable: Boolean
            get() = statusCode == 503
        
        /**
         * Check if this error should trigger exponential backoff
         */
        val shouldBackoff: Boolean
            get() = isRateLimit || isServiceUnavailable
    }
    data class Exception(val throwable: Throwable) : NetworkResponse()
}

/**
 * Batch payload for sending multiple events
 */
data class EventBatchPayload(
    val events: List<com.irdb.analytics.models.EventPayload>
)

/**
 * Response from analytics server
 */
data class EventBatchResponse(
    val success: Boolean,
    val message: String? = null,
    val eventsReceived: Int = 0
)
