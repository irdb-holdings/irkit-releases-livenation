package com.irdb.irkit.ui

import android.graphics.Bitmap
import android.graphics.RectF
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize

/**
 * Segmentation mask overlay drawn on top of the camera preview.
 *
 * Draws the segmentation mask as a two-color overlay matching iOS/web:
 *   - Semi-transparent **red** over the AI-detected object
 *   - Semi-transparent **green** over the background
 *
 * Coordinates are transformed to account for the PreviewView scale type so
 * the mask aligns correctly with the displayed camera image:
 *   - FILL_CENTER (default): camera frame is scaled to fill the screen, clipping edges
 *   - FIT_CENTER: camera frame fits within the screen with letterboxing
 *
 * @param showOverlay Whether to render the overlay (from ClientConfigBase.showSegmentationBoundingBox)
 * @param boundingBox Retained for API compatibility; no longer rendered
 * @param maskBitmap Two-color mask bitmap from the segmentation model (384x384), or null
 * @param frameWidth Width of the rotated camera frame in pixels (0 = unknown, falls back to direct mapping)
 * @param frameHeight Height of the rotated camera frame in pixels (0 = unknown, falls back to direct mapping)
 * @param isFillScale True for FILL_CENTER (default PreviewView), false for FIT_CENTER
 */
@Composable
fun SegmentationBboxOverlay(
    showOverlay: Boolean,
    @Suppress("UNUSED_PARAMETER") boundingBox: RectF?,
    maskBitmap: Bitmap? = null,
    frameWidth: Int = 0,
    frameHeight: Int = 0,
    isFillScale: Boolean = true,
    modifier: Modifier = Modifier
) {
    if (!showOverlay) return
    if (maskBitmap == null) return

    Canvas(modifier = modifier.fillMaxSize()) {
        // Compute the FILL/FIT_CENTER transform
        val hasFrameSize = frameWidth > 0 && frameHeight > 0
        val scaleX = if (hasFrameSize) size.width / frameWidth else 1f
        val scaleY = if (hasFrameSize) size.height / frameHeight else 1f
        val scale = if (hasFrameSize) {
            if (isFillScale) maxOf(scaleX, scaleY) else minOf(scaleX, scaleY)
        } else 1f
        val displayedW = if (hasFrameSize) frameWidth * scale else size.width
        val displayedH = if (hasFrameSize) frameHeight * scale else size.height
        val offsetX = (size.width - displayedW) / 2f
        val offsetY = (size.height - displayedH) / 2f

        // Draw the two-color segmentation mask (red = object, green = background)
        if (!maskBitmap.isRecycled) {
            drawImage(
                image = maskBitmap.asImageBitmap(),
                dstOffset = IntOffset(offsetX.toInt(), offsetY.toInt()),
                dstSize = IntSize(displayedW.toInt(), displayedH.toInt()),
                filterQuality = FilterQuality.Medium
            )
        }
    }
}
