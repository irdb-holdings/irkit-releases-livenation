package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName
import com.irdb.irkit.BaseResponse
import com.irdb.irkit.dto.ImageDto

data class ImageContainer(
    @SerializedName("Image")
    val image: ImageDto
)

typealias GetImageResponse = BaseResponse<ImageContainer>
