package com.irdb.irkitui.theme

import androidx.compose.ui.graphics.Color

/**
 * Defines the color scheme for IRKit-UI components.
 *
 * This data class provides semantic color naming for all UI elements,
 * allowing client themes to customize the appearance while maintaining
 * consistent behavior across components.
 *
 * Usage in components:
 * ```kotlin
 * Box(modifier = Modifier.background(IRKitTheme.colors.primary))
 * Text(color = IRKitTheme.colors.textPrimary)
 * ```
 */
data class IRKitColorScheme(
    // ============================================
    // Backgrounds
    // ============================================

    /** Main background color for screens and large containers */
    val background: Color,

    /** Surface color for cards and elevated components */
    val surface: Color,

    /** Alternative surface color for visual hierarchy */
    val surfaceVariant: Color,

    /** Background color for card components */
    val cardBackground: Color,

    // ============================================
    // Primary/Accent Colors
    // ============================================

    /** Primary brand color for buttons and interactive elements */
    val primary: Color,

    /** Text/icon color on primary colored backgrounds */
    val onPrimary: Color,

    /** Accent color for highlights and secondary actions */
    val accent: Color,

    /** Text/icon color on accent colored backgrounds */
    val onAccent: Color,

    // ============================================
    // Text Colors
    // ============================================

    /** Primary text color for headings and important content */
    val textPrimary: Color,

    /** Secondary text color for subtitles and descriptions */
    val textSecondary: Color,

    /** Disabled text color for inactive or unavailable content */
    val textDisabled: Color,

    // ============================================
    // Interactive Elements
    // ============================================

    /** Background color for mode selector component */
    val selectorBackground: Color,

    /** Color for selected state in mode selector */
    val selectorSelected: Color,

    /** Text color for selected items (on selectorSelected background) */
    val onSelectorSelected: Color,

    /** Text color for unselected items in selector */
    val selectorUnselectedText: Color,

    // ============================================
    // Camera/Scanner Colors
    // ============================================

    /** Default guiding rectangle border color */
    val guidingRectangle: Color,

    /** Guiding rectangle color when image is recognized */
    val guidingRectangleActive: Color,

    /** Overlay color for camera scanning area */
    val cameraOverlay: Color,

    // ============================================
    // Status & Badges
    // ============================================

    /** Success/confirmation color */
    val success: Color,

    /** Background color for badge components (Pro badge, etc.) */
    val badgeBackground: Color,

    /** Background color for tag components (Soon tag, etc.) */
    val tagBackground: Color,

    /** Text color for tags */
    val tagText: Color,

    // ============================================
    // Icons & Miscellaneous
    // ============================================

    /** Background color for icon containers */
    val iconBackground: Color,

    /** Button background with transparency (for ShadowButton) */
    val buttonOverlay: Color,

    /** Border color for buttons and cards */
    val borderColor: Color
)
