package com.irdb.irkitui.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Legacy color definitions for backward compatibility.
 *
 * @deprecated These colors are deprecated. Use [com.irdb.irkitui.theme.IRKitThemeAccessor.colors]
 * instead for themeable colors.
 *
 * Migration guide:
 * - ModeSelectorBackgroundColor -> IRKitTheme.colors.selectorBackground
 * - ModeSelectorSelectedColor -> IRKitTheme.colors.selectorSelected
 * - IRKitBackgroundColor -> IRKitTheme.colors.background
 * - IRKitTextColor -> IRKitTheme.colors.textPrimary
 * - CreateIRCodeBackgroundColor -> IRKitTheme.colors.background
 * - CreateIRCodeCardBackgroundColor -> IRKitTheme.colors.surface
 * - CreateIRCodeTitleColor -> IRKitTheme.colors.textPrimary
 * - CreateIRCodeSubtitleColor -> IRKitTheme.colors.textSecondary
 * - CreateIRCodeDisabledTextColor -> IRKitTheme.colors.textDisabled
 * - CreateIRCodeIconBackgroundColor -> IRKitTheme.colors.iconBackground
 * - CreateIRCodeSoonTagBackgroundColor -> IRKitTheme.colors.tagBackground
 * - CreateIRCodeSoonTagTextColor -> IRKitTheme.colors.tagText
 */

// ModeSelectorView Colors for IRKit-UI
@Deprecated(
    message = "Use IRKitThemeAccessor.colors.selectorBackground instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.selectorBackground", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val ModeSelectorBackgroundColor = Color(0xFF2D2D2D)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.selectorSelected instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.selectorSelected", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val ModeSelectorSelectedColor = Color(0xFFFFD700)


// IRKit Camera Component Colors
@Deprecated(
    message = "Use IRKitThemeAccessor.colors.background instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.background", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val IRKitBackgroundColor = Color(0xFF000000)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.textPrimary instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.textPrimary", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val IRKitTextColor = Color.White

// CreateIRCodeBottomSheet Colors - iOS Style
@Deprecated(
    message = "Use IRKitThemeAccessor.colors.background instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.background", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val CreateIRCodeBackgroundColor = Color(0xFF000000)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.surface instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.surface", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val CreateIRCodeCardBackgroundColor = Color(0xFF1C1C1E)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.textPrimary instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.textPrimary", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val CreateIRCodeTitleColor = Color(0xFFFFFFFF)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.textSecondary instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.textSecondary", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val CreateIRCodeSubtitleColor = Color(0xFF8E8E93)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.textPrimary instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.textPrimary", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val CreateIRCodeActiveTextColor = Color(0xFFFFFFFF)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.textSecondary instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.textSecondary", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val CreateIRCodeActiveSecondaryTextColor = Color(0xFF8E8E93)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.textDisabled instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.textDisabled", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val CreateIRCodeDisabledTextColor = Color(0xFF545458)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.textDisabled with lower alpha instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.cardBackground", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val CreateIRCodeDisabledSecondaryTextColor = Color(0xFF3A3A3C)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.surface instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.surface", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val CreateIRCodeDisabledCardBackgroundColor = Color(0xFF1C1C1E)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.iconBackground instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.iconBackground", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val CreateIRCodeIconBackgroundColor = Color(0xFF3A3A3C)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.tagBackground instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.tagBackground", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val CreateIRCodeSoonTagBackgroundColor = Color(0xFF545458)

@Deprecated(
    message = "Use IRKitThemeAccessor.colors.tagText instead",
    replaceWith = ReplaceWith("IRKitThemeAccessor.colors.tagText", "com.irdb.irkitui.theme.IRKitThemeAccessor")
)
val CreateIRCodeSoonTagTextColor = Color(0xFFFFFFFF)
