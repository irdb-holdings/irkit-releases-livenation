package com.irdb.irkit.segmentation

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.RectF
import android.net.Uri
import android.util.Log
import androidx.exifinterface.media.ExifInterface
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.nio.FloatBuffer

/**
 * ONNX segmentation inference engine.
 *
 * This class runs an AI model (GazeNet) that looks at a camera frame and decides
 * which pixels belong to "the object" (e.g. a TV) and which are background.
 *
 * ## How it works end-to-end
 *
 * 1. **[preprocessImage]** — Takes a camera frame bitmap, resizes it to 384x384,
 *    and converts it into a float array that the model understands (BGR color order,
 *    values 0.0–1.0). Think of this as "translating" the image into the model's language.
 *
 * 2. **[runInference]** — Feeds that float array plus a "gaze point" (where on screen
 *    the user is looking, default = center) into the ONNX model. The model returns a
 *    384x384 grid of confidence scores (0.0 to 1.0), where each score says "how confident
 *    am I that this pixel is part of the object?" A score of 0.95 = very confident it's
 *    the object; 0.1 = very confident it's background.
 *
 * 3. **[postprocessMask]** — Takes that confidence grid and converts it into a single
 *    bounding box rectangle (RectF). It thresholds at 0.85 (anything above = object),
 *    trims outlier pixels from the edges, adds padding, and normalizes to 0–1 coordinates.
 *    This box is what drives the crop region sent to the backend for image recognition.
 *
 * 4. **[buildMaskBitmap]** — (Debug overlay only) Takes the same confidence grid and
 *    creates a colored bitmap: red pixels = object, green pixels = background. This is
 *    drawn on top of the camera preview when the "Show Segmentation BBox" switch is on.
 *
 * ## Key concepts
 * - **ONNX Runtime**: A cross-platform ML inference engine. Runs the same .onnx model
 *   file on Android (here), iOS, and web.
 * - **NNAPI**: Android's Neural Networks API — hardware acceleration for ML on supported
 *   chips (GPU/DSP). Falls back to CPU if unavailable or buggy.
 * - **NCHW**: Tensor layout — [batch, channels, height, width]. The model expects pixels
 *   arranged as all-blue-values, then all-green, then all-red (BGR order).
 * - **Gaze point**: The model has an attention mechanism — gaze_x/gaze_y (0–1) tell it
 *   where to focus. Default 0.5/0.5 = center of frame.
 *
 * Exact port of iOS SegmentationProcessor — same model, same preprocessing,
 * same postprocessing algorithm. Both platforms produce the same bounding box
 * for the same input image.
 *
 * Lifecycle: create once per camera session, call [preprocessImage] + [runInference] +
 * [postprocessMask] per frame, call [close] when done.
 *
 * @param context Application context for loading the model from assets
 * @param useNnapi Whether to attempt NNAPI acceleration (set false for known-bad Exynos devices)
 * @param modelName ONNX model filename in assets (resolved by [SegmentationModelResolver])
 */
class SegmentationProcessor(
    private val context: Context,
    private val useNnapi: Boolean = true,
    internal val modelName: String = SegmentationConfig.modelName
) {

    companion object {
        private const val TAG = "SegmentationProcessor"
        private const val INPUT_SIZE = 384
    }

    init {
        Log.d(TAG, "SegmentationProcessor created: model=$modelName, nnapi=$useNnapi")
    }

    // ONNX Runtime environment — singleton, manages memory for all tensors/sessions.
    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()

    // The ONNX model session — loaded lazily (first time it's accessed) from the
    // .onnx file in the app's assets folder. This is the actual AI model.
    // - Thread count scales with device cores (2-4) for better utilization
    // - ALL_OPT = maximum graph optimizations (fuse ops, constant folding, etc.)
    // - NNAPI = tries to use the phone's GPU/DSP for faster inference; falls back
    //   to CPU if the hardware doesn't support it or produces wrong results.
    private val session: OrtSession by lazy {
        val options = OrtSession.SessionOptions().apply {
            val cores = Runtime.getRuntime().availableProcessors()
            setIntraOpNumThreads(cores.coerceIn(2, 4))
            setOptimizationLevel(OrtSession.SessionOptions.OptLevel.ALL_OPT)
            if (useNnapi) {
                try { addNnapi() } catch (_: Exception) { /* fall back to CPU */ }
            }
        }
        val bytes = context.assets.open(modelName).readBytes()
        env.createSession(bytes, options)
    }

    // Returns true if the model loaded without errors and is ready for inference.
    val isReady: Boolean get() = try { session; true } catch (_: Exception) { false }

    // Pre-allocated buffers to avoid per-frame GC pressure (~2.8MB saved per inference)
    // Safe because inference runs on a single dedicated thread.
    private val pixelBuffer = IntArray(INPUT_SIZE * INPUT_SIZE)
    private val tensorBuffer = FloatArray(3 * INPUT_SIZE * INPUT_SIZE)

    // -------------------------------------------------------------------------
    // EXIF rotation correction — only needed for JPEGs loaded from disk
    // (snapshot/gallery path). NOT needed for live CameraX frames since
    // processFrame() already handles rotation.
    //
    // Device-dependent: Pixel typically needs it, some Samsungs do not.
    // This is a no-op when EXIF says ORIENTATION_NORMAL.
    // -------------------------------------------------------------------------
    fun correctBitmapOrientation(bitmap: Bitmap, imageUri: Uri): Bitmap {
        val exif = try {
            context.contentResolver.openInputStream(imageUri)?.use { ExifInterface(it) }
        } catch (_: Exception) { null } ?: return bitmap

        val orientation = exif.getAttributeInt(
            ExifInterface.TAG_ORIENTATION,
            ExifInterface.ORIENTATION_NORMAL
        )
        val matrix = android.graphics.Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.preScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.preScale(1f, -1f)
            else -> return bitmap
        }
        return Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    }

    // -------------------------------------------------------------------------
    // Step 1: Preprocess — convert camera frame into model input.
    //
    // The model expects a very specific format:
    //   1. Resize to 384x384 — model has a fixed input size
    //   2. BGR color order — NOT the usual RGB (the model was trained on BGR)
    //   3. NCHW layout — instead of pixel-by-pixel [R,G,B, R,G,B, ...], it wants
    //      all Blue values first, then all Green, then all Red (3 "planes")
    //   4. Values 0.0–1.0 — divide raw 0–255 pixel values by 255
    //
    // Example: a 384x384 image becomes a float array of 442,368 values
    //          (384 * 384 * 3 channels)
    //
    // Matches iOS SegmentationProcessor.makeInputTensor exactly.
    // -------------------------------------------------------------------------
    fun preprocessImage(bitmap: Bitmap): FloatArray {
        val scaled = Bitmap.createScaledBitmap(bitmap, INPUT_SIZE, INPUT_SIZE, true)
        scaled.getPixels(pixelBuffer, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE)
        if (scaled !== bitmap) scaled.recycle()

        val planeSize = INPUT_SIZE * INPUT_SIZE
        for (i in pixelBuffer.indices) {
            val px = pixelBuffer[i]
            tensorBuffer[0 * planeSize + i] = Color.blue(px) / 255f   // plane 0 = B
            tensorBuffer[1 * planeSize + i] = Color.green(px) / 255f  // plane 1 = G
            tensorBuffer[2 * planeSize + i] = Color.red(px) / 255f    // plane 2 = R
        }
        return tensorBuffer
    }

    // -------------------------------------------------------------------------
    // Step 2: Run inference — feed the preprocessed image into the AI model.
    //
    // This is the actual "AI" part. The model takes 3 inputs:
    //   "image"  — the preprocessed 384x384 BGR image from step 1
    //   "gaze_x" — where to focus horizontally (0.0=left, 0.5=center, 1.0=right)
    //   "gaze_y" — where to focus vertically (0.0=top, 0.5=center, 1.0=bottom)
    //
    // The model returns a 384x384 grid of float values (0.0 to 1.0).
    // Each value is a confidence score: "how sure am I this pixel is the object?"
    //   - 0.95 = "almost certainly the object (e.g. the TV)"
    //   - 0.50 = "uncertain"
    //   - 0.05 = "almost certainly background (e.g. the wall)"
    //
    // Typical inference time: 50–200ms depending on device and NNAPI support.
    //
    // Returns: Pair(confidenceGrid, outputShape)
    // -------------------------------------------------------------------------
    fun runInference(
        imageData: FloatArray,
        gazeX: Float = SegmentationConfig.gazeX,
        gazeY: Float = SegmentationConfig.gazeY
    ): Pair<FloatArray, LongArray> {
        val imageTensor = OnnxTensor.createTensor(
            env,
            FloatBuffer.wrap(imageData),
            longArrayOf(1, 3, INPUT_SIZE.toLong(), INPUT_SIZE.toLong())
        )
        val gazeXTensor = OnnxTensor.createTensor(
            env, FloatBuffer.wrap(floatArrayOf(gazeX)), longArrayOf(1)
        )
        val gazeYTensor = OnnxTensor.createTensor(
            env, FloatBuffer.wrap(floatArrayOf(gazeY)), longArrayOf(1)
        )

        try {
            val inputs = mapOf(
                "image" to imageTensor,
                "gaze_x" to gazeXTensor,
                "gaze_y" to gazeYTensor
            )

            session.run(inputs).use { result ->
                val outputTensor: OnnxTensor = try {
                    result.get("output").get() as OnnxTensor
                } catch (_: Exception) {
                    result.get(0) as OnnxTensor
                }
                val shape = outputTensor.info.shape
                val buf = outputTensor.floatBuffer
                val mask = FloatArray(buf.remaining())
                buf.get(mask)
                return Pair(mask, shape)
            }
        } finally {
            imageTensor.close()
            gazeXTensor.close()
            gazeYTensor.close()
        }
    }

    // -------------------------------------------------------------------------
    // Helper: figure out the mask dimensions from the output tensor shape.
    //
    // Different model versions may return different shaped tensors:
    //   [1, 1, 384, 384] → 4D: width=384, height=384
    //   [1, 384, 384]    → 3D: same
    //   [384, 384]        → 2D: same
    // This handles all cases so we're robust to model changes.
    // -------------------------------------------------------------------------
    fun parseMaskDimensions(shape: LongArray): Pair<Int, Int> {
        return when {
            shape.size >= 4 -> Pair(
                maxOf(1, shape[shape.size - 1].toInt()),
                maxOf(1, shape[shape.size - 2].toInt())
            )
            shape.size == 3 -> Pair(
                maxOf(1, shape[2].toInt()),
                maxOf(1, shape[1].toInt())
            )
            shape.size == 2 -> Pair(
                maxOf(1, shape[1].toInt()),
                maxOf(1, shape[0].toInt())
            )
            else -> Pair(INPUT_SIZE, INPUT_SIZE)
        }
    }

    // -------------------------------------------------------------------------
    // Step 3: Postprocess — convert the confidence grid into a bounding box.
    //
    // The confidence grid from step 2 is a "heat map" of where the object is.
    // This function turns that fuzzy heat map into a clean rectangle:
    //
    //   1. THRESHOLD at 0.85 — any pixel with confidence > 0.85 counts as
    //      "object". Build histograms: how many object-pixels in each column (X)
    //      and each row (Y).
    //
    //   2. NO OBJECT CHECK — if zero pixels passed the threshold, return null
    //      (the model didn't find anything).
    //
    //   3. TRIM EDGES (2%) — remove the outermost 2% of object-pixels from
    //      each side. This eliminates stray noise pixels at the edges that
    //      would make the box too large.
    //
    //   4. PAD (10%) — expand the trimmed box by 10% on each side so the crop
    //      isn't too tight. Clamp to image bounds.
    //
    //   5. NORMALIZE — convert pixel coordinates to 0–1 range so the box works
    //      at any resolution. (0,0) = top-left, (1,1) = bottom-right.
    //
    // The returned RectF is used to crop the camera frame before sending it
    // to the backend for image recognition (so we send just the TV, not the
    // whole room).
    //
    // Returns RectF(left, top, right, bottom) in [0,1], or null if no object.
    // -------------------------------------------------------------------------
    fun postprocessMask(
        mask: FloatArray,
        maskWidth: Int,
        maskHeight: Int,
        threshold: Float = SegmentationConfig.MASK_THRESHOLD,
        trimPercent: Double = SegmentationConfig.TRIM_PERCENT,
        paddingPercent: Double = SegmentationConfig.PADDING_PERCENT
    ): RectF? {
        val histX = IntArray(maskWidth)
        val histY = IntArray(maskHeight)
        var total = 0

        for (y in 0 until maskHeight) {
            for (x in 0 until maskWidth) {
                if (mask[y * maskWidth + x] > threshold) {
                    histX[x]++
                    histY[y]++
                    total++
                }
            }
        }
        if (total == 0) return null

        val trimTarget = maxOf(1, (total * trimPercent).toInt())

        fun trimMin(arr: IntArray): Int {
            var running = 0
            for (i in arr.indices) {
                running += arr[i]
                if (running >= trimTarget) return i
            }
            return 0
        }

        fun trimMax(arr: IntArray): Int {
            var running = 0
            for (i in arr.indices.reversed()) {
                running += arr[i]
                if (running >= trimTarget) return i
            }
            return arr.size - 1
        }

        var minX = trimMin(histX)
        var maxX = trimMax(histX)
        var minY = trimMin(histY)
        var maxY = trimMax(histY)

        val padX = ((maxX - minX + 1) * paddingPercent).toInt()
        val padY = ((maxY - minY + 1) * paddingPercent).toInt()
        minX = maxOf(0, minX - padX)
        maxX = minOf(maskWidth - 1, maxX + padX)
        minY = maxOf(0, minY - padY)
        maxY = minOf(maskHeight - 1, maxY + padY)

        val w = maxOf(1, maxX - minX + 1)
        val h = maxOf(1, maxY - minY + 1)
        return RectF(
            minX / maskWidth.toFloat(),
            minY / maskHeight.toFloat(),
            (minX + w) / maskWidth.toFloat(),
            (minY + h) / maskHeight.toFloat()
        )
    }

    // -------------------------------------------------------------------------
    // Step 4 (debug only): Build a colored bitmap to visualize the mask.
    //
    // Uses gradient blending based on confidence values so that the boundary
    // between object (red) and background (green) is smooth rather than jagged.
    //
    // Pixels well above threshold → fully red (25% opacity)
    // Pixels well below threshold → fully green (25% opacity)
    // Pixels near the threshold   → smooth blend of red↔green
    //
    // The blend zone spans ±0.15 around the threshold (e.g. 0.70–1.00 for
    // threshold 0.85). This produces smooth edges matching iOS/web.
    // -------------------------------------------------------------------------
    fun buildMaskBitmap(
        mask: FloatArray,
        maskWidth: Int,
        maskHeight: Int,
        threshold: Float = SegmentationConfig.MASK_THRESHOLD
    ): Bitmap {
        val pixels = IntArray(maskWidth * maskHeight)
        val blendRange = 0.15f // how far from threshold the gradient extends
        val lo = threshold - blendRange // below this = fully green
        val hi = threshold + blendRange // above this = fully red
        val alpha = 0x40 // 25% opacity for both colors

        for (i in pixels.indices) {
            val conf = mask[i]
            // t: 0.0 = fully green, 1.0 = fully red, 0.5 = at threshold
            val t = ((conf - lo) / (hi - lo)).coerceIn(0f, 1f)
            val r = (255 * t).toInt()
            val g = (255 * (1f - t)).toInt()
            pixels[i] = (alpha shl 24) or (r shl 16) or (g shl 8)
        }
        val bmp = Bitmap.createBitmap(maskWidth, maskHeight, Bitmap.Config.ARGB_8888)
        bmp.setPixels(pixels, 0, maskWidth, 0, 0, maskWidth, maskHeight)
        return bmp
    }

    fun close() {
        try { session.close() } catch (_: Exception) {}
        // Do NOT close env — OrtEnvironment.getEnvironment() returns a process-wide singleton.
        // Closing it would break any subsequent ONNX sessions.
    }
}
