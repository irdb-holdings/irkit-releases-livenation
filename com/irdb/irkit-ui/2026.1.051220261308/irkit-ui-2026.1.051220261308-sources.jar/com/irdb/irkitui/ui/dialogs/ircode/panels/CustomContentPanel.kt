package com.irdb.irkitui.ui.dialogs.ircode.panels

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object CustomContentPanelDimens {
    val verticalSpacing = 12.dp
    val horizontalPadding = 0.dp
    val labelFontSize = 16.sp
    val valueFontSize = 18.sp
    const val valueColumnWeight = 0.5f
    const val labelColumnWeight = 1f - valueColumnWeight
}

@Composable
fun CustomContentPanel(
    customFields: List<Pair<String, String>>, // e.g., output of getCustomFieldsArray()
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(CustomContentPanelDimens.horizontalPadding)
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(contentPadding),
        verticalArrangement = Arrangement.spacedBy(CustomContentPanelDimens.verticalSpacing)
    ) {
        customFields.forEach { (labelText, valueText) ->
            Row(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = labelText,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = CustomContentPanelDimens.labelFontSize,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(CustomContentPanelDimens.labelColumnWeight)
                )
                Text(
                    text = valueText,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = CustomContentPanelDimens.valueFontSize,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(CustomContentPanelDimens.valueColumnWeight)
                )
            }
        }
    }
}

