package com.irdb.irkit.shared

import com.irdb.irkit.dto.ProductInCampaignDto
import java.util.UUID

data class ProductLinkShared(
    val id: String,
    val linkToFollow: String,
    val title: String,
    val imageUrl: String?,
)

fun ProductInCampaignDto.toShared(): ProductLinkShared {
    return ProductLinkShared(
        id = id ?: UUID.randomUUID().toString(),
        linkToFollow = linkToFollow,
        title = title,
        imageUrl = imageUrl.takeIf { it.isNotBlank() },
    )
}
