package com.irdb.irkit.utils

import android.content.Context

/**
 * Example usage of ErrorCodeTranslator This file demonstrates how to use the ErrorCodeTranslator in
 * different scenarios
 */
class ErrorCodeTranslatorExample {

    /** Example: Using ErrorCodeTranslator with context for localization */
    fun handleErrorWithLocalization(errorCode: String, context: Context) {
        val translatedMessage = ErrorCodeTranslator.translate(errorCode, context)
        // Use the translated message in your UI
        showErrorToUser(translatedMessage)
    }

    /** Example: Using ErrorCodeTranslator without context (fallback to English) */
    fun handleErrorWithoutContext(errorCode: String) {
        val translatedMessage = ErrorCodeTranslator.translate(errorCode)
        // Use the translated message in your UI
        showErrorToUser(translatedMessage)
    }

    /** Example: Checking if an error code has a translation before processing */
    fun processErrorCode(errorCode: String, context: Context) {
        if (ErrorCodeTranslator.hasTranslation(errorCode)) {
            val translatedMessage = ErrorCodeTranslator.translate(errorCode, context)
            showErrorToUser(translatedMessage)
        } else {
            // Handle unknown error codes
            showErrorToUser("Unknown error: $errorCode")
        }
    }

    /** Example: Using in a ViewModel or Repository */
    fun handleBackendError(errorCode: String, context: Context): String {
        return ErrorCodeTranslator.translate(errorCode, context)
    }

    /** Example: Using in error handling for API calls */
    fun handleApiError(errorCode: String, context: Context) {
        when (errorCode) {
            "notValidOwner1" -> {
                val message = ErrorCodeTranslator.translate(errorCode, context)
                // Handle specific error case
                showPermissionError(message)
            }
            "networkError" -> {
                val message = ErrorCodeTranslator.translate(errorCode, context)
                // Handle network error
                showNetworkError(message)
            }
            else -> {
                val message = ErrorCodeTranslator.translate(errorCode, context)
                // Handle generic error
                showGenericError(message)
            }
        }
    }

    // Example helper methods (these would be implemented in your actual code)
    private fun showErrorToUser(message: String) {
        // Implementation would show error to user (e.g., via Toast, Snackbar, etc.)
        println("Error: $message")
    }

    private fun showPermissionError(message: String) {
        // Implementation for permission errors
        println("Permission Error: $message")
    }

    private fun showNetworkError(message: String) {
        // Implementation for network errors
        println("Network Error: $message")
    }

    private fun showGenericError(message: String) {
        // Implementation for generic errors
        println("Generic Error: $message")
    }
}
