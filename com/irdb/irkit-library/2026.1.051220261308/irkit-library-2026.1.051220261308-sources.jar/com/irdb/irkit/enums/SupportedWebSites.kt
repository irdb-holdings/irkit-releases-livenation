package com.irdb.irkit.enums

/**
 * Enum representing all supported website types with their corresponding icons and display names.
 * This enum provides a centralized way to manage website icons and can be used in IconSelector.
 * 
 * Note: Resource IDs are provided by the consuming application through IRKitResourceProvider
 */
enum class SupportedWebSites(val icon: String, val displayName: String, val drawableName: String) {
    WEB("web", "Default", "link_default"),
    FACEBOOK("facebook", "Facebook", "link_facebook"),
    TWITTER("twitter", "X", "link_twitter"),
    INSTAGRAM("instagram", "Instagram", "link_instagram"),
    YOUTUBE("youtube", "YouTube", "link_youtube"),
    TIKTOK("tiktok", "TikTok", "link_tiktok"),
    LINKEDIN("linkedin", "LinkedIn", "link_linkedin"),
    APPSTORE("appstore", "App Store", "link_appstore"),
    AMAZON("amazon", "Amazon", "link_amazon"),
    VIMEO("vimeo", "Vimeo", "link_vimeo");

    /**
     * Gets the icon identifier string.
     * @return The icon identifier used in the backend
     */
    fun getIconIdentifier(): String = icon

    /**
     * Gets the drawable resource name that can be used to look up the actual resource ID
     * in the consuming application.
     * @return The drawable resource name
     */
    fun getDrawableResourceName(): String = drawableName

    companion object {
        /**
         * Returns an array of all supported websites.
         * @return Array of all SupportedWebSites enum values
         */
        fun getAllWebsites(): Array<SupportedWebSites> = values()

        /**
         * Returns a list of all supported websites.
         * @return List of all SupportedWebSites enum values
         */
        fun getAllWebsitesList(): List<SupportedWebSites> = values().toList()

        /**
         * Finds a website by its icon identifier.
         * @param icon The icon identifier to search for
         * @return The matching SupportedWebSites enum value, or WEB as default if not found
         */
        fun fromIconIdentifier(icon: String?): SupportedWebSites {
            return values().find { it.icon == icon } ?: WEB
        }

        /**
         * Gets the default website (WEB).
         * @return The default SupportedWebSites enum value
         */
        fun getDefault(): SupportedWebSites = WEB
    }
}

/**
 * Data class representing an icon item for use in IconSelector. This matches the existing IconItem
 * structure used in the codebase.
 */
data class IconItem(val iconResId: Int, val text: String)

/**
 * Interface for providing resource IDs from the consuming application.
 * This allows the library to be decoupled from specific resource IDs.
 */
interface IRKitResourceProvider {
    /**
     * Get the resource ID for a drawable by name
     * @param drawableName The name of the drawable resource
     * @return The resource ID, or 0 if not found
     */
    fun getDrawableResourceId(drawableName: String): Int
    
    /**
     * Convert SupportedWebSites to IconItems using the consuming app's resources
     * @return List of IconItem objects with proper resource IDs
     */
    fun websitesToIconItems(): List<IconItem> {
        return SupportedWebSites.values().map { website -> 
            IconItem(getDrawableResourceId(website.drawableName), website.displayName) 
        }
    }
}

/**
 * Extension function to get resource ID for a website using resource provider
 */
fun SupportedWebSites.getIconResId(resourceProvider: IRKitResourceProvider): Int {
    return resourceProvider.getDrawableResourceId(this.drawableName)
}