package com.irdb.analytics

import kotlin.time.Duration
import kotlin.time.Duration.Companion.seconds

/**
 * Configuration for the analytics module.
 * All configuration is provided by the app using the library.
 */
data class AnalyticsConfig(
    // API configuration (REQUIRED - provided by app)
    val apiEndpoint: String,                      // e.g., "https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_44/Statistics"
    val apiKey: String,                            // SDK API key (different per app)
    val apiKeyHeaderName: String = "sdkapikey",    // Header name for API key

    // Company name (REQUIRED - used to build sessionSource dynamically)
    val companyName: String,                       // e.g., "irdb", "ksl"
                                                   // sessionSource is built as "Android-{companyName}-{bucketName}"

    // Bucket name (REQUIRED - provided by app)
    //
    // `var` (not `val`) because IRKitUI rewrites this from the /lenses
    // response's `primaryCollection` once the lens opens. /lenses is deferred
    // to lens-open to keep app startup REST-free, so the real value isn't
    // available at SDK init time.
    //
    // IMPORTANT: do NOT use `AnalyticsConfig.copy()` to snapshot/diff this
    // class. `bucketName` is mutable, so two `copy()`s taken at different
    // times compare equal under data-class equality (which operates on the
    // current field values, not snapshot semantics). Update only via
    // [AnalyticsClient.setBucketName] — it also persists the value to
    // UserPreferences so the next launch starts with the correct bucket.
    var bucketName: String = "irdbMain",

    // IR Engine base URL (REQUIRED - for constructing imageUrlOfScan)
    val irEngineBaseUrl: String = "",              // e.g., "https://production.backend.irdb.com/v1"

    // Device information (OPTIONAL - library auto-detects if not provided)
    // v2.0: removed deviceCarrier, deviceIFA, deviceManufacturer, cookies
    val deviceType: String? = null,                // Auto-detected if null ("iOS", "Android", "Desktop")
    val userAgent: String? = null,                 // Auto-detected if null
    
    // Behavior flags
    val enableMocking: Boolean = false,           // Mock mode (no network calls)
    val enableDebugLogging: Boolean = false,      // Log events to LogCat
    val enableEventLogLine: Boolean = BuildConfig.DEBUG,  // Library-only: one-line per event (tag: Analytics_Log); off in release
    val autoTrackLifecycle: Boolean = true,       // Auto-track app start/stop
    val autoDetectDeviceInfo: Boolean = true,     // Auto-detect device fields from OS
    
    // Batching configuration
    // flushInterval defaults to 1s so events appear on the server within
    // ~1s of occurring. The short interval still coalesces rapid-fire
    // scan bursts into a single POST (natural debounce) without making
    // events feel delayed to the analytics team tailing the server.
    val flushInterval: Duration = 1.seconds,      // Auto-flush interval
    val maxBatchSize: Int = 20,                   // Max events per batch
    val maxQueueSize: Int = 100,                  // Max events in queue
    
    // Cache/Persistence configuration
    val enableCaching: Boolean = true,            // Persist events to disk
    val cacheRetentionPolicy: CacheRetentionPolicy = CacheRetentionPolicy.CLEAR_ON_SUCCESS,
    val maxCacheAgeHours: Int = 24,              // Max age for cached events (dev mode)
    val maxCacheSize: Int = 1000,                // Max cached events
    
    // Network configuration
    val connectTimeout: Duration = 10.seconds,
    val readTimeout: Duration = 30.seconds,
    val writeTimeout: Duration = 30.seconds,
    val retryOnFailure: Boolean = true,
    val maxRetries: Int = 3,
    val autoSyncOnConnectivity: Boolean = true,  // Auto-sync when connection restored
    
    // Rate limiting configuration
    val rateLimitBaseDelay: Duration = 1.seconds,      // Base delay for exponential backoff
    val rateLimitMaxDelay: Duration = 60.seconds,      // Maximum delay between retries
    val rateLimitMaxRetries: Int = 5,                  // Max retries for rate-limited requests
    val respectRetryAfterHeader: Boolean = true,        // Respect Retry-After header from server
    
    // Custom headers
    val customHeaders: Map<String, String> = emptyMap()
)

/**
 * Cache retention policy
 */
enum class CacheRetentionPolicy {
    CLEAR_ON_SUCCESS,     // Production: Clear immediately after successful send
    KEEP_FOR_DEBUG        // Dev: Keep for maxCacheAgeHours for inspection
}

