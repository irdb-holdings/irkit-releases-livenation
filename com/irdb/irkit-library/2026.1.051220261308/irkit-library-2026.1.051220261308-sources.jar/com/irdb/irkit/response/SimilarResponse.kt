package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName
import com.irdb.irkit.dto.ImageDto

data class SimilarResponse(

    @SerializedName("ImageAlreadyExists")
    val imageAlreadyExists: Boolean = false,

    @SerializedName("Images")
    val images: List<ImageDto> = emptyList()
)
