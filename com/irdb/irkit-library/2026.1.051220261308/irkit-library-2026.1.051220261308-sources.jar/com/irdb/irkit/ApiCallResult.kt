package com.irdb.irkit

data class ApiCallResult<T>(
    var payload: T? = null,
    var succeeded: Boolean = false,
    var isUnauthorizedAccess: Boolean = false,
    var hasTimedOut: Boolean = false,
    var noNetworkConnection: Boolean = false,
    var url: String = "",
    var httpStatusCode: Int = 200,
    var errorMessage: String? = null,
    var errorCode: Int? = null,
    var gcrLog: String? = null
)
