package com.irdb.analytics

import android.util.Log

/**
 * Logger for analytics events and debugging.
 * Provides colored LogCat output and conditional logging based on config flags.
 */
internal class AnalyticsLogger(
    private val config: AnalyticsConfig
) {
    private val tag = "IRKit-Analytics"
    private val tagParms = "Analytics-Params"

    /** Tag for one-line event log; filter logcat by this to see event stream for doc comparison. */
    private val eventLogTag = "Analytics_Log"

    /**
     * Log a single line per event when [AnalyticsConfig.enableEventLogLine] is true.
     * Format: eventType + key subtypes (e.g. "status sessionStarted", "scan live matched").
     */
    fun logEventOneLine(eventName: String, parameters: Map<String, Any?>) {
        if (!config.enableEventLogLine) return
        val line = buildEventSummary(eventName, parameters)
        Log.d(eventLogTag, line)
    }

    private fun buildEventSummary(eventName: String, parameters: Map<String, Any?>): String {
        return when (eventName) {
            "status" -> {
                val statusType = parameters["statusType"]?.toString() ?: "?"
                "status $statusType"
            }
            "scan" -> {
                val scanType = parameters["scanType"]?.toString() ?: "?"
                val matched = parameters["matched"] as? Boolean
                val failed = parameters["failed"] as? Boolean == true
                val hasButtonSource = parameters.containsKey("buttonSource")
                val hasImageUrlOfScan = parameters.containsKey("imageUrlOfScan")
                val isSubmission = hasButtonSource && hasImageUrlOfScan
                val suffix = when {
                    failed -> "failed"
                    matched == true -> "matched"
                    isSubmission -> "submitted"
                    else -> "noMatch"
                }
                "scan $scanType $suffix"
            }
            "view" -> {
                val viewType = parameters["viewType"]?.toString() ?: "?"
                val viewSource = parameters["viewSource"]?.toString() ?: "?"
                "view $viewType $viewSource"
            }
            "buttonPressed" -> {
                val buttonType = parameters["buttonType"]?.toString() ?: "?"
                val buttonSource = parameters["buttonSource"]?.toString() ?: "?"
                "buttonPressed $buttonType $buttonSource"
            }
            else -> eventName + (parameters["statusType"]?.toString()?.let { " $it" } ?: "")
        }
    }
    
    fun logEvent(eventName: String, parameters: Map<String, Any?>) {
        if (config.enableDebugLogging) {
            // Add special handling for scan events to make "not recognized" more explicit
            val matched = parameters["matched"] as? Boolean
            val failed = parameters["failed"] as? Boolean == true
            
            // Distinguish between "Scan Submitted" and "Scan Result — No Match" events
            // Submission events have buttonSource and imageUrlOfScan
            // Result events have trackingId and similarCount but no buttonSource
            val hasButtonSource = parameters.containsKey("buttonSource")
            val hasImageUrlOfScan = parameters.containsKey("imageUrlOfScan")
            val isSubmissionEvent = hasButtonSource && hasImageUrlOfScan
            
            val isNotRecognized = eventName == "scan" && matched == false && !failed && !isSubmissionEvent
            
            val mockPrefix = if (config.enableMocking) "[MOCK] " else ""
            
            if (isNotRecognized) {
                Log.d(tagParms, "🔵 $mockPrefix Event: $eventName (❌ Image NOT RECOGNIZED)")
            } else if (isSubmissionEvent && matched == false) {
                Log.d(tagParms, "🔵 $mockPrefix Event: $eventName (📤 Scan Submitted)")
            } else {
                Log.d(tagParms, "🔵 $mockPrefix Event: $eventName")
            }
            Log.d(tagParms, "📦 Parameters:")
            // v2.1: locationLat/locationLng ride in the JSON body
            parameters.forEach { (key, value) ->
                val displayValue = value?.toString() ?: "null"
                Log.d(tagParms, "  • $key: $displayValue")
            }
            Log.d(tagParms, "─".repeat(50))
        }
    }
    
    fun logDebug(message: String) {
        if (config.enableDebugLogging) {
            Log.d(tag, message)
        }
    }
    
    fun logError(message: String, throwable: Throwable? = null) {
        Log.e(tag, "❌ $message", throwable)
    }
    
    fun logNetworkCall(endpoint: String, payload: String) {
        if (config.enableDebugLogging) {
            Log.d(tag, "📡 POST $endpoint")
            Log.d(tag, "📤 Payload: $payload")
        }
    }

    /**
     * Log the HTTP request headers attached to a /Statistics POST so capture
     * tooling can hand them to the backend team alongside the body. Keys with
     * "key", "token", "secret", or "auth" in their name are masked to first8…last8
     * to avoid leaking credentials into shared logs.
     */
    fun logNetworkHeaders(headers: Map<String, String>) {
        if (!config.enableDebugLogging) return
        val sensitive = Regex("(?i)key|token|secret|auth")
        val rendered = headers.entries.joinToString(", ") { (k, v) ->
            val displayed = if (sensitive.containsMatchIn(k) && v.length > 16) {
                v.substring(0, 8) + "…" + v.substring(v.length - 8)
            } else {
                v
            }
            "$k=$displayed"
        }
        Log.d(tag, "📋 Headers: {$rendered}")
    }

    fun logNetworkResponse(statusCode: Int, response: String) {
        if (config.enableDebugLogging) {
            Log.d(tag, "📥 Response [$statusCode]: $response")
        }
    }
}

