/**
 * Data Transfer Objects for API communication.
 * 
 * This package will contain:
 * - ImageDto and related DTOs
 * - Request/response data classes
 * - Gson type adapters
 * - Serialization configurations
 */
package com.irdb.irkit.dto