package com.irdb.irkitui.ui.baseComponents

import android.content.res.Configuration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.irdb.irkitui.theme.AddCustomFieldButtonBackgroundColor
import com.irdb.irkitui.theme.AddCustomFieldButtonIconColor
import com.irdb.irkitui.theme.AddCustomFieldButtonTextColor
import com.irdb.irkitui.theme.IRKitUITheme

object AddCustomFieldButtonDimens {
    val iconPadding = 10.dp
    val textHorizontalPadding = 8.dp
    val textVerticalPadding = 10.dp
    val fontSize = 16.sp
    val previewSpacing = 8.dp
    val previewPadding = 8.dp
}

@Composable
fun AddCustomFieldButton(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    labelOverride: String? = null,
    showIcon: Boolean = true,
    // For library usage, labelText will need to be provided externally
    labelText: String? = null,
    // Icon will need to be provided externally for library usage
    icon: ImageVector? = null
) {
    val buttonLabelText = labelOverride ?: labelText ?: "Add Custom Field"

    ShadowButton(
        modifier = modifier
            .fillMaxWidth()
            .wrapContentHeight(),
        onClick = onClick,
        backgroundColor = AddCustomFieldButtonBackgroundColor
    ) {
        if (showIcon && icon != null) {
            Icon(
                imageVector = icon,
                contentDescription = buttonLabelText,
                tint = AddCustomFieldButtonIconColor,
                modifier = Modifier.padding(AddCustomFieldButtonDimens.iconPadding)
            )
        }

        Text(
            text = buttonLabelText,
            style = MaterialTheme.typography.titleMedium,
            color = AddCustomFieldButtonTextColor,
            modifier = Modifier.padding(
                horizontal = AddCustomFieldButtonDimens.textHorizontalPadding,
                vertical = AddCustomFieldButtonDimens.textVerticalPadding
            )
        )
    }
}

@Preview(showBackground = true)
@Composable
fun AddCustomFieldButtonPreview() {
    IRKitUITheme {
        Column(
            verticalArrangement = Arrangement.spacedBy(AddCustomFieldButtonDimens.previewSpacing),
            modifier = Modifier.padding(AddCustomFieldButtonDimens.previewPadding)
        ) {
            AddCustomFieldButton(
                onClick = { },
                labelText = "Add Custom Field",
                icon = null
            )

            AddCustomFieldButton(
                onClick = { },
                labelOverride = "Add Custom Field",
                showIcon = false,
                labelText = null,
                icon = null
            )
        }
    }
}

@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
fun AddCustomFieldButtonDarkPreview() {
    IRKitUITheme(darkTheme = true) {
        Column(
            verticalArrangement = Arrangement.spacedBy(AddCustomFieldButtonDimens.previewSpacing),
            modifier = Modifier.padding(AddCustomFieldButtonDimens.previewPadding)
        ) {
            AddCustomFieldButton(
                onClick = { },
                labelText = "Add Custom Field",
                icon = null
            )

            AddCustomFieldButton(
                onClick = { },
                labelOverride = "Add Custom Field",
                showIcon = false,
                labelText = null,
                icon = null
            )
        }
    }
}
