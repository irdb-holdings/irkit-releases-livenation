package com.irdb.irkit

import android.util.Log
import com.irdb.irkit.dto.ImageDto
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.dto.MetaContent.CardType
import com.irdb.irkit.dto.ParsedMetaItem
import com.irdb.irkit.dto.ProductInCampaignDto
import com.irdb.irkit.dto.UserDto
import com.irdb.irkit.dto.getMetaContentByType
import com.irdb.irkit.dto.parseMetaItems
import com.irdb.irkit.enums.CardTypes
import com.irdb.irkit.enums.ImageStatus
import com.irdb.irkit.enums.MetaTypes
import com.irdb.irkit.extensions.extractValueFromParentheses
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Date


sealed class ImageModel {
    abstract val imageId: String
    abstract val bucketName: String
    abstract val trackingId: String
    abstract val title: String
    abstract val description: String
    abstract val displayImageUrl: String
    abstract val campaignId: Int
    abstract val campaignName: String?
    abstract val products: List<ProductInCampaignDto>
    abstract val metaItems: List<ParsedMetaItem>
    abstract val location: Location?
    abstract var save: Boolean
    open val line1: String = ""
    open val line2: String = ""
    open val imageUser: UserDto? = null

    lateinit var status: ImageStatus
    var cropped: Boolean = false // if the image was cropped during initial registration, used for double checks
    var timeTheImageWasScanned: Long = 0 // what time the original image was scanned, used for double checks, in millis

    var fromDeepLink = false

    override fun toString(): String {
        return buildString {
            appendLine("ImageModel [${this@ImageModel::class.simpleName}]")
            appendLine("├─ Image ID: $imageId")
            appendLine("├─ Title: ${title.ifEmpty { "N/A" }}")
            appendLine("├─ Description: ${description.ifEmpty { "N/A" }}")
            appendLine("├─ Bucket: ${bucketName.ifEmpty { "N/A" }}")
            appendLine("├─ Tracking ID: ${trackingId.ifEmpty { "N/A" }}")
            appendLine("├─ Campaign ID: $campaignId")
            appendLine("├─ Campaign Name: ${campaignName ?: "N/A"}")
            appendLine("├─ Display URL: ${displayImageUrl.ifEmpty { "N/A" }}")
            appendLine("├─ Line1: ${line1.ifEmpty { "N/A" }}")
            appendLine("├─ Line2: ${line2.ifEmpty { "N/A" }}")
            appendLine("├─ Status: $status")
            appendLine("├─ Saved: $save")
            appendLine("├─ Cropped: $cropped")
            appendLine("├─ From Deep Link: $fromDeepLink")

            if (timeTheImageWasScanned > 0) {
                appendLine("├─ Scan Time: ${Date(timeTheImageWasScanned)}")
            }

            location?.let { loc ->
                appendLine("├─ Location: (${loc.latitude}, ${loc.longitude})")
            }

            imageUser?.let { user ->
                appendLine("├─ User: $user")
            }

            if (products.isNotEmpty()) {
                appendLine("├─ Products (${products.size}):")
                products.forEachIndexed { index, product ->
                    appendLine("│  ${index + 1}. $product")
                }
            }

            if (metaItems.isNotEmpty()) {
                appendLine("├─ Meta Items (${metaItems.size}):")
                metaItems.forEachIndexed { index, item ->
                    appendLine("│  ${index + 1}. ${item.metaType}: content=${item.content}, contentArray=${item.contentArray}, order=${item.order}")
                }
            }

            // Add subtype-specific information
            when (this@ImageModel) {
                is FullImage -> {
                    appendLine("├─ Image Dimensions: ${imageWidth}x$imageHeight")
                    appendLine("├─ Image Size: $imageSize bytes")
                    appendLine("├─ Manual Capture: $isFromManualCapture")
                    appendLine("├─ Count Views: $countViews")
                    appendLine("├─ Count Saved: $countSaved")
                    appendLine("├─ Count Comments: $countComments")
                    appendLine("├─ Count Similar: $countSimilar")
                    appendLine("├─ Image Status: $imageStatus")
                }
                is RecognizedByAI -> {
                    appendLine("├─ AI Recognition: true")
                }
                is Placeholder -> {
                    appendLine("├─ Type: Placeholder")
                }
                is NotRecognized -> {
                    appendLine("├─ Type: Not Recognized")
                }
            }

            // Add computed properties
            appendLine("├─ getImageTitle(): ${getImageTitle().ifEmpty { "N/A" }}")
            appendLine("├─ Show Smart View: $showSmartView")
            appendLine("├─ Show in Chrome Tab: $showInChromeTab")
            appendLine("├─ Card Type: ${getCardType()}")
            appendLine("├─ Artist Name: ${getArtistName()}")

            getLinks()?.let { link ->
                appendLine("├─ Link URL: ${link.url}")
                appendLine("├─ Link Open in New Window: ${link.openInNewWindow}")
                appendLine("├─ Link Private Details: ${link.privateDetails}")
                appendLine("├─ Link On Scan Display: ${link.onScanDisplay}")
            }

            append("└─ End ImageModel")
        }
    }

    fun getImageTags(): String {
        val item = metaItems.find { it.metaTypeEnum == MetaTypes.Tags }
        val title = item?.content?.toString() ?: ""
        return title.extractValueFromParentheses()
    }

    fun getImageTitle(): String {
        val item = metaItems.find { it.metaTypeEnum == MetaTypes.Title }
        val title = item?.content?.toString() ?: ""
        val metaTitle = title.extractValueFromParentheses()
        // Fall back to line1 if meta title is empty (matches iOS behavior)
        return metaTitle.ifEmpty { line1 }
    }

    fun getArtistName(): String {
        val item = metaItems.find { it.metaTypeEnum == MetaTypes.ArtistName }
        val title = item?.content?.toString() ?: ""
        return title.extractValueFromParentheses()
    }

    fun getMetaTypeValue(metaType: MetaTypes): String {
        val item = metaItems.find { it.metaTypeEnum == metaType }
        val itemString = item?.content?.toString() ?: ""
        return itemString.extractValueFromParentheses()
    }

    fun getLinks(): MetaContent.Link? {
        return metaItems.find { it.metaTypeEnum() == MetaTypes.Link }?.content as? MetaContent.Link
    }

    fun getArtist(): MetaContent.Link? {
        return metaItems.find { it.metaTypeEnum() == MetaTypes.ArtistName }?.content as? MetaContent.Link
    }

    val showSmartView: Boolean
        get() {
            val links = getLinks()
//            return links?.let {
//                !it.openInNewWindow &&
//                    !it.privateDetails
//                it.onScanDisplay
//            } ?: false

            return links?.let { it.onScanDisplay && !it.openInNewWindow && !it.privateDetails } ?: false
        }

    val showInChromeTab: Boolean
        get() {
            val links = getLinks()
            return links?.let { it.openInNewWindow && it.url.isNotEmpty() } ?: false
        }

    val isScanToSite: Boolean
        get() = showSmartView || showInChromeTab

    fun getMetaItemForType(searchString: String): ParsedMetaItem? {
        return metaItems.find { it.metaType == searchString }
    }

    data class Placeholder(override val imageId: String) : ImageModel() {
        override val title: String = ""
        override val bucketName: String = ""
        override val trackingId: String = ""
        override val description: String = ""
        override val displayImageUrl: String = ""
        override val campaignId: Int = 0
        override val campaignName: String = ""
        override val products: List<ProductInCampaignDto> = emptyList()
        override val metaItems: List<ParsedMetaItem> = emptyList()
        override val location: Location? = null
        override var save: Boolean = false

        init {
            status = ImageStatus.PUBLISH
        }
    }

    data class NotRecognized(override val imageId: String) : ImageModel() {
        override val title: String = ""
        override val bucketName: String = ""
        override val trackingId: String = ""
        override val description: String = ""
        override val displayImageUrl: String = ""
        override val campaignId: Int = 0
        override val campaignName: String = ""
        override val products: List<ProductInCampaignDto> = emptyList()
        override val metaItems: List<ParsedMetaItem> = emptyList()
        override val location: Location? = null
        override var save: Boolean = false

        init {
            status = ImageStatus.PUBLISH
        }
    }

    data class RecognizedByAI(
        override val imageId: String,
        override val description: String
    ) : ImageModel() {
        override val title: String = "AI Recognition"
        override val bucketName: String = ""
        override val trackingId: String = ""
        override val displayImageUrl: String = ""
        override val campaignId: Int = 0
        override val campaignName: String = ""
        override val products: List<ProductInCampaignDto> = emptyList()
        override val metaItems: List<ParsedMetaItem> = emptyList()
        override val location: Location? = null
        override var save: Boolean = false

        init {
            status = ImageStatus.PUBLISH
        }
    }

    data class FullImage(
        override val imageId: String,
        override val bucketName: String,
        override val trackingId: String,
        override val title: String,
        override val description: String,
        override var displayImageUrl: String,
        override val campaignId: Int,
        override val campaignName: String,
        override val products: List<ProductInCampaignDto>,
        override val metaItems: List<ParsedMetaItem>,
        override val location: Location?,
        override val imageUser: UserDto? = null,
        override var save: Boolean = false,
        override val line1: String = "",
        override val line2: String = "",
        val imageWidth: Int,
        val imageHeight: Int,
        val imageSize: Int,
        val isFromManualCapture: Boolean = false,
        val countSaved: Int = 0,
        val countViews: Int = 0,
        val countComments: Int = 0,
        val countSimilar: Int = 0,
        val imageStatus: ImageStatus
    ) : ImageModel() {
        init {
            status = imageStatus
        }
    }




    companion object {
        suspend fun fetchImage(imageId: String, trackingId: String, bucketName: String): ImageModel? {
            return withContext(Dispatchers.IO) {
                try {
                    val response = getImage(imageId)
                    fromImageDto(response, trackingId, bucketName, isFromManualCapture = false)
                } catch (e: Exception) {
                    Log.e("network", e.toString())
                    null
                }
            }
        }

        fun fromImageDto(dto: ImageDto, trackingId: String, bucketName: String, isFromManualCapture: Boolean = false): FullImage {
            if (BackendService.isDebugMode()) {
                Log.d("IRCODE_FIELDS", "===== RAW ImageDto FIELDS =====")
                Log.d("IRCODE_FIELDS", "imageId: ${dto.imageId}")
                Log.d("IRCODE_FIELDS", "title: '${dto.title}'")
                Log.d("IRCODE_FIELDS", "line1: '${dto.line1}'")
                Log.d("IRCODE_FIELDS", "line2: '${dto.line2}'")
                Log.d("IRCODE_FIELDS", "imageUrl: ${dto.imageUrl}")
                Log.d("IRCODE_FIELDS", "displayImageUrl: ${dto.displayImageUrl}")
                Log.d("IRCODE_FIELDS", "assetDisplayImage: ${dto.assetDisplayImage}")
                Log.d("IRCODE_FIELDS", "assetUrl: ${dto.assetUrl}")
                Log.d("IRCODE_FIELDS", "assetID: ${dto.assetID}")
                Log.d("IRCODE_FIELDS", "webUrl: ${dto.webUrl}")
                Log.d("IRCODE_FIELDS", "nativeUrl: ${dto.nativeUrl}")
                Log.d("IRCODE_FIELDS", "imageStatus: ${dto.imageStatus}")
                Log.d("IRCODE_FIELDS", "campaignId: ${dto.campaignId}")
                Log.d("IRCODE_FIELDS", "campaignName: ${dto.campaignName}")
                Log.d("IRCODE_FIELDS", "specialType: ${dto.specialType}")
                Log.d("IRCODE_FIELDS", "imageUserId: ${dto.imageUserId}")
                Log.d("IRCODE_FIELDS", "imageUser: ${dto.imageUser}")
                Log.d("IRCODE_FIELDS", "latitude: ${dto.latitude}, longitude: ${dto.longitude}")
                Log.d("IRCODE_FIELDS", "imageWidth: ${dto.imageWidth}, imageHeight: ${dto.imageHeight}, imageSize: ${dto.imageSize}")
                Log.d("IRCODE_FIELDS", "countViews: ${dto.countViews}, countSaved: ${dto.countSaved}, countComments: ${dto.countComments}, countSimilar: ${dto.countSimilar}")
                Log.d("IRCODE_FIELDS", "metaArray (${dto.metaArray.size} items):")
                dto.metaArray.forEachIndexed { index, meta ->
                    Log.d("IRCODE_FIELDS", "  meta[$index]: type='${meta.metaType}', content=${meta.metaContent}")
                }
                Log.d("IRCODE_FIELDS", "productsArray: ${dto.productsArray?.size ?: 0} items")
                Log.d("IRCODE_FIELDS", "===== END RAW ImageDto =====")
            }

            return FullImage(
                imageId = dto.imageId,
                bucketName = bucketName,
                trackingId = trackingId,
                title = dto.getMetaContentByType<MetaContent.Title>("Title")?.value ?: "",
                description = dto.getMetaContentByType<MetaContent.Description>("Description")?.value ?: "",
                displayImageUrl = dto.assetDisplayImage ?: dto.displayImageUrl ?: dto.imageUrl ?: "",
                campaignId = dto.campaignId,
                campaignName = dto.campaignName ?: "",
                products = dto.products,
                metaItems = dto.parseMetaItems(),
                location = if (dto.latitude != 0.0 && dto.longitude != 0.0) {
                    Location(dto.latitude, dto.longitude)
                } else {
                    null
                },
                imageWidth = dto.imageWidth,
                imageHeight = dto.imageHeight,
                imageSize = dto.imageSize,
                isFromManualCapture = isFromManualCapture,
                imageUser = dto.imageUser,
                save = dto.save,
                line1 = dto.line1 ?: "",
                line2 = dto.line2 ?: "",
                countSaved = dto.countSaved ?: 0,
                countViews = dto.countViews ?: 0,
                countComments = dto.countComments ?: 0,
                countSimilar = dto.countSimilar ?: 0,
                imageStatus = when ((dto.imageStatus as String?)?.lowercase() ?: "publish") {
                    "draft" -> ImageStatus.DRAFT
                    "publish" -> ImageStatus.PUBLISH
                    else -> ImageStatus.PUBLISH
                }
            )
        }
    }
}

fun ImageModel.setParams(image: ImageModel? = null): Map<String, Any> {
    val params = mutableMapOf<String, Any>()

    params["imageID"] = imageId // this is only used by update call, query and add create their own in BE
    params["imageUrl"] = displayImageUrl
    params["status"] = status.toString()
    params["cropped"] = cropped
    params["scanTime"] = timeTheImageWasScanned

    // image?.let { bitmap -> // if image is not present, then we are updating textual fields
    //     params[JSONData.imageWidth.name] = bitmap.width
    //     params[JSONData.imageHeight.name] = bitmap.height

    //     currentImage = FireBaseHelper.downSizeImageForRegistration(bitmap)
    //     params[JSONData.imageSize.name] = currentImage.size
    // }

    // // If you are running in beta and you do not set bucket, it defaults to irdbMain
    // if (currentEnvironment == Environment.BETA && ImageModel.betaBucketName.isNotEmpty()) {
    //     params["bucket"] = ImageModel.betaBucketName // this is only available in Environment beta
    // }
    return params
}

data class Location(val latitude: Double, val longitude: Double)

// Get any meta content by type
inline fun <reified T : MetaContent> ImageModel.getMetaContent(type: String): T? {
    return metaItems.find { it.metaType == type }?.content as? T
}

// Convenience functions for common meta types

fun ImageModel.getCardType(): String {
    return getMetaContent<CardType>("CardType")?.value ?: ""
}

fun ImageModel.getCardTypeEmum(): CardTypes {
    val cardType = getMetaContent<CardType>("CardType")?.value?.lowercase() ?: ""

    when (cardType) {
        "artcard" -> return CardTypes.ArtCard
        "contact" -> return CardTypes.Contact
        "products", "productcard" -> return CardTypes.ProductCard
        "general" -> return CardTypes.General
    }
    return CardTypes.General
}

fun ImageModel.getLinks(): MetaContent.Link? = getMetaContent("Link")

fun ImageModel.getLinkArray(): List<MetaContent>? = getMetaContent("Link")

/**
 * Selects the single footer CTA link based on card type, matching iOS behavior.
 * - General/Art/Contact: LAST link where onScanDisplay == false
 * - Product: FIRST link where onScanDisplay == true, else FIRST where onScanDisplay == false
 * Returns null if no suitable link exists (meaning no CTA should be shown).
 */
fun ImageModel.getFooterCTALink(): MetaContent.Link? {
    val allLinks = metaItems.find { it.metaTypeEnum() == MetaTypes.Link }
        ?.contentArray?.filterIsInstance<MetaContent.Link>()
        ?: return null

    return when (getCardTypeEmum()) {
        CardTypes.ProductCard -> {
            allLinks.firstOrNull { it.onScanDisplay }
                ?: allLinks.firstOrNull { !it.onScanDisplay }
        }
        else -> allLinks.lastOrNull { !it.onScanDisplay }
    }
}

fun ImageModel.getTags(): List<String> = getMetaContent<MetaContent.Tags>("Tags")?.tags ?: emptyList()

fun ImageModel.getEmbeddedVideo(): String? = getMetaContent<MetaContent.EmbeddedVideo>("EmbeddedVideo")?.videoUrl

fun ImageModel.getCustomContent(): Map<String, Any>? = getMetaContent<MetaContent.Custom>("Custom")?.data
