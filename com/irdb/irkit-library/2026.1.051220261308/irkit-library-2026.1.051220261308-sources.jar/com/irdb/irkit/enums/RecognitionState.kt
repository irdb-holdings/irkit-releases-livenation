package com.irdb.irkit.enums

enum class RecognitionState(val text: String) {
    ACTIVE("Active"),
    PAUSED("Paused");
    override fun toString(): String = text
}