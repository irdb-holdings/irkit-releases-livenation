package com.irdb.analytics

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.irdb.analytics.models.CacheStats
import com.irdb.analytics.models.EventPayload
import com.irdb.analytics.models.SendStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Disk persistence for analytics events using SQLite (built into Android).
 * Provides offline support and debugging capabilities.
 * Handles thousands of events efficiently.
 */
internal class AnalyticsCache(
    private val context: Context,
    private val config: AnalyticsConfig,
    private val logger: AnalyticsLogger
) {
    private val dbHelper = AnalyticsDatabaseHelper(context)
    private val gson = Gson()
    
    /**
     * Save events to database
     */
    suspend fun saveEvents(events: List<EventPayload>) = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        try {
            db.beginTransaction()
            try {
                events.forEach { event ->
                    // CRITICAL: Only serialize parameters, not the entire EventPayload
                    // The entire event object includes metadata (id, attemptCount, etc.) that shouldn't be in parameters
                    val parametersJson = gson.toJson(event.parameters)
                    db.insert(
                        AnalyticsDatabaseHelper.TABLE_EVENTS,
                        null,
                        android.content.ContentValues().apply {
                            put(AnalyticsDatabaseHelper.COLUMN_ID, event.id)
                            put(AnalyticsDatabaseHelper.COLUMN_EVENT_NAME, event.eventName)
                            put(AnalyticsDatabaseHelper.COLUMN_TIMESTAMP, event.timestamp)
                            put(AnalyticsDatabaseHelper.COLUMN_PARAMETERS, parametersJson)
                            put(AnalyticsDatabaseHelper.COLUMN_SENT_AT, event.sentAt)
                            put(AnalyticsDatabaseHelper.COLUMN_ATTEMPT_COUNT, event.attemptCount)
                            put(AnalyticsDatabaseHelper.COLUMN_LAST_ATTEMPT_AT, event.lastAttemptAt)
                            put(AnalyticsDatabaseHelper.COLUMN_SEND_STATUS, event.sendStatus.name)
                        }
                    )
                }
                
                // Enforce max cache size
                val totalCount = getTotalEventCount(db)
                if (totalCount > config.maxCacheSize) {
                    val excess = totalCount - config.maxCacheSize
                    // Delete oldest events - get IDs first, then delete
                    val cursor = db.rawQuery(
                        "SELECT ${AnalyticsDatabaseHelper.COLUMN_ID} FROM ${AnalyticsDatabaseHelper.TABLE_EVENTS} " +
                                "ORDER BY ${AnalyticsDatabaseHelper.COLUMN_TIMESTAMP} ASC LIMIT ?",
                        arrayOf(excess.toString())
                    )
                    val idsToDelete = mutableListOf<String>()
                    cursor.use {
                        while (it.moveToNext()) {
                            idsToDelete.add(it.getString(0))
                        }
                    }
                    if (idsToDelete.isNotEmpty()) {
                        val placeholders = idsToDelete.joinToString(",") { "?" }
                        db.execSQL(
                            "DELETE FROM ${AnalyticsDatabaseHelper.TABLE_EVENTS} WHERE ${AnalyticsDatabaseHelper.COLUMN_ID} IN ($placeholders)",
                            idsToDelete.toTypedArray()
                        )
                    }
                }
                
                db.setTransactionSuccessful()
                logger.logDebug("💾 Cached ${events.size} events to database")
            } finally {
                db.endTransaction()
            }
        } catch (e: Exception) {
            logger.logError("Failed to save events to cache", e)
        }
        // Note: Do NOT close db - SQLiteOpenHelper manages the connection pool
    }
    
    /**
     * Load all cached events
     */
    suspend fun loadEvents(): List<EventPayload> = withContext(Dispatchers.IO) {
        loadEventsSync()
    }
    
    /**
     * Get count of pending/failed events (excluding SUCCESS).
     * Lightweight COUNT query for performance optimization.
     */
    suspend fun getPendingEventCount(): Int = withContext(Dispatchers.IO) {
        val db = dbHelper.readableDatabase
        return@withContext try {
            val cursor = db.rawQuery(
                "SELECT COUNT(*) FROM ${AnalyticsDatabaseHelper.TABLE_EVENTS} WHERE ${AnalyticsDatabaseHelper.COLUMN_SEND_STATUS} != ?",
                arrayOf(SendStatus.SUCCESS.name)
            )
            cursor.use {
                if (it.moveToFirst()) {
                    it.getInt(0)
                } else {
                    0
                }
            }
        } catch (e: Exception) {
            logger.logError("Failed to get pending event count", e)
            0
        }
    }
    
    private fun loadEventsSync(): List<EventPayload> {
        val db = dbHelper.readableDatabase
        return try {
            val cursor = db.query(
                AnalyticsDatabaseHelper.TABLE_EVENTS,
                null,
                null,
                null,
                null,
                null,
                "${AnalyticsDatabaseHelper.COLUMN_TIMESTAMP} ASC"
            )
            
            val events = mutableListOf<EventPayload>()
            cursor.use {
                while (it.moveToNext()) {
                    try {
                        val id = it.getString(it.getColumnIndexOrThrow(AnalyticsDatabaseHelper.COLUMN_ID))
                        val eventName = it.getString(it.getColumnIndexOrThrow(AnalyticsDatabaseHelper.COLUMN_EVENT_NAME))
                        val timestamp = it.getLong(it.getColumnIndexOrThrow(AnalyticsDatabaseHelper.COLUMN_TIMESTAMP))
                        val parametersJson = it.getString(it.getColumnIndexOrThrow(AnalyticsDatabaseHelper.COLUMN_PARAMETERS))
                        val sentAt = if (it.isNull(it.getColumnIndexOrThrow(AnalyticsDatabaseHelper.COLUMN_SENT_AT))) {
                            null
                        } else {
                            it.getLong(it.getColumnIndexOrThrow(AnalyticsDatabaseHelper.COLUMN_SENT_AT))
                        }
                        val attemptCount = it.getInt(it.getColumnIndexOrThrow(AnalyticsDatabaseHelper.COLUMN_ATTEMPT_COUNT))
                        val lastAttemptAt = if (it.isNull(it.getColumnIndexOrThrow(AnalyticsDatabaseHelper.COLUMN_LAST_ATTEMPT_AT))) {
                            null
                        } else {
                            it.getLong(it.getColumnIndexOrThrow(AnalyticsDatabaseHelper.COLUMN_LAST_ATTEMPT_AT))
                        }
                        val sendStatusStr = it.getString(it.getColumnIndexOrThrow(AnalyticsDatabaseHelper.COLUMN_SEND_STATUS))
                        
                        val parameters = parseParameters(parametersJson)
                        val sendStatus = SendStatus.valueOf(sendStatusStr)
                        
                        events.add(
                            EventPayload(
                                id = id,
                                eventName = eventName,
                                timestamp = timestamp,
                                parameters = parameters,
                                sentAt = sentAt,
                                attemptCount = attemptCount,
                                lastAttemptAt = lastAttemptAt,
                                sendStatus = sendStatus
                            )
                        )
                    } catch (e: Exception) {
                        logger.logError("Failed to parse event from database", e)
                    }
                }
            }
            
            // Only log when events are actually loaded to reduce overhead
            if (events.isNotEmpty()) {
                logger.logDebug("📥 Loaded ${events.size} events from cache")
            }
            events
        } catch (e: Exception) {
            logger.logError("Failed to load events from cache", e)
            emptyList()
        }
        // Note: Do NOT close db - SQLiteOpenHelper manages the connection pool
    }
    
    /**
     * Mark events as successfully sent (for dev mode inspection)
     */
    suspend fun markAsSent(eventIds: Set<String>, sentTimestamp: Long) = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        try {
            val placeholders = eventIds.joinToString(",") { "?" }
            val args = arrayOf(sentTimestamp.toString(), SendStatus.SUCCESS.name) + eventIds.toTypedArray()
            db.execSQL(
                "UPDATE ${AnalyticsDatabaseHelper.TABLE_EVENTS} SET " +
                        "${AnalyticsDatabaseHelper.COLUMN_SENT_AT} = ?, " +
                        "${AnalyticsDatabaseHelper.COLUMN_SEND_STATUS} = ? " +
                        "WHERE ${AnalyticsDatabaseHelper.COLUMN_ID} IN ($placeholders)",
                args
            )
            logger.logDebug("✅ Marked ${eventIds.size} events as sent at ${java.util.Date(sentTimestamp)}")
        } catch (e: Exception) {
            logger.logError("Failed to mark events as sent", e)
        }
        // Note: Do NOT close db - SQLiteOpenHelper manages the connection pool
    }
    
    /**
     * Clear successfully sent events (production mode)
     */
    suspend fun clearSentEvents(sentEventIds: Set<String>) = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        try {
            val placeholders = sentEventIds.joinToString(",") { "?" }
            val deleted = db.delete(
                AnalyticsDatabaseHelper.TABLE_EVENTS,
                "${AnalyticsDatabaseHelper.COLUMN_ID} IN ($placeholders)",
                sentEventIds.toTypedArray()
            )
            logger.logDebug("🧹 Cleared $deleted sent events from cache")
        } catch (e: Exception) {
            logger.logError("Failed to clear sent events", e)
        }
        // Note: Do NOT close db - SQLiteOpenHelper manages the connection pool
    }
    
    /**
     * Clear all successfully sent events (cleanup old SUCCESS events)
     */
    suspend fun clearAllSentEvents() = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        try {
            val deleted = db.delete(
                AnalyticsDatabaseHelper.TABLE_EVENTS,
                "${AnalyticsDatabaseHelper.COLUMN_SEND_STATUS} = ?",
                arrayOf(SendStatus.SUCCESS.name)
            )
            if (deleted > 0) {
                logger.logDebug("🧹 Cleaned up $deleted old SUCCESS events from cache")
            }
        } catch (e: Exception) {
            logger.logError("Failed to clear all sent events", e)
        }
        // Note: Do NOT close db - SQLiteOpenHelper manages the connection pool
    }
    
    /**
     * Update send attempt tracking
     */
    suspend fun updateSendAttempt(eventIds: Set<String>) = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        try {
            val now = System.currentTimeMillis()
            val placeholders = eventIds.joinToString(",") { "?" }
            val args = arrayOf(now.toString(), SendStatus.SENDING.name) + eventIds.toTypedArray()
            db.execSQL(
                "UPDATE ${AnalyticsDatabaseHelper.TABLE_EVENTS} SET " +
                        "${AnalyticsDatabaseHelper.COLUMN_ATTEMPT_COUNT} = ${AnalyticsDatabaseHelper.COLUMN_ATTEMPT_COUNT} + 1, " +
                        "${AnalyticsDatabaseHelper.COLUMN_LAST_ATTEMPT_AT} = ?, " +
                        "${AnalyticsDatabaseHelper.COLUMN_SEND_STATUS} = ? " +
                        "WHERE ${AnalyticsDatabaseHelper.COLUMN_ID} IN ($placeholders)",
                args
            )
        } catch (e: Exception) {
            logger.logError("Failed to update send attempt", e)
        }
        // Note: Do NOT close db - SQLiteOpenHelper manages the connection pool
    }
    
    /**
     * Mark events as failed
     */
    suspend fun markAsFailed(eventIds: Set<String>) = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        try {
            val placeholders = eventIds.joinToString(",") { "?" }
            val args = arrayOf(SendStatus.FAILED.name) + eventIds.toTypedArray()
            db.execSQL(
                "UPDATE ${AnalyticsDatabaseHelper.TABLE_EVENTS} SET " +
                        "${AnalyticsDatabaseHelper.COLUMN_SEND_STATUS} = ? " +
                        "WHERE ${AnalyticsDatabaseHelper.COLUMN_ID} IN ($placeholders)",
                args
            )
            logger.logDebug("❌ Marked ${eventIds.size} events as failed")
        } catch (e: Exception) {
            logger.logError("Failed to mark events as failed", e)
        }
        // Note: Do NOT close db - SQLiteOpenHelper manages the connection pool
    }

    /**
     * Reset rows stuck in SENDING back to PENDING. Called once on initialize()
     * to recover from prior-session flushes that were cancelled mid-state-machine
     * (e.g. flushSync timeout fired between the network POST and clearSentEvents).
     * Server-side dedup absorbs the small number of true duplicates this can cause.
     */
    suspend fun resetStuckSendingEvents() = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        try {
            val args = arrayOf(SendStatus.PENDING.name, SendStatus.SENDING.name)
            db.execSQL(
                "UPDATE ${AnalyticsDatabaseHelper.TABLE_EVENTS} SET " +
                        "${AnalyticsDatabaseHelper.COLUMN_SEND_STATUS} = ? " +
                        "WHERE ${AnalyticsDatabaseHelper.COLUMN_SEND_STATUS} = ?",
                args
            )
        } catch (e: Exception) {
            logger.logError("Failed to reset stuck SENDING events", e)
        }
        // Note: Do NOT close db - SQLiteOpenHelper manages the connection pool
    }

    /**
     * Clear all events (for testing or reset)
     */
    suspend fun clearAll() = withContext(Dispatchers.IO) {
        val db = dbHelper.writableDatabase
        try {
            db.delete(AnalyticsDatabaseHelper.TABLE_EVENTS, null, null)
            logger.logDebug("🗑️ Cleared entire cache")
        } catch (e: Exception) {
            logger.logError("Failed to clear cache", e)
        }
        // Note: Do NOT close db - SQLiteOpenHelper manages the connection pool
    }
    
    /**
     * Get cache statistics (for dev inspection)
     */
    suspend fun getCacheStats(): CacheStats = withContext(Dispatchers.IO) {
        val db = dbHelper.readableDatabase
        return@withContext try {
            val totalEvents = getTotalEventCount(db)
            val pendingEvents = getEventCountByStatus(db, SendStatus.PENDING)
            val successEvents = getEventCountByStatus(db, SendStatus.SUCCESS)
            val failedEvents = getEventCountByStatus(db, SendStatus.FAILED)
            
            val oldestTimestamp = getOldestTimestamp(db)
            val newestTimestamp = getNewestTimestamp(db)
            val oldestSentTimestamp = getOldestSentTimestamp(db)
            val newestSentTimestamp = getNewestSentTimestamp(db)
            
            // Estimate cache size (rough calculation)
            val cacheSize = totalEvents * 500 // Rough estimate: ~500 bytes per event
            
            CacheStats(
                totalEvents = totalEvents,
                pendingEvents = pendingEvents,
                successEvents = successEvents,
                failedEvents = failedEvents,
                oldestEventTimestamp = oldestTimestamp,
                newestEventTimestamp = newestTimestamp,
                oldestSentTimestamp = oldestSentTimestamp,
                newestSentTimestamp = newestSentTimestamp,
                cacheSize = cacheSize,
                lastUpdated = System.currentTimeMillis()
            )
        } catch (e: Exception) {
            logger.logError("Failed to get cache stats", e)
            CacheStats()
        }
        // Note: Do NOT close db - SQLiteOpenHelper manages the connection pool
    }
    
    private fun getTotalEventCount(db: SQLiteDatabase): Int {
        val cursor = db.rawQuery("SELECT COUNT(*) FROM ${AnalyticsDatabaseHelper.TABLE_EVENTS}", null)
        return cursor.use {
            if (it.moveToFirst()) {
                it.getInt(0)
            } else {
                0
            }
        }
    }
    
    private fun getEventCountByStatus(db: SQLiteDatabase, status: SendStatus): Int {
        val cursor = db.rawQuery(
            "SELECT COUNT(*) FROM ${AnalyticsDatabaseHelper.TABLE_EVENTS} WHERE ${AnalyticsDatabaseHelper.COLUMN_SEND_STATUS} = ?",
            arrayOf(status.name)
        )
        return cursor.use {
            if (it.moveToFirst()) {
                it.getInt(0)
            } else {
                0
            }
        }
    }
    
    private fun getOldestTimestamp(db: SQLiteDatabase): Long? {
        val cursor = db.rawQuery(
            "SELECT MIN(${AnalyticsDatabaseHelper.COLUMN_TIMESTAMP}) FROM ${AnalyticsDatabaseHelper.TABLE_EVENTS}",
            null
        )
        return cursor.use {
            if (it.moveToFirst() && !it.isNull(0)) {
                it.getLong(0)
            } else {
                null
            }
        }
    }
    
    private fun getNewestTimestamp(db: SQLiteDatabase): Long? {
        val cursor = db.rawQuery(
            "SELECT MAX(${AnalyticsDatabaseHelper.COLUMN_TIMESTAMP}) FROM ${AnalyticsDatabaseHelper.TABLE_EVENTS}",
            null
        )
        return cursor.use {
            if (it.moveToFirst() && !it.isNull(0)) {
                it.getLong(0)
            } else {
                null
            }
        }
    }
    
    private fun getOldestSentTimestamp(db: SQLiteDatabase): Long? {
        val cursor = db.rawQuery(
            "SELECT MIN(${AnalyticsDatabaseHelper.COLUMN_SENT_AT}) FROM ${AnalyticsDatabaseHelper.TABLE_EVENTS} WHERE ${AnalyticsDatabaseHelper.COLUMN_SENT_AT} IS NOT NULL",
            null
        )
        return cursor.use {
            if (it.moveToFirst() && !it.isNull(0)) {
                it.getLong(0)
            } else {
                null
            }
        }
    }
    
    private fun getNewestSentTimestamp(db: SQLiteDatabase): Long? {
        val cursor = db.rawQuery(
            "SELECT MAX(${AnalyticsDatabaseHelper.COLUMN_SENT_AT}) FROM ${AnalyticsDatabaseHelper.TABLE_EVENTS} WHERE ${AnalyticsDatabaseHelper.COLUMN_SENT_AT} IS NOT NULL",
            null
        )
        return cursor.use {
            if (it.moveToFirst() && !it.isNull(0)) {
                it.getLong(0)
            } else {
                null
            }
        }
    }
    
    private fun parseParameters(json: String): Map<String, Any?> {
        return try {
            val type = object : TypeToken<Map<String, Any?>>() {}.type
            val rawParameters = gson.fromJson<Map<String, Any?>>(json, type) ?: emptyMap()
            normalizeStatisticsIntegerFields(rawParameters)
        } catch (e: Exception) {
            logger.logError("Failed to parse event parameters", e)
            emptyMap()
        }
    }

    /**
     * Gson parses all JSON numbers in Map<String, Any?> as Double, which causes
     * integer analytics fields to serialize with decimals (e.g. 0.0) when events
     * are reloaded from cache and posted to /Statistics.
     */
    private fun normalizeStatisticsIntegerFields(parameters: Map<String, Any?>): Map<String, Any?> {
        if (parameters.isEmpty()) return parameters

        val normalized = parameters.toMutableMap()

        normalizeLongFieldIfPresent("created", parameters, normalized)
        normalizeLongFieldIfPresent("duration", parameters, normalized)
        normalizeLongFieldIfPresent("timeToDisplay", parameters, normalized)

        normalizeIntFieldIfPresent("similarCount", parameters, normalized)
        normalizeIntFieldIfPresent("campaignID", parameters, normalized)
        normalizeIntFieldIfPresent("count", parameters, normalized)

        return normalized
    }

    private fun normalizeLongFieldIfPresent(
        key: String,
        source: Map<String, Any?>,
        target: MutableMap<String, Any?>
    ) {
        if (!source.containsKey(key)) return
        target[key] = toLongIfNumeric(source[key])
    }

    private fun normalizeIntFieldIfPresent(
        key: String,
        source: Map<String, Any?>,
        target: MutableMap<String, Any?>
    ) {
        if (!source.containsKey(key)) return
        target[key] = toIntIfNumeric(source[key])
    }

    private fun toLongIfNumeric(value: Any?): Any? {
        return when (value) {
            null -> null
            is Long -> value
            is Int -> value.toLong()
            is Short -> value.toLong()
            is Byte -> value.toLong()
            is Double -> value.toLong()
            is Float -> value.toLong()
            is String -> value.toLongOrNull()
            else -> value
        }
    }

    private fun toIntIfNumeric(value: Any?): Any? {
        return when (value) {
            null -> null
            is Int -> value
            is Short -> value.toInt()
            is Byte -> value.toInt()
            is Long -> value.toInt()
            is Double -> value.toInt()
            is Float -> value.toInt()
            is String -> value.toIntOrNull()
            else -> value
        }
    }
    
    /**
     * SQLite database helper for analytics events
     */
    private class AnalyticsDatabaseHelper(context: Context) : SQLiteOpenHelper(
        context,
        DATABASE_NAME,
        null,
        DATABASE_VERSION
    ) {
        companion object {
            private const val DATABASE_NAME = "analytics_cache.db"
            private const val DATABASE_VERSION = 1
            
            const val TABLE_EVENTS = "events"
            const val COLUMN_ID = "id"
            const val COLUMN_EVENT_NAME = "event_name"
            const val COLUMN_TIMESTAMP = "timestamp"
            const val COLUMN_PARAMETERS = "parameters"
            const val COLUMN_SENT_AT = "sent_at"
            const val COLUMN_ATTEMPT_COUNT = "attempt_count"
            const val COLUMN_LAST_ATTEMPT_AT = "last_attempt_at"
            const val COLUMN_SEND_STATUS = "send_status"
        }
        
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("""
                CREATE TABLE $TABLE_EVENTS (
                    $COLUMN_ID TEXT PRIMARY KEY,
                    $COLUMN_EVENT_NAME TEXT NOT NULL,
                    $COLUMN_TIMESTAMP INTEGER NOT NULL,
                    $COLUMN_PARAMETERS TEXT NOT NULL,
                    $COLUMN_SENT_AT INTEGER,
                    $COLUMN_ATTEMPT_COUNT INTEGER NOT NULL DEFAULT 0,
                    $COLUMN_LAST_ATTEMPT_AT INTEGER,
                    $COLUMN_SEND_STATUS TEXT NOT NULL DEFAULT 'PENDING'
                )
            """.trimIndent())
            
            // Create indexes for efficient querying
            db.execSQL("CREATE INDEX idx_timestamp ON $TABLE_EVENTS($COLUMN_TIMESTAMP)")
            db.execSQL("CREATE INDEX idx_send_status ON $TABLE_EVENTS($COLUMN_SEND_STATUS)")
            db.execSQL("CREATE INDEX idx_sent_at ON $TABLE_EVENTS($COLUMN_SENT_AT)")
        }
        
        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            db.execSQL("DROP TABLE IF EXISTS $TABLE_EVENTS")
            onCreate(db)
        }
    }
}
