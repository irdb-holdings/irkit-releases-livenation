package com.irdb.irkitui.ui.baseComponents

import android.content.res.Configuration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.irdb.irkitui.theme.ButtonCountTextColor
import com.irdb.irkitui.theme.IRKitUITheme

object ButtonCountTextDimens {
    val fontSize = 12.sp
    val minCount = 1
}

/**
 * A reusable composable for displaying count text next to buttons.
 *
 * This component is designed to show numerical counts (like save counts, comment counts, etc.)
 * next to action buttons. It only displays when the count is greater than 0.
 *
 * @param count The count to display. Only shows when count > 0
 * @param modifier Additional modifier to be applied to the text
 * @param color The color of the text (defaults to theme color)
 * @param fontSize The font size of the text (defaults to 12sp)
 *
 * Usage example:
 * ```
 * CheckRow {
 *     IconButton(onClick = { /* action */ }) {
 *         Icon(imageVector = Icons.Default.Bookmark, contentDescription = "Save")
 *     }
 *     ButtonCountText(count = 5)
 * }
 * ```
 */
@Composable
fun ButtonCountText(
    count: Int,
    modifier: Modifier = Modifier,
    color: Color = ButtonCountTextColor,
    fontSize: TextUnit = ButtonCountTextDimens.fontSize
) {
    if (count >= ButtonCountTextDimens.minCount) {
        Text(
            text = "$count",
            color = color,
            fontSize = fontSize,
            modifier = modifier
        )
    }
}

@Preview(showBackground = true)
@Composable
fun ButtonCountTextPreview() {
    IRKitUITheme {
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(8.dp)
        ) {
            ButtonCountText(count = 1)
            ButtonCountText(count = 5)
            ButtonCountText(count = 42)
            ButtonCountText(count = 0) // Should not display
            ButtonCountText(count = -1) // Should not display
        }
    }
}

@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
fun ButtonCountTextDarkPreview() {
    IRKitUITheme(darkTheme = true) {
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(8.dp)
        ) {
            ButtonCountText(count = 1)
            ButtonCountText(count = 5)
            ButtonCountText(count = 42)
            ButtonCountText(count = 0) // Should not display
            ButtonCountText(count = -1) // Should not display
        }
    }
}
