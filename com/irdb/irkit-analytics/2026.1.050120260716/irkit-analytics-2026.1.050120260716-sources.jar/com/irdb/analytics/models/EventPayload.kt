package com.irdb.analytics.models

import java.util.UUID

/**
 * Payload for a single analytics event.
 * Includes tracking information for debugging and correlation with server logs.
 */
data class EventPayload(
    val id: String = UUID.randomUUID().toString(),  // Unique ID for tracking
    val eventName: String,
    val timestamp: Long,                             // When event was created
    val parameters: Map<String, Any?>,              // Allow null values (e.g., userID for anonymous users)
    
    // Send tracking (for debugging)
    val sentAt: Long? = null,                        // When successfully sent to server
    val attemptCount: Int = 0,                       // Number of send attempts
    val lastAttemptAt: Long? = null,                 // Last attempt timestamp
    val sendStatus: SendStatus = SendStatus.PENDING  // Current status
) {
    /**
     * Estimate size in bytes for cache size tracking
     */
    fun estimatedSizeBytes(): Int {
        var size = 0
        size += id.length * 2  // UUID string
        size += eventName.length * 2
        size += 8  // timestamp (Long)
        size += 8  // sentAt (Long?)
        size += 4  // attemptCount (Int)
        size += 8  // lastAttemptAt (Long?)
        size += 4  // sendStatus enum
        
        // Parameters size estimate
        parameters.forEach { (key, value) ->
            size += key.length * 2
            size += when (value) {
                null -> 4  // null value
                is String -> value.length * 2
                is Number -> 8
                is Boolean -> 1
                else -> value.toString().length * 2
            }
        }
        
        return size
    }
}

/**
 * Status of event sending
 */
enum class SendStatus {
    PENDING,      // Not sent yet
    SENDING,      // Currently being sent
    SUCCESS,      // Successfully sent
    FAILED        // Failed after retries
}

/**
 * Batch payload for sending multiple events
 */
data class EventBatchPayload(
    val events: List<EventPayload>
)

/**
 * Response from analytics server
 */
data class EventBatchResponse(
    val success: Boolean,
    val message: String? = null,
    val eventsReceived: Int = 0
)

