package com.irdb.irkit.dto

import android.util.Log
import com.google.gson.TypeAdapter
import com.google.gson.stream.JsonReader
import com.google.gson.stream.JsonWriter
import java.util.Locale

class BooleanTypeAdapter : TypeAdapter<Boolean>() {
    override fun write(out: JsonWriter, value: Boolean?) {
        out.value(value)
    }

    override fun read(reader: JsonReader): Boolean {
        try {
            val token = reader.peek()
            val value = when (token) {
                com.google.gson.stream.JsonToken.BOOLEAN -> reader.nextBoolean()
                com.google.gson.stream.JsonToken.NUMBER -> reader.nextInt() == 1
                com.google.gson.stream.JsonToken.STRING -> {
                    val stringValue = reader.nextString()
                    stringValue.lowercase(Locale.getDefault()) == "true" || stringValue == "1"
                }
                else -> {
                    Log.e("BooleanTypeAdapter", "Unexpected token type: $token")
                    false
                }
            }
            Log.d("BooleanTypeAdapter", "Successfully parsed boolean value: $value from token: $token")
            return value
        } catch (e: Exception) {
            Log.e("BooleanTypeAdapter", "Error parsing boolean value: ${e.message}", e)
            return false
        }
    }
}