package com.irdb.analytics

import kotlin.time.Duration.Companion.seconds

/**
 * Builds the sessionSource string dynamically from its component parts.
 * Format: "{platform}-{companyName}-{bucketName}"
 *
 * @param platform The platform identifier (e.g., "Android")
 * @param companyName The company name (e.g., "ksl", "irdb")
 * @param bucketName The analytics bucket name (e.g., "ksldemo", "irdbMain")
 * @return The constructed sessionSource string (e.g., "Android-ksl-ksldemo")
 */
fun buildSessionSource(platform: String, companyName: String, bucketName: String): String {
    return "$platform-$companyName-$bucketName".lowercase()
}

/**
 * Rewrite an event's `bucketName` and `sessionSource` parameters with the
 * given resolved values, leaving every other parameter untouched.
 *
 * Used by [AnalyticsClient.setBucketName] when draining the pre-bucket
 * buffer: events captured before /lenses returned still need to ship with
 * the right bucket once the resolver completes. Returns a NEW
 * [com.irdb.analytics.models.EventPayload] (the original is not mutated, so
 * any reference held elsewhere — e.g. the buffer snapshot — stays
 * consistent).
 */
internal fun rebrandEventBucket(
    event: com.irdb.analytics.models.EventPayload,
    bucketName: String,
    sessionSource: String
): com.irdb.analytics.models.EventPayload {
    return event.copy(
        parameters = event.parameters.toMutableMap().apply {
            this["bucketName"] = bucketName
            this["sessionSource"] = sessionSource
        }
    )
}

/**
 * Helper function to create AnalyticsConfig from Java.
 * Provides sensible defaults for all parameters.
 */
fun createAnalyticsConfig(
    apiEndpoint: String,
    apiKey: String,
    companyName: String,
    bucketName: String,
    isDebugBuild: Boolean
): AnalyticsConfig {
    return AnalyticsConfig(
        apiEndpoint = apiEndpoint,
        apiKey = apiKey,
        companyName = companyName,
        bucketName = bucketName,
        enableMocking = true,  // Mock/log only (no network calls)
        enableDebugLogging = isDebugBuild,
        autoTrackLifecycle = true,  // REQUIRED for session tracking
        autoDetectDeviceInfo = true,
        enableCaching = true,
        cacheRetentionPolicy = CacheRetentionPolicy.CLEAR_ON_SUCCESS,
        maxBatchSize = 100,
        flushInterval = 1.seconds,
        autoSyncOnConnectivity = true
    )
}
