package com.irdb.analytics

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Deduplication mechanism for scan match events (spec-strict "while-displayed" semantics).
 *
 * Per analytics_doc (3).md §"Scan Result - Match":
 *   "For Live Visual Search based matches, only submit matches when they are new and unique.
 *    If the same match is returned within the same second, or from the same section, it counts
 *    as a single match. Only one submission is necessary. Ignore submitting new matches until
 *    it is unique, of a different section, or the preview popup has been dismissed by the user
 *    and a new preview popup appears."
 *
 * Rule: track the imageID currently shown in the preview popup. Same imageID is blocked
 * until clear() is called (preview popup dismissed). A → B → A produces 2 POSTs (A admitted,
 * B admitted, A blocked because A is still the currently-displayed match window context until
 * a dismiss happens). After dismiss, the next recognition of A is admitted again as a fresh match.
 */
internal class ScanMatchDeduplicator {
    private val mutex = Mutex()

    // imageID currently shown in the preview popup. Set when a match is admitted; cleared on
    // popup dismiss via clear(). Any recognition of the same imageID while this is set is a
    // duplicate per spec and must be suppressed.
    private var currentMatchedImageId: String? = null

    /**
     * @return true if the match should be POSTed (new/unique relative to currently-displayed match)
     */
    suspend fun shouldSubmitMatch(imageId: String): Boolean {
        return mutex.withLock {
            if (imageId == currentMatchedImageId) {
                false
            } else {
                currentMatchedImageId = imageId
                true
            }
        }
    }

    /** Reset state — call when the preview popup is dismissed so the next match can fire. */
    suspend fun clear() {
        mutex.withLock {
            currentMatchedImageId = null
        }
    }
}

