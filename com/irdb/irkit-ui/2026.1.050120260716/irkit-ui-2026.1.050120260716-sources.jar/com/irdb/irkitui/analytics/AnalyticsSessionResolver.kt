package com.irdb.irkitui.analytics

import com.irdb.irkit.response.LensResponse

/**
 * Per-session analytics identifiers derived from a `/lenses` server response.
 *
 *  - `bucketName`     — the lens's `primaryCollection`, e.g. `"ksl-commercials"`
 *                       or `"irdbMain"`. Sent on every analytics event.
 *  - `sessionSource`  — built per the analytics spec as
 *                       `<platform>-<company>-<collection>`, all lowercase
 *                       (e.g. `"android-ksl-ksl-commercials"`).
 */
data class AnalyticsSessionDescriptor(
    val bucketName: String,
    val sessionSource: String
)

/**
 * Resolve the per-session analytics identifiers from a server `/lenses`
 * response and the static client `companyName`.
 *
 * The server returns one or more lenses; we use the **first lens**'s
 * `primaryCollection` as the bucket. That mirrors what
 * [com.irdb.irkitui.IRKitUI.refreshLensConfig] already does for everything
 * else (search string, characteristics, etc.).
 *
 * `sessionSource` follows the analytics spec:
 * > Pattern: `<source>-<company>-<collection name>` (e.g. `iOS-ircode-irdbMain`)
 *
 * The output is lowercased so different casings of `companyName` ("KSL" vs
 * "ksl") collapse to one canonical sessionSource on the server side.
 *
 * @return the resolved descriptor, or `null` if any required input is missing
 *         (no lenses, blank `primaryCollection`, blank `companyName`). The
 *         caller should keep the previous bucket on null — never ship `--`.
 */
fun resolveAnalyticsSession(
    lensResponse: LensResponse,
    companyName: String,
    platform: String = "Android"
): AnalyticsSessionDescriptor? {
    if (companyName.isBlank() || platform.isBlank()) return null
    val primaryCollection = lensResponse.lenses
        ?.firstOrNull()
        ?.primaryCollection
        ?.takeIf { it.isNotBlank() }
        ?: return null
    val sessionSource = "$platform-$companyName-$primaryCollection".lowercase()
    return AnalyticsSessionDescriptor(
        bucketName = primaryCollection,
        sessionSource = sessionSource
    )
}
