package com.irdb.irkit

import android.util.Log
import com.google.gson.reflect.TypeToken
import com.irdb.irkit.response.ImageSaveDeleteResponse
import com.irdb.irkit.response.ImageSavePostResponse

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// {
// "scanTime":0,
// "status":"publish",
// "imageID":"0194B8AB062870EDBFD69ED0C27C3278",
// "imageUrl":"https:\/\/storage.googleapis.com\/ircode-1a662.appspot.com\/irdbAdd%2Fd0e0db01-64c8-46f3-a1eb-d499d2b98a85.jpeg",
// "cropped":false
// }

suspend fun BackendService.addImageToSaved(
    imageId: String,
    displayImageUrl: String,
    fbToken: String
): Boolean =
    withContext(Dispatchers.IO) {
        val endpoint = "/images/save/$imageId"

        if (BackendService.isDebugMode()) {
            Log.i(TAG, "Adding this image to Saved $imageId")
        }

        val requestBody = mapOf(
            "scanTime" to 0,
            "status" to "publish",
            "imageID" to imageId,
            "imageUrl" to displayImageUrl,
            "cropped" to false
        )

        if (BackendService.isDebugMode()) {
            Log.d(TAG, "Request body: $requestBody")
            Log.d(TAG, "auth: $fbToken")
        }

        val response = request<BaseResponse<ImageSavePostResponse>>(
            endpoint = endpoint,
            method = HttpMethod.POST,
            responseType = object : TypeToken<BaseResponse<ImageSavePostResponse>>() {}.type,
            bodyParameters = requestBody
        )

        if (!response.succeeded || response.payload == null) {
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        payload.results.save
    }

suspend fun BackendService.removeImageToSaved(
    imageId: String,
    displayImageUrl: String,
    fbToken: String
): Boolean =
    withContext(Dispatchers.IO) {
        val endpoint = "/images/save/$imageId"

        if (BackendService.isDebugMode()) {
            Log.i(TAG, "remove this image to Saved $imageId")
        }

        val requestBody = mapOf(
            "scanTime" to 0,
            "status" to "publish",
            "imageID" to imageId,
            "imageUrl" to displayImageUrl,
            "cropped" to false
        )

        if (BackendService.isDebugMode()) {
            Log.d(TAG, "Request body: $requestBody")
            Log.d(TAG, "auth: $fbToken")
        }

        val response = request<BaseResponse<ImageSaveDeleteResponse>>(
            endpoint = endpoint,
            method = HttpMethod.DELETE,
            responseType = object : TypeToken<BaseResponse<ImageSaveDeleteResponse>>() {}.type,
            bodyParameters = requestBody
        )

        if (!response.succeeded || response.payload == null) {
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        payload.results.removed
    }
