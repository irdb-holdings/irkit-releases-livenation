package com.irdb.analytics.models

/**
 * Snapshot of the network / location fields that [com.irdb.analytics.AnalyticsClient]
 * attaches to every analytics event payload.
 *
 * Every field here mirrors exactly what would be written into the event
 * `parameters` map by `buildEventParameters()` at the moment the snapshot is
 * taken. Intended for debugging surfaces (Playground, analytics test app)
 * that need to show the developer what the next event will actually send.
 *
 * Note: `locationIP` is no longer fetched or sent — the /Statistics backend
 * now derives it from each request's source IP. `deviceLocalIp` is kept here
 * for debug surfaces only (still useful to see the phone's own IP); it is
 * not sent in any payload.
 */
data class AnalyticsDebugInfo(
    /** Value sent in the `network` field (e.g. "wifi", "4g", "offline"). */
    val networkType: String,

    /** Phone's own local IP (not sent to analytics; shown for diagnostic UI). */
    val deviceLocalIp: String?,

    /** Value sent in the `locationLat` field. */
    val locationLat: Double?,

    /** Value sent in the `locationLng` field. */
    val locationLng: Double?,

    /**
     * Captured failure message when `FusedLocationProviderClient.requestLocationUpdates`
     * throws on a non-GMS device (Amazon Fire, Huawei post-2019, de-googled
     * ROMs). Null on healthy devices. Lets QA tell "no location yet" from
     * "fused broken" at a glance.
     */
    val locationUnavailableReason: String? = null,
)
