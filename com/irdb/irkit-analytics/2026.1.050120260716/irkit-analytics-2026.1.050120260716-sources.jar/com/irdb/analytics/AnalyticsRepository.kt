package com.irdb.analytics

import com.irdb.analytics.models.EventPayload
import com.irdb.analytics.models.SendStatus
import com.irdb.analytics.network.EventBatchPayload
import com.irdb.analytics.network.NetworkClient
import com.irdb.analytics.network.NetworkResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.min
import kotlin.math.pow
import kotlin.random.Random

/**
 * Repository for handling analytics event queuing, batching, and network calls.
 * Integrates with cache for offline support.
 */
internal class AnalyticsRepository(
    private val config: AnalyticsConfig,
    private val logger: AnalyticsLogger,
    private val cache: AnalyticsCache,
    // Late-bind locationIP at send time (primary goal fix from
    // docs/address_ip.md): any event whose `parameters` map does NOT contain
    // a `locationIP` key gets stamped with the current cached value right
    // before the network POST. If /myip has never resolved yet, we leave
    // the field absent (same floor as today).
    private val cachedIpProvider: () -> String? = { null }
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private var autoFlushJob: kotlinx.coroutines.Job? = null
    
    /**
     * Initialize - load cached events
     */
    suspend fun initialize() {
        if (config.enableCaching) {
            // Clean up any old SUCCESS events that shouldn't be in cache anymore
            cache.clearAllSentEvents()
            
            val cachedEvents = cache.loadEvents()
            if (cachedEvents.isNotEmpty()) {
                logger.logDebug("📦 Found ${cachedEvents.size} cached events, will retry")
            }
        }
        
        // Start auto-flush
        startAutoFlush()
    }
    
    /**
     * Enqueue an event (save to cache and queue for sending)
     */
    fun enqueueEvent(event: EventPayload) {
        scope.launch {
            mutex.withLock {
                // Save to cache immediately (offline support)
                if (config.enableCaching && !config.enableMocking) {
                    cache.saveEvents(listOf(event))
                }

                // Log event for debugging (independent of mock mode)
                logger.logDebug("📦 Enqueueing event: ${event.eventName}")
                logger.logEvent(event.eventName, event.parameters)
                logger.logEventOneLine(event.eventName, event.parameters)
                logger.logDebug("✅ Event enqueued: ${event.eventName}")
            }

            // Trigger flush if batch size reached
            val pendingEvents = cache.loadEvents()
                .filter { it.sendStatus != SendStatus.SUCCESS }
            if (pendingEvents.size >= config.maxBatchSize) {
                flushEvents()
            }
        }
    }

    /**
     * Synchronously enqueue event and wait for cache persistence to complete.
     * Use this for critical events that must be persisted before app termination.
     */
    suspend fun enqueueEventSync(event: EventPayload) {
        mutex.withLock {
            // Save to cache (already on IO dispatcher via mutex context)
            if (config.enableCaching && !config.enableMocking) {
                cache.saveEvents(listOf(event))  // Suspend until write completes
            }

            // Log event for debugging
            logger.logDebug("📦 Enqueueing event (sync): ${event.eventName}")
            logger.logEvent(event.eventName, event.parameters)
            logger.logEventOneLine(event.eventName, event.parameters)
            logger.logDebug("✅ Event enqueued (sync): ${event.eventName}")
        }

        // Check if flush needed AFTER persisting
        val pendingEvents = cache.loadEvents()
            .filter { it.sendStatus != SendStatus.SUCCESS }
        if (pendingEvents.size >= config.maxBatchSize) {
            flushEvents()
        }
    }
    
    /**
     * Calculate exponential backoff delay with jitter
     * @param attemptNumber The current retry attempt (0-based)
     * @return Delay in milliseconds
     */
    private fun calculateBackoffDelay(attemptNumber: Int): Long {
        val baseDelayMs = config.rateLimitBaseDelay.inWholeMilliseconds
        val maxDelayMs = config.rateLimitMaxDelay.inWholeMilliseconds
        
        // Exponential backoff: baseDelay * 2^attemptNumber
        val exponentialDelay = baseDelayMs * (2.0.pow(attemptNumber)).toLong()
        
        // Cap at max delay
        val cappedDelay = min(exponentialDelay, maxDelayMs)
        
        // Add jitter (±25%) to prevent thundering herd
        val jitterRange = (cappedDelay * 0.25).toLong()
        val jitter = if (jitterRange > 0) {
            Random.nextLong(-jitterRange, jitterRange + 1)
        } else {
            0L
        }
        
        return maxOf(0, cappedDelay + jitter)
    }
    
    /**
     * Check if an event is still in backoff period and should not be retried yet
     */
    private fun isEventInBackoff(event: EventPayload): Boolean {
        val lastAttemptAt = event.lastAttemptAt ?: return false
        val attemptCount = event.attemptCount
        
        // Only apply backoff for rate-limited events (those that have been attempted)
        if (attemptCount == 0) return false
        
        val backoffDelayMs = calculateBackoffDelay(attemptCount - 1)
        val nextRetryTime = lastAttemptAt + backoffDelayMs
        val now = System.currentTimeMillis()
        
        return now < nextRetryTime
    }
    
    /**
     * Flush pending events to server
     */
    suspend fun flushEvents() {
        mutex.withLock {
            // OPTIMIZATION: Check count first to avoid expensive full query when no events
            val pendingCount = cache.getPendingEventCount()
            if (pendingCount == 0) {
                // No events to flush - skip expensive loadEvents() call
                return
            }
            
            // Load all pending events from cache
            val allPendingEvents = cache.loadEvents()
                .filter { it.sendStatus != SendStatus.SUCCESS } // Only send pending/failed

            // Filter out events that are still in backoff period
            var readyEvents = allPendingEvents.filter { event ->
                if (isEventInBackoff(event)) {
                    val lastAttemptAt = event.lastAttemptAt ?: 0L
                    val backoffDelayMs = calculateBackoffDelay(event.attemptCount - 1)
                    val nextRetryTime = lastAttemptAt + backoffDelayMs
                    val waitTimeMs = nextRetryTime - System.currentTimeMillis()
                    logger.logDebug("⏳ Event ${event.id} in backoff, retry in ${waitTimeMs}ms (attempt ${event.attemptCount})")
                    false
                } else {
                    true
                }
            }
            
            if (config.enableMocking) {
                // In mock mode, only log FLUSH if there are actually events to flush
                if (readyEvents.isNotEmpty()) {
                    logger.logEvent("FLUSH", mapOf("info" to "Mock mode - no network call", "eventCount" to readyEvents.size))
                }
                return
            }
            
            if (readyEvents.isEmpty()) {
                if (allPendingEvents.isNotEmpty()) {
                    logger.logDebug("⏸️ ${allPendingEvents.size} events pending, but all in backoff period")
                }
                // Removed "No events to flush" log to reduce overhead
                return
            }
            
            val eventIds = readyEvents.map { it.id }.toSet()
            
            try {
                // Mark as attempting to send
                try {
                    cache.updateSendAttempt(eventIds)
                } catch (e: Exception) {
                    logger.logError("Failed to update send attempt in cache", e)
                    // Continue anyway - the network call can still proceed
                }
                
                // Late-bind locationIP: stamp any events missing the field with
                // the current cached /myip value. Persist the stamp so retries
                // don't re-stamp with a newer IP on a later attempt. Primary
                // goal fix from docs/address_ip.md: every event flushed after
                // /myip has ever resolved in-session carries locationIP.
                val cachedIp = cachedIpProvider()
                if (cachedIp != null) {
                    val needsStamping = readyEvents.filter { !it.parameters.containsKey("locationIP") }
                    if (needsStamping.isNotEmpty()) {
                        logger.logDebug("🌐 [IP] Late-binding locationIP=$cachedIp on ${needsStamping.size} event(s)")
                        // Persist the stamp back to the cache (re-insert replaces the
                        // existing row since id is PRIMARY KEY) so retries keep the
                        // same stamp.
                        val stamped = needsStamping.map { event ->
                            event.copy(parameters = event.parameters + ("locationIP" to cachedIp))
                        }
                        try {
                            cache.updateEventParameters(stamped)
                        } catch (e: Exception) {
                            logger.logError("Failed to persist late-bound locationIP for ${stamped.size} event(s)", e)
                            // Continue anyway — the in-memory batch below still carries the stamp.
                        }
                        // Replace the in-memory batch with the stamped versions so
                        // the outgoing POST reflects the late-bound field even if
                        // persistence failed.
                        readyEvents = readyEvents.map { event ->
                            if (!event.parameters.containsKey("locationIP")) {
                                event.copy(parameters = event.parameters + ("locationIP" to cachedIp))
                            } else event
                        }
                    }
                }

                // Send batch to server using HttpURLConnection. locationLat /
                // locationLng travel in the JSON body along with locationIP
                // (v2.1 — iOS §4.3 parity).
                val networkResponse = NetworkClient.sendEvents(config, EventBatchPayload(readyEvents), logger)
                
                when (networkResponse) {
                    is NetworkResponse.Success -> {
                        val sentTimestamp = System.currentTimeMillis()
                        val formattedTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US)
                            .format(Date(sentTimestamp))
                        
                        logger.logNetworkResponse(200, networkResponse.response.message ?: "Success")
                        logger.logDebug("📤 Sent ${readyEvents.size} events at $formattedTime")
                        
                        // Always clear sent events immediately from cache
                        try {
                            cache.clearSentEvents(eventIds)
                            logger.logDebug("🗑️ Cleared sent events from cache")
                        } catch (e: Exception) {
                            logger.logError("Failed to clear sent events from cache", e)
                            // Event was sent successfully, so this is a minor issue
                        }
                    }
                    is NetworkResponse.Error -> {
                        // Additional error logging with event details
                        logger.logError("📊 Error summary: ${readyEvents.size} events failed with HTTP ${networkResponse.statusCode}")
                        logger.logError("Error response: ${networkResponse.message.takeIf { it.isNotEmpty() } ?: "[no response body]"}")

                        if (networkResponse.shouldBackoff) {
                            // Rate limiting (429) or Service Unavailable (503)
                            val attemptCount = readyEvents.firstOrNull()?.attemptCount ?: 0
                            
                            // Determine retry delay
                            val retryDelayMs = when {
                                // Respect Retry-After header if provided and enabled
                                config.respectRetryAfterHeader && networkResponse.retryAfterSeconds != null -> {
                                    networkResponse.retryAfterSeconds * 1000L
                                }
                                // Otherwise use exponential backoff
                                else -> {
                                    calculateBackoffDelay(attemptCount)
                                }
                            }
                            
                            val errorType = when {
                                networkResponse.isRateLimit -> "Rate Limited (429)"
                                networkResponse.isServiceUnavailable -> "Service Unavailable (503)"
                                else -> "HTTP ${networkResponse.statusCode}"
                            }
                            
                            logger.logError("⏳ $errorType - Retrying in ${retryDelayMs}ms (attempt ${attemptCount + 1}/${config.rateLimitMaxRetries})")
                            
                            // Check if we've exceeded max retries
                            if (attemptCount >= config.rateLimitMaxRetries) {
                                logger.logError("❌ Max retries (${config.rateLimitMaxRetries}) exceeded for rate-limited events. Marking as failed.")
                                try {
                                    cache.markAsFailed(eventIds)
                                } catch (e: Exception) {
                                    logger.logError("Failed to mark events as failed in cache", e)
                                }
                            } else {
                                // Mark as failed but keep for retry with backoff
                                try {
                                    cache.markAsFailed(eventIds)
                                    logger.logDebug("🔄 Events will be retried after backoff period")
                                } catch (e: Exception) {
                                    logger.logError("Failed to mark events as failed in cache", e)
                                }
                            }
                        } else {
                            // Other HTTP errors (4xx, 5xx except 429/503)
                            logger.logError("❌ HTTP ${networkResponse.statusCode} error - Events will be retried on next flush")
                            try {
                                cache.markAsFailed(eventIds)
                                // Events remain in cache for retry
                            } catch (e: Exception) {
                                logger.logError("Failed to mark events as failed in cache", e)
                            }
                        }
                    }
                    is NetworkResponse.Exception -> {
                        // Network exception - already logged in NetworkClient, but add summary here
                        logger.logError("📊 Network exception summary: ${readyEvents.size} events failed due to network error")
                        logger.logError("Exception details: ${networkResponse.throwable.javaClass.simpleName} - ${networkResponse.throwable.message}")
                        try {
                            cache.markAsFailed(eventIds)
                            // Events remain in cache for retry when connection restored
                        } catch (e: Exception) {
                            logger.logError("Failed to mark events as failed in cache", e)
                        }
                    }
                }
            } catch (e: Exception) {
                logger.logError("Unexpected error sending events", e)
                try {
                    cache.markAsFailed(eventIds)
                    // Events remain in cache for retry when connection restored
                } catch (cacheException: Exception) {
                    logger.logError("Failed to mark events as failed in cache after unexpected error", cacheException)
                }
            }
        }
    }
    
    /**
     * Start auto-flush timer.
     *
     * We delay the first flush by 1000ms (docs/address_ip.md §B.8 warmup).
     * [AnalyticsClient.init] kicks off the initial `/myip` fetch on the
     * same IO scope; giving that fetch a 1s head start means most cold-start
     * events get `locationIP` stamped on their very first flush attempt. If
     * `/myip` resolves faster, we're still bounded by the normal
     * flushInterval for subsequent flushes. Worst case: 1s extra latency on
     * cold start.
     */
    private fun startAutoFlush() {
        autoFlushJob?.cancel()
        autoFlushJob = scope.launch {
            // Startup warmup: give the initial /myip fetch a head start so
            // the first flush has a cached IP to late-bind.
            delay(1000)
            flushEvents()
            while (true) {
                delay(config.flushInterval)
                flushEvents()
            }
        }
    }
    
    /**
     * Get cache stats for debugging
     */
    suspend fun getCacheStats() = cache.getCacheStats()

    /**
     * Cancel the auto-flush loop and the repository's IO scope. Idempotent —
     * subsequent calls are no-ops. Intended for [AnalyticsClient.shutdown]
     * teardown only.
     */
    fun shutdown() {
        autoFlushJob?.cancel()
        autoFlushJob = null
        scope.cancel()
    }
}

