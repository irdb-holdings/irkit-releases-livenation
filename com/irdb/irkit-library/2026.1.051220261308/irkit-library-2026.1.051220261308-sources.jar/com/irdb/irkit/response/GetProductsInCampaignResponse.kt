package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName
import com.irdb.irkit.BaseResponse
import com.irdb.irkit.dto.ProductInCampaignDto

typealias GetProductsInCampaignResponse = BaseResponse<ProductsContainer>

data class ProductsContainer(
    @SerializedName("Products")
    val products: List<ProductInCampaignDto>
)
