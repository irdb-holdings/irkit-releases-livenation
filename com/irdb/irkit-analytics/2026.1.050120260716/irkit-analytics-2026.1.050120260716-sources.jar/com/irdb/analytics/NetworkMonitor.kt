package com.irdb.analytics

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Monitors network connectivity and auto-syncs when connection restored.
 *
 * Detects three distinct transitions (docs/address_ip.md §5.1 Option B,
 * the recommended Android choice):
 *
 * | Transition                           | Signal                          | Action                                                                |
 * |--------------------------------------|---------------------------------|-----------------------------------------------------------------------|
 * | Offline → Online (after disconnect)  | `onAvailable` with currentNet=null | [onConnectivityRestored] (flush queue) AND [onTransportChanged] (refetch IP) |
 * | Clean WiFi ↔ cellular handover       | `onAvailable` with new Network  | [onTransportChanged] only — we were never offline, no flush needed    |
 * | Online → Offline                     | `onLost` for current network    | Record wasDisconnected = true. No IP refetch.                         |
 *
 * This fixes the "clean WiFi↔cellular handover is invisible" bug the iOS
 * doc calls out explicitly: without [onTransportChanged], a user who walks
 * out of WiFi range carries the old IP for the rest of the session.
 */
internal class NetworkMonitor(
    private val context: Context,
    private val onConnectivityRestored: suspend () -> Unit,
    private val logger: AnalyticsLogger,
    private val onTransportChanged: suspend () -> Unit = {}
) {
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE)
        as ConnectivityManager

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    // The Network handle we're currently tracking as the default network.
    // null = we believe we're offline. Updates on onAvailable/onLost.
    @Volatile private var currentNetwork: Network? = null

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            val previous = currentNetwork
            currentNetwork = network
            when {
                previous == null -> {
                    // Offline → Online (or first-ever signal after start())
                    logger.logDebug("📶 Default network available: $network")
                    handleConnectivityRestored()
                    fireTransportChanged("online")
                }
                previous != network -> {
                    // Clean WiFi ↔ cellular handover (no offline gap)
                    logger.logDebug("📶 Default network CHANGED: $previous → $network")
                    fireTransportChanged("handover")
                }
                else -> {
                    // Same network reported available again — no-op.
                }
            }
        }

        override fun onLost(network: Network) {
            if (network == currentNetwork) {
                logger.logDebug("📵 Default network lost: $network")
                currentNetwork = null
                // No IP refetch on loss; we'll refetch when we come back online.
            }
        }
    }

    fun start() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            connectivityManager.registerDefaultNetworkCallback(networkCallback)
        } else {
            val request = NetworkRequest.Builder()
                .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                .build()
            connectivityManager.registerNetworkCallback(request, networkCallback)
        }

        logger.logDebug("✅ Network monitoring started")
    }

    fun stop() {
        try {
            connectivityManager.unregisterNetworkCallback(networkCallback)
            logger.logDebug("⏹️ Network monitoring stopped")
        } catch (e: Exception) {
            logger.logError("Error stopping network monitor", e)
        }
    }

    private fun handleConnectivityRestored() {
        logger.logDebug("✅ Connection restored - triggering sync")
        scope.launch {
            delay(2000) // Give network a moment to stabilize
            onConnectivityRestored()
        }
    }

    private fun fireTransportChanged(reason: String) {
        scope.launch {
            logger.logDebug("🔀 [NetworkMonitor] Transport changed ($reason)")
            try {
                onTransportChanged()
            } catch (e: Exception) {
                logger.logError("onTransportChanged callback threw", e)
            }
        }
    }

    fun isConnected(): Boolean {
        val network = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }
}
