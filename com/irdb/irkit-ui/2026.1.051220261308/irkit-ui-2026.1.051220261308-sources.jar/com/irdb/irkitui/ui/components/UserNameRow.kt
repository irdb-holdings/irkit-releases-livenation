package com.irdb.irkitui.ui.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.irdb.irkit.ImageModel
import com.irdb.irkitui.ui.baseComponents.ProBadge

@Composable
fun UserNameRow(image: ImageModel) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = image.imageUser?.userName?.takeIf { it.isNotBlank() }
                ?: image.imageUser?.fullName?.takeIf { it.isNotBlank() }
                ?: image.getArtistName().takeIf { it.isNotBlank() }
                ?: "User",
            style = TextStyle(
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF8E8E93)
            )
        )

        // Jiri Looking at iOS code
        // We show this badge for two reasons
        // if the logged in user is a pro (?????)
        // if (userType == UserModel.UserType.Pro) {
        // The last one makes more sense to me.
        // in any case we do not have logged in users so I will hide the badge

        val proUser = false
        // Pro badge if needed
        if (proUser) {
            ProBadge()
        }
    }
}
