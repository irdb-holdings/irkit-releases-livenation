package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName
import com.irdb.irkit.dto.ImageDto

/*
{
	"Completed": true,
	"Time": "2025-7-29 12:49:47.39",
	"TimeUsed": 214,
	"GCRLog": "development-v1-43-3546194669-240",
	"NextOffset": 0,
	"Total": 0,
	"Count": 0,
	"Pages": 0,
	"Environment": "DEV",
	"GCFVersion": "development-v1-43-00797-xay",
	"Results": {
		"Finished": true
	}
}
 */

data class ImageMetaResponse(
    @SerializedName("Finished")
    val finished: Boolean = false,
)


/*

// IOS
{
	"metaArray": [{
		"metaContent": "{\"cardType\":\"general\"}",
		"metaDelete": false,
		"metaOrder": -1,
		"metaID": 186625,
		"metaType": "CardType"
	}, {
		"metaDelete": false,
		"metaOrder": 2,
		"metaType": "Description",
		"metaContent": "{\"description\":\"\"}",
		"metaID": 0
	}, {
		"metaType": "Title",
		"metaOrder": 0,
		"metaID": 186626,
		"metaDelete": false,
		"metaContent": "{\"title\":\"Messy\"}"
	}, {
		"metaContent": "{\"tags\":[]}",
		"metaDelete": false,
		"metaID": 186627,
		"metaType": "Tags",
		"metaOrder": 29
	}, {
		"metaContent": "{\"links\":[]}",
		"metaDelete": false,
		"metaOrder": 8,
		"metaID": 186628,
		"metaType": "Link"
	}, {
		"metaType": "Custom",
		"metaID": 186629,
		"metaOrder": 13,
		"metaDelete": false,
		"metaContent": "{\"custom\":{}}"
	}, {
		"metaContent": "{\"embeddedVideo\":\"\"}",
		"metaType": "EmbeddedVideo",
		"metaID": 186630,
		"metaOrder": 23,
		"metaDelete": false
	}],
	"imageID": "019831C14EDF74398886DEAE25D5ECA5"
}

// android:
{
  "imageID": "0198334811EB7155AB311F14C3153C64",
  "metaArray": [
    {
      "metaID": 0,
      "metaType": "CardType",
      "metaContent": "{\"cardType\":\"general\"}"
    },
    {
      "metaID": 0,
      "metaType": "Title",
      "metaContent": "{\"title\":\"cup\"}"
    }
  ]
}
 */
