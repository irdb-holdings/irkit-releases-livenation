package com.irdb.irkit

import android.util.Log
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken

import com.irdb.irkit.dto.UserDataDTO
import com.irdb.irkit.dto.CreateUserRequest
import com.irdb.irkit.response.UserResponse

//{
//    "email": "user@mail.com",
//    "phone": "123-456-7890",
//    "profileUrl": "http://someurl.com",
//    "fullName": "username",
//    "version": "1.0",
//    "mergeFirebaseID": "firebase-id-123",
//    "deviceToken": "device-token-abc", // do not send
//    "privateAccount": "0"
//}

suspend fun UserService.createUser( createUserRequest: CreateUserRequest): UserDataDTO {
    val endpoint = "/User"

    if (BackendService.isDebugMode()) {
        Log.d(TAG, "-- IRCode::createUser --")
    }

    val response =
        BackendService.request<BaseResponse<UserResponse>>(
            endpoint = endpoint,
            method = HttpMethod.POST,
            bodyParameters = createUserRequest,
            responseType = object : TypeToken<BaseResponse<UserResponse>>() {}.type
        )

    if (!response.succeeded || response.payload == null) {
        Log.e(TAG, "Failed to create createUser user: ${response.errorMessage}")
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    if (BackendService.isDebugMode()) {
        val ur = payload.results
        Log.d(TAG, ur.user.describeContents())
    }

    val userDataDto =
        UserDataDTO.fromUserResponse(
            payload.results.user
        )
    return userDataDto
}

//{
//    "email": "user@mail.com",
//    "phone": "123-456-7890",
//    "profileUrl": "http://someurl.com",
//    "fullName": "username",
//    "version": "1.0",
//    "mergeFirebaseID": "firebase-id-123",
//    "deviceToken": "device-token-abc", // do not send
//    "privateAccount": "0"
//}

suspend fun UserService.UpdateUser( createUserRequest: CreateUserRequest): UserDataDTO {
    val endpoint = "/User"

    if (BackendService.isDebugMode()) {
        Log.d(TAG, "-- IRCode::UpdateUser --")
        
        // Log request in formatted JSON
        try {
            val requestJson = GsonBuilder()
                .setPrettyPrinting()
                .create()
                .toJson(createUserRequest)
            Log.d(TAG, "=== UpdateUser REQUEST ===")
            Log.d(TAG, "Endpoint: $endpoint")
            Log.d(TAG, "Request Body:\n$requestJson")
            Log.d(TAG, "==========================")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to format request: ${e.message}")
            Log.d(TAG, "Request: $createUserRequest")
        }
    }

    val response =
        BackendService.request<BaseResponse<UserResponse>>(
            endpoint = endpoint,
            method = HttpMethod.POST,
            bodyParameters = createUserRequest,
            responseType = object : TypeToken<BaseResponse<UserResponse>>() {}.type
        )

    if (BackendService.isDebugMode()) {
        // Log raw response metadata
        Log.d(TAG, "=== UpdateUser RAW RESPONSE METADATA ===")
        Log.d(TAG, "URL: ${response.url}")
        Log.d(TAG, "HTTP Status Code: ${response.httpStatusCode}")
        Log.d(TAG, "Succeeded: ${response.succeeded}")
        Log.d(TAG, "GCRLog: ${response.gcrLog ?: "null"}")
        if (response.errorMessage != null) {
            Log.d(TAG, "Error Message: ${response.errorMessage}")
        }
        if (response.errorCode != null) {
            Log.d(TAG, "Error Code: ${response.errorCode}")
        }
        Log.d(TAG, "========================================")
    }

    if (!response.succeeded || response.payload == null) {
        Log.e(TAG, "Failed to create createUser user: ${response.errorMessage}")
        throw BackendServiceError.ServerError(response.errorMessage)
    }

    if (BackendService.isDebugMode()) {
        // Log response in formatted JSON
        try {
            val responseJson = GsonBuilder()
                .setPrettyPrinting()
                .create()
                .toJson(response.payload)
            Log.d(TAG, "=== UpdateUser RESPONSE ===")
            Log.d(TAG, "Response Body:\n$responseJson")
            Log.d(TAG, "===========================")
            
            // Also log the user details using existing method
            val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
            val ur = payload.results
            Log.d(TAG, "User Details: ${ur.user.describeContents()}")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to format response: ${e.message}")
            val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
            val ur = payload.results
            Log.d(TAG, ur.user.describeContents())
        }
    }

    val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
    val userDataDto =
        UserDataDTO.fromUserResponse(
            payload.results.user
        )
    return userDataDto
}
