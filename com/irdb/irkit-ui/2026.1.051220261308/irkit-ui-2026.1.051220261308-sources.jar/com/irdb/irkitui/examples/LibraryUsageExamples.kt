package com.irdb.irkitui.examples

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.irdb.irkitui.components.IRButton
import com.irdb.irkitui.components.IRCard
import com.irdb.irkitui.theme.IRKitUITheme

/**
 * Example composables demonstrating how to use IRKit-UI components
 */
class LibraryUsageExamples {

    @Composable
    fun BasicButtonExample(onClick: () -> Unit) {
        IRButton(
            text = "Click Me!",
            onClick = onClick
        )
    }

    @Composable
    fun ButtonWithResourceText(@androidx.annotation.StringRes textRes: Int, onClick: () -> Unit) {
        IRButton(
            textRes = textRes,
            onClick = onClick
        )
    }

    @Composable
    fun CardWithContent() {
        IRCard {
            Column {
                Text("Sample Content")
                IRButton(
                    text = "Action Button",
                    onClick = { /* Handle action */ }
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun LibraryUsagePreview() {
    IRKitUITheme {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            LibraryUsageExamples().BasicButtonExample { }
            LibraryUsageExamples().CardWithContent()
        }
    }
}
