package com.irdb.analytics.models

import android.os.Build
import com.irdb.analytics.NetworkType

/**
 * User and session context information attached to all events.
 * Device information is auto-populated by the library if not provided.
 */
data class UserContext(
    // User information
    val userId: String? = null,
    val installationId: String? = null,        // Unique per app installation
    val userType: String? = null,              // "anonymous", "basic", "pro", "enterprise", "creator"
    val username: String? = null,
    val userProfileUrl: String? = null,
    
    // Session information
    val sessionTrackingId: String? = null,     // UUIDv7
    val sessionSource: String = "Android",     // Format: "Android-company-collection"
    
    // Location information (optional)
    val locationIp: String? = null,
    val locationLat: Double? = null,
    val locationLng: Double? = null,
    val locationLookup: String? = null,
    
    // Device information (auto-populated by library if not provided)
    // v2.0: removed deviceManufacturer, deviceCarrier, deviceIFA, cookies
    val deviceModel: String = Build.MODEL,
    val deviceType: String = DEVICE_TYPE_ANDROID,  // "iOS", "Android", or "Desktop"
    val osVersion: String = Build.VERSION.RELEASE,
    val userAgent: String? = null,              // Auto-generated
    val appVersion: String? = null,

    // Library version information (IRKit library version)
    val libraryVersion: String? = null,         // Full version (e.g., "2026.1")
    val libraryMainRelease: String? = null,     // Main release (e.g., "2026")
    val libraryPointRelease: String? = null,    // Point release (e.g., "1")

    // Network information (auto-detected)
    val networkType: NetworkType? = null       // Auto-detected from ConnectivityManager
) {
    companion object {
        // Canonical device-type value for Android clients. Reference this
        // anywhere the deviceType field is set or compared so case can be
        // flipped in one place if the server team changes convention.
        const val DEVICE_TYPE_ANDROID = "Android"
    }
}

