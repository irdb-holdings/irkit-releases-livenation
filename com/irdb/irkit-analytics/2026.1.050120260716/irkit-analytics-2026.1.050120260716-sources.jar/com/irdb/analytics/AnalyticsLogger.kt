package com.irdb.analytics

import android.util.Log

/**
 * Logger for analytics events and debugging.
 * Provides colored LogCat output and conditional logging based on config flags.
 */
internal class AnalyticsLogger(
    private val config: AnalyticsConfig
) {
    private val tag = "IRKit-Analytics"
    private val tagParms = "Analytics-Params"

    /** Tag for one-line event log; filter logcat by this to see event stream for doc comparison. */
    private val eventLogTag = "Analytics_Log"

    /**
     * Log a single line per event when [AnalyticsConfig.enableEventLogLine] is true.
     * Format: eventType + key subtypes (e.g. "status sessionStarted", "scan live matched").
     */
    fun logEventOneLine(eventName: String, parameters: Map<String, Any?>) {
        if (!config.enableEventLogLine) return
        val line = buildEventSummary(eventName, parameters)
        Log.d(eventLogTag, line)
    }

    private fun buildEventSummary(eventName: String, parameters: Map<String, Any?>): String {
        return when (eventName) {
            "status" -> {
                val statusType = parameters["statusType"]?.toString() ?: "?"
                "status $statusType"
            }
            "scan" -> {
                val scanType = parameters["scanType"]?.toString() ?: "?"
                val matched = parameters["matched"] as? Boolean
                val failed = parameters["failed"] as? Boolean == true
                val hasButtonSource = parameters.containsKey("buttonSource")
                val hasImageUrlOfScan = parameters.containsKey("imageUrlOfScan")
                val isSubmission = hasButtonSource && hasImageUrlOfScan
                val suffix = when {
                    failed -> "failed"
                    matched == true -> "matched"
                    isSubmission -> "submitted"
                    else -> "noMatch"
                }
                "scan $scanType $suffix"
            }
            "view" -> {
                val viewType = parameters["viewType"]?.toString() ?: "?"
                val viewSource = parameters["viewSource"]?.toString() ?: "?"
                "view $viewType $viewSource"
            }
            "buttonPressed" -> {
                val buttonType = parameters["buttonType"]?.toString() ?: "?"
                val buttonSource = parameters["buttonSource"]?.toString() ?: "?"
                "buttonPressed $buttonType $buttonSource"
            }
            else -> eventName + (parameters["statusType"]?.toString()?.let { " $it" } ?: "")
        }
    }
    
    fun logEvent(eventName: String, parameters: Map<String, Any?>) {
        if (config.enableDebugLogging) {
            // Add special handling for scan events to make "not recognized" more explicit
            val matched = parameters["matched"] as? Boolean
            val failed = parameters["failed"] as? Boolean == true
            
            // Distinguish between "Scan Submitted" and "Scan Result — No Match" events
            // Submission events have buttonSource and imageUrlOfScan
            // Result events have trackingId and similarCount but no buttonSource
            val hasButtonSource = parameters.containsKey("buttonSource")
            val hasImageUrlOfScan = parameters.containsKey("imageUrlOfScan")
            val isSubmissionEvent = hasButtonSource && hasImageUrlOfScan
            
            val isNotRecognized = eventName == "scan" && matched == false && !failed && !isSubmissionEvent
            
            val mockPrefix = if (config.enableMocking) "[MOCK] " else ""
            
            if (isNotRecognized) {
                Log.d(tagParms, "🔵 $mockPrefix Event: $eventName (❌ Image NOT RECOGNIZED)")
            } else if (isSubmissionEvent && matched == false) {
                Log.d(tagParms, "🔵 $mockPrefix Event: $eventName (📤 Scan Submitted)")
            } else {
                Log.d(tagParms, "🔵 $mockPrefix Event: $eventName")
            }
            Log.d(tagParms, "📦 Parameters:")
            // v2.1: locationLat/locationLng/locationIP all ride in the JSON body
            parameters.forEach { (key, value) ->
                val displayValue = value?.toString() ?: "null"
                Log.d(tagParms, "  • $key: $displayValue")
            }
            Log.d(tagParms, "─".repeat(50))
        }
    }
    
    fun logDebug(message: String) {
        if (config.enableDebugLogging) {
            Log.d(tag, message)
        }
    }
    
    fun logError(message: String, throwable: Throwable? = null) {
        Log.e(tag, "❌ $message", throwable)
    }
    
    fun logNetworkCall(endpoint: String, payload: String) {
        if (config.enableDebugLogging) {
            Log.d(tag, "📡 POST $endpoint")
            Log.d(tag, "📤 Payload: $payload")
        }
    }
    
    fun logNetworkResponse(statusCode: Int, response: String) {
        if (config.enableDebugLogging) {
            Log.d(tag, "📥 Response [$statusCode]: $response")
        }
    }
}

