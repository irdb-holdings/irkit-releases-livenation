package com.irdb.irkitui.ui.dialogs.ircode.panels

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

object TagsDisplayPanelDimens {
    val chipHorizontalPadding = 5.dp
    val chipVerticalPadding = 2.dp
    val chipCornerRadius = 5.dp
    val chipHorizontalSpacing = 12.dp
    val chipVerticalSpacing = 12.dp
    val fontSize = 14.sp
}

/**
 * Uses simple Column/Row layout instead of FlowRow to avoid experimental API
 */
@Composable
fun TagsDisplayPanel(
    tags: List<String>,
    modifier: Modifier = Modifier,
    contentPadding: PaddingValues = PaddingValues(0.dp),
    tagsLabel: String = "Tags"
) {
    Row(modifier = modifier.padding(contentPadding)) {
        Text(
            text = tagsLabel,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 16.sp,
            modifier = Modifier.weight(1f)
        )
        // Use Column with Row children as stable alternative to FlowRow
        Column(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(TagsDisplayPanelDimens.chipVerticalSpacing)
        ) {
            tags.chunked(3).forEach { rowTags ->
                Row(
                    horizontalArrangement = Arrangement.spacedBy(TagsDisplayPanelDimens.chipHorizontalSpacing)
                ) {
                    rowTags.forEach { tagLabel ->
                        TagChip(text = tagLabel)
                    }
                }
            }
        }
    }
}

@Composable
private fun TagChip(text: String) {
    Surface(
        color = MaterialTheme.colorScheme.primary,
        shape = RoundedCornerShape(TagsDisplayPanelDimens.chipCornerRadius)
    ) {
        Text(
            text = text.uppercase(),
            color = MaterialTheme.colorScheme.onPrimary,
            fontSize = TagsDisplayPanelDimens.fontSize,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .clip(RoundedCornerShape(TagsDisplayPanelDimens.chipCornerRadius))
                .padding(
                    horizontal = TagsDisplayPanelDimens.chipHorizontalPadding,
                    vertical = TagsDisplayPanelDimens.chipVerticalPadding
                )
        )
    }
}
