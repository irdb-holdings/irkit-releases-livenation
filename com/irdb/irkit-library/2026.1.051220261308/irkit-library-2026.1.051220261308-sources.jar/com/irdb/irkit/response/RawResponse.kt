package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName
import com.irdb.irkit.dto.ImageDto

data class RawResponse(

    @SerializedName("ImageAlreadyExists")
    val imageAlreadyExists: Boolean = false,

    @SerializedName("Image")
    val image: ImageDto? = null,

    @SerializedName("Images")
    val images: List<ImageDto> = emptyList()
)
