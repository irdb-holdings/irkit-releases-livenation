package com.irdb.analytics.models

/**
 * Snapshot of the network / location fields that [com.irdb.analytics.AnalyticsClient]
 * attaches to every analytics event payload.
 *
 * Every field here mirrors exactly what would be written into the event
 * `parameters` map by `buildEventParameters()` at the moment the snapshot is
 * taken. Intended for debugging surfaces (Playground, analytics test app)
 * that need to show the developer what the next event will actually send.
 */
data class AnalyticsDebugInfo(
    /** Value sent in the `network` field (e.g. "wifi", "4g", "offline"). */
    val networkType: String,

    /** Value sent in the `locationIP` field — cached result of `/myip`. */
    val locationIp: String?,

    /** Phone's own local IP (not sent to analytics; shown for comparison). */
    val deviceLocalIp: String?,

    /** Value sent in the `locationLat` field. */
    val locationLat: Double?,

    /** Value sent in the `locationLng` field. */
    val locationLng: Double?,

    /**
     * Captured failure message when `FusedLocationProviderClient.requestLocationUpdates`
     * throws on a non-GMS device (Amazon Fire, Huawei post-2019, de-googled
     * ROMs). Null on healthy devices. Lets QA tell "no location yet" from
     * "fused broken" at a glance.
     */
    val locationUnavailableReason: String? = null,

    /**
     * Timestamp of the last exhausted `/myip` failure cycle (3 attempts
     * failed). 0 when `/myip` is currently healthy or hasn't been tried
     * yet. Lets QA see "we tried N seconds ago and gave up" in the
     * Playground panel without grepping logcat.
     */
    val locationIpLastFailureAt: Long = 0L,
)
