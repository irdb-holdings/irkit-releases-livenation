package com.irdb.analytics

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import com.irdb.analytics.models.UserContext

/**
 * Automatically detects device information from Android OS.
 * Falls back to provided values if auto-detection fails.
 */
internal class DeviceInfoDetector(
    private val context: Context
) {
    private val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    
    fun detectDeviceInfo(): DeviceInfo {
        return DeviceInfo(
            deviceModel = Build.MODEL,
            deviceType = getDeviceType(),
            osVersion = Build.VERSION.RELEASE,
            userAgent = generateUserAgent(),
            networkType = detectNetworkType()
        )
    }
    
    private fun getDeviceType(): String {
        return UserContext.DEVICE_TYPE_ANDROID
    }
    
    private fun generateUserAgent(): String {
        return "Android/${Build.VERSION.RELEASE} (${Build.MODEL}; ${Build.MANUFACTURER})"
    }
    
    private fun detectNetworkType(): NetworkType {
        val network = connectivityManager?.activeNetwork ?: return NetworkType.OFFLINE
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return NetworkType.UNKNOWN
        
        return when {
            !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) -> NetworkType.OFFLINE
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> NetworkType.WIFI
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkType.ETHERNET
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) ->
                classifyCellularNetwork(capabilities)
            else -> NetworkType.UNKNOWN
        }
    }

    /**
     * Classifies cellular into 2G/3G/4G/5G for the analytics `network` field.
     *
     * Previous logic used only [NetworkCapabilities.linkDownstreamBandwidthKbps]. On real
     * devices that value is often `0` (unknown / not yet estimated), which incorrectly mapped
     * every idle or freshly-connected 5G/LTE radio to `cellular2g`. Prefer OS signals:
     * [TelephonyManager.getDataNetworkType] when available (requires telephony read access on
     * API 31+), then bandwidth thresholds only when the estimate is positive, else
     * [NetworkType.UNKNOWN].
     */
    private fun classifyCellularNetwork(capabilities: NetworkCapabilities): NetworkType {
        networkTypeFromTelephonyOrNull()?.let { return it }

        val bw = capabilities.linkDownstreamBandwidthKbps
        if (bw > 0) {
            return when {
                bw >= 20_000 -> NetworkType.CELLULAR_5G
                bw >= 10_000 -> NetworkType.CELLULAR_4G
                bw >= 2_000 -> NetworkType.CELLULAR_3G
                else -> NetworkType.CELLULAR_2G
            }
        }

        return NetworkType.UNKNOWN
    }

    /**
     * Maps [TelephonyManager.getDataNetworkType] to analytics [NetworkType], or null if
     * unavailable (no permission on API 31+, unknown type, OEM-specific throws, etc.).
     *
     * The whole probe is wrapped in a broad catch because OEM telephony stacks
     * have been observed to throw beyond the documented surface:
     *   - SecurityException: permission revoked at runtime (some Xiaomi/HONOR builds)
     *   - IllegalStateException: SIM in transition (Samsung One UI 6)
     *   - Other Throwable: anything else from a vendor telephony patch we
     *     haven't seen yet. The network-type field is best-effort metadata —
     *     we never want a bad guess here to crash the recognition flow.
     */
    @Suppress("DEPRECATION")
    private fun networkTypeFromTelephonyOrNull(): NetworkType? {
        return try {
            val telephony = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
                ?: return null
            val tm = telephonyForDefaultData(telephony)
            mapTelephonyDataNetworkType(tm.dataNetworkType)
        } catch (_: SecurityException) {
            null
        } catch (_: IllegalStateException) {
            null
        } catch (_: Throwable) {
            null
        }
    }

    private fun telephonyForDefaultData(telephony: TelephonyManager): TelephonyManager {
        val subId = SubscriptionManager.getDefaultDataSubscriptionId()
        return if (subId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
            telephony.createForSubscriptionId(subId)
        } else {
            telephony
        }
    }
}

/**
 * Maps `TelephonyManager.getDataNetworkType()` / [TelephonyManager.dataNetworkType] to
 * analytics cellular buckets. Exposed for unit tests.
 */
internal fun mapTelephonyDataNetworkType(dataNetworkType: Int): NetworkType? {
    // TelephonyManager.NETWORK_TYPE_LTE_CA was public through older APIs; radio still returns 19
    // but the int constant was dropped from public TelephonyManager stubs on newer compileSdk.
    val networkTypeLteCa = 19
    return when (dataNetworkType) {
        TelephonyManager.NETWORK_TYPE_UNKNOWN -> null
        TelephonyManager.NETWORK_TYPE_NR -> NetworkType.CELLULAR_5G
        TelephonyManager.NETWORK_TYPE_LTE,
        networkTypeLteCa -> NetworkType.CELLULAR_4G
        TelephonyManager.NETWORK_TYPE_GPRS,
        TelephonyManager.NETWORK_TYPE_EDGE,
        TelephonyManager.NETWORK_TYPE_GSM,
        TelephonyManager.NETWORK_TYPE_CDMA,
        TelephonyManager.NETWORK_TYPE_1xRTT,
        TelephonyManager.NETWORK_TYPE_IDEN -> NetworkType.CELLULAR_2G
        TelephonyManager.NETWORK_TYPE_UMTS,
        TelephonyManager.NETWORK_TYPE_EVDO_0,
        TelephonyManager.NETWORK_TYPE_EVDO_A,
        TelephonyManager.NETWORK_TYPE_EVDO_B,
        TelephonyManager.NETWORK_TYPE_EHRPD,
        TelephonyManager.NETWORK_TYPE_HSPA,
        TelephonyManager.NETWORK_TYPE_HSDPA,
        TelephonyManager.NETWORK_TYPE_HSUPA,
        TelephonyManager.NETWORK_TYPE_HSPAP,
        TelephonyManager.NETWORK_TYPE_TD_SCDMA -> NetworkType.CELLULAR_3G
        TelephonyManager.NETWORK_TYPE_IWLAN -> NetworkType.CELLULAR_4G
        else -> null
    }
}

/**
 * Device information model
 */
/**
 * Device information model (v2.0: removed deviceManufacturer, deviceCarrier, deviceIFA)
 */
data class DeviceInfo(
    val deviceModel: String,
    val deviceType: String,
    val osVersion: String,
    val userAgent: String,
    val networkType: NetworkType
)

