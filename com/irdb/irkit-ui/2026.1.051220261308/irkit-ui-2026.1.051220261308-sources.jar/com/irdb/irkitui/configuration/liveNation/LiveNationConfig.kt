package com.irdb.irkitui.configuration.liveNation

import com.irdb.irkitui.BuildConfig
import com.irdb.irkitui.configuration.ClientConfigBase
import com.irdb.irkitui.configuration.ExpandedCloseButtonPlacement

/**
 * Configuration values for the LiveNation client.
 * Contains Dev, Staging, and Production variants.
 *
 * Note: LiveNation uses companyName "LiveNation" to distinguish its analytics data
 * from the main IRCODE app. sessionSource is built dynamically.
 */
object LiveNationConfig {

    const val useIRCODE = true
    object Dev : ClientConfigBase() {
        override val clientName = "LiveNation"
        override val backendUrl = "https://us-central1-ircode-1a662.cloudfunctions.net/production-v1_44"
        override val irEngineUrl = "https://production.backend.irdb.com/v1"
        override val irkitSubscriptionKey = "EB3D9136E2F148DF9592D50E03A6BA2D26364ECABAAA4072948A6ABADC0A46EE6015445E975C427EA4D2CFC7A7617073"
        override val analyticsApiKey = "EB3D9136E2F148DF9592D50E03A6BA2D26364ECABAAA4072948A6ABADC0A46EE6015445E975C427EA4D2CFC7A7617073"
        override val analyticsApiKeyHeaderName = "sdkapikey"
        override val companyName = "LiveNation"
        override val analyticsBucketName = "--"
        override val environment = "production"
        override val prefsEncryptionKey = "AH7H9qCQuffHwF8KjFdvX9toH8rCit"
        override val prefsEncryptionSalt = "AH7H9qC3QuffHwdF8vX9toH8rC33dgit"
        override val expandedCloseButtonPlacement get() = ExpandedCloseButtonPlacement.bottomCenter
        override val skipNotifiationCards = true
    }

    object Staging : ClientConfigBase() {
        override val clientName = "LiveNation NOT SUPPORTED"
        override val backendUrl = "https://us-central1-ircode-1a662.cloudfunctions.net/production-v1_44"
        override val irEngineUrl = "https://production.backend.irdb.com/v1"
        override val irkitSubscriptionKey = "--"
        override val analyticsApiKey = "--"
        override val analyticsApiKeyHeaderName = "sdkapikey"
        override val companyName = "LiveNation NOT SUPPORTED"
        override val analyticsBucketName = "--"
        override val environment = "production"
        override val prefsEncryptionKey = "AH7H9qCQuffHwF8KjFdvX9toH8rCit"
        override val prefsEncryptionSalt = "AH7H9qC3QuffHwdF8vX9toH8rC33dgit"
        override val expandedCloseButtonPlacement get() = ExpandedCloseButtonPlacement.bottomCenter
        override val skipNotifiationCards = true
    }

    object Production : ClientConfigBase() {
        override val clientName = "LiveNation"
        override val backendUrl = "https://us-central1-ircode-1a662.cloudfunctions.net/production-v1_44"
        override val irEngineUrl = "https://production.backend.irdb.com/v1"
        override val irkitSubscriptionKey = "07BCE203B5D44707A8AC03CDC28040ABC6CEB6DC076F458DA30E7075419F73B09013C46BD27B435C9A08F1C60F11A7AD"
        override val analyticsApiKey = "07BCE203B5D44707A8AC03CDC28040ABC6CEB6DC076F458DA30E7075419F73B09013C46BD27B435C9A08F1C60F11A7AD"
        override val analyticsApiKeyHeaderName = "sdkapikey"
        override val companyName = "LiveNation"
        override val analyticsBucketName = "--"
        override val environment = "production"
        override val prefsEncryptionKey = "AH7H9qCQuffHwF8KjFdvX9toH8rCit"
        override val prefsEncryptionSalt = "AH7H9qC3QuffHwdF8vX9toH8rC33dgit"
        override val expandedCloseButtonPlacement get() = ExpandedCloseButtonPlacement.bottomCenter
        override val skipNotifiationCards = true
    }

    /**
     * Returns the appropriate configuration based on the current build flavor.
     */
    val current: ClientConfigBase
        get() = when (BuildConfig.FLAVOR) {
            "staging" -> Staging
            "production" -> Production
            else -> Dev
        }
}
