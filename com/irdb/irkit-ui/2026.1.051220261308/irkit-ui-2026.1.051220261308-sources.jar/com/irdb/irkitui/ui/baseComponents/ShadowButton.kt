package com.irdb.irkitui.ui.baseComponents

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.irdb.irkitui.theme.IRKitThemeAccessor
import com.irdb.irkitui.theme.IRKitUITheme

@Composable
fun ShadowButton(
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
    isRound: Boolean = false,
    backgroundColor: Color? = null, // null means use theme color
    borderColor: Color? = null, // null means use theme color
    content: @Composable () -> Unit
) {
    val colors = IRKitThemeAccessor.colors
    val resolvedBackgroundColor = backgroundColor ?: colors.buttonOverlay
    val resolvedBorderColor = borderColor ?: colors.borderColor
    val shape: Shape = if (isRound) CircleShape else RoundedCornerShape(25.dp)
    val buttonModifier = if (isRound) {
        modifier.size(44.dp)
    } else {
        modifier
    }

    Row(
        modifier = buttonModifier
            .shadow(
                elevation = 4.dp,
                shape = shape,
                spotColor = Color.White.copy(alpha = 0.2f)
            )
            .border(
                width = 1.dp,
                color = resolvedBorderColor,
                shape = shape
            )
            .background(
                color = resolvedBackgroundColor,
                shape = shape
            )
            .clickable(onClick = onClick)
            .padding(if (isRound) 8.dp else 6.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        content()
    }
}

@Preview(showBackground = false)
@Composable
fun ShadowButtonPreview() {
    IRKitUITheme {
        Column(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(8.dp)
        ) {
            // Text only button
            ShadowButton(
                onClick = { }
            ) {
                Text(
                    text = "Click Me",
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
                )
            }

            // Button with icon
            ShadowButton(
                onClick = { }
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add",
                    tint = Color.White,
                    modifier = Modifier.padding(8.dp)
                )
            }

            // Round button with icon
            ShadowButton(
                onClick = { },
                isRound = true
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Add",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }
        }
    }
}
