package com.irdb.irkitui.theme

import androidx.compose.ui.graphics.Color

/**
 * Pre-defined theme presets for IRKit-UI.
 *
 * These presets provide ready-to-use themes that clients can select
 * via their configuration. The Dark preset matches the current iOS-style
 * appearance exactly.
 *
 * Usage in client config:
 * ```kotlin
 * object MyClientConfig : ClientConfigBase() {
 *     override val theme get() = IRKitThemePresets.Dark
 *     // or for custom branding:
 *     override val theme get() = IRKitThemePresets.Blue
 * }
 * ```
 */
object IRKitThemePresets {

    /**
     * Dark theme - matches the current iOS-style appearance.
     *
     * This is the default theme and uses:
     * - Black/dark gray backgrounds
     * - Gold accent color for selections
     * - White text for primary content
     * - Gray tones for secondary content
     */
    val Dark = IRKitTheme(
        colors = IRKitColorScheme(
            // Backgrounds
            background = Color(0xFF000000),           // IRKitBackgroundColor
            surface = Color(0xFF1C1C1E),              // CreateIRCodeCardBackgroundColor
            surfaceVariant = Color(0xFF2D2D2D),       // ModeSelectorBackgroundColor
            cardBackground = Color(0xFF3A3A3C),       // RecognitionNotification card color

            // Primary/Accent
            primary = Color(0xFF6B4EFF),              // BuyButton purple
            onPrimary = Color.White,
            accent = Color(0xFFFFD700),               // ModeSelectorSelectedColor (gold)
            onAccent = Color.Black,

            // Text
            textPrimary = Color(0xFFFFFFFF),          // CreateIRCodeTitleColor
            textSecondary = Color(0xFF8E8E93),        // CreateIRCodeSubtitleColor / FormLabel
            textDisabled = Color(0xFF545458),         // CreateIRCodeDisabledTextColor

            // Selector
            selectorBackground = Color(0xFF2D2D2D),   // ModeSelectorBackgroundColor
            selectorSelected = Color(0xFFFFD700),     // ModeSelectorSelectedColor
            onSelectorSelected = Color.Black,
            selectorUnselectedText = Color.White,

            // Camera
            guidingRectangle = Color.White,
            guidingRectangleActive = Color(0xFFFFC107), // Yellow when recognized
            cameraOverlay = Color.Black.copy(alpha = 0.2f),

            // Status & Badges
            success = Color(0xFF4CAF50),              // Standard green
            badgeBackground = Color(0xFF9381FF),      // ProBadge lavender
            tagBackground = Color(0xFF545458),        // CreateIRCodeSoonTagBackgroundColor
            tagText = Color(0xFFFFFFFF),              // CreateIRCodeSoonTagTextColor

            // Icons & Misc
            iconBackground = Color(0xFF3A3A3C),       // CreateIRCodeIconBackgroundColor
            buttonOverlay = Color.Black.copy(alpha = 0.45f), // ShadowButton
            borderColor = Color.DarkGray.copy(alpha = 0.3f)
        ),
        typography = IRKitTypography.default()
    )

    /**
     * Blue theme - alternative theme with blue accent.
     *
     * Uses blue instead of gold for accent colors, providing
     * a more corporate/professional appearance.
     */
    val Blue = IRKitTheme(
        colors = Dark.colors.copy(
            primary = Color(0xFF1E88E5),              // Material Blue 600
            accent = Color(0xFF42A5F5),               // Material Blue 400
            onAccent = Color.White,
            selectorSelected = Color(0xFF1E88E5),
            onSelectorSelected = Color.White,
            guidingRectangleActive = Color(0xFF42A5F5),
            badgeBackground = Color(0xFF64B5F6)       // Material Blue 300
        ),
        typography = IRKitTypography.default()
    )

    /**
     * Light theme - for future use.
     *
     * Inverts the dark theme for light mode support.
     * Currently a placeholder - not fully implemented.
     */
    val Light = IRKitTheme(
        colors = IRKitColorScheme(
            // Backgrounds
            background = Color(0xFFF5F5F5),
            surface = Color.White,
            surfaceVariant = Color(0xFFE0E0E0),
            cardBackground = Color.White,

            // Primary/Accent
            primary = Color(0xFF6B4EFF),
            onPrimary = Color.White,
            accent = Color(0xFFFFB300),               // Amber 600 for better contrast
            onAccent = Color.Black,

            // Text
            textPrimary = Color(0xFF212121),
            textSecondary = Color(0xFF757575),
            textDisabled = Color(0xFFBDBDBD),

            // Selector
            selectorBackground = Color(0xFFE0E0E0),
            selectorSelected = Color(0xFFFFB300),
            onSelectorSelected = Color.Black,
            selectorUnselectedText = Color(0xFF424242),

            // Camera
            guidingRectangle = Color(0xFF424242),
            guidingRectangleActive = Color(0xFFFFC107),
            cameraOverlay = Color.White.copy(alpha = 0.3f),

            // Status & Badges
            success = Color(0xFF4CAF50),
            badgeBackground = Color(0xFF9381FF),
            tagBackground = Color(0xFFBDBDBD),
            tagText = Color(0xFF212121),

            // Icons & Misc
            iconBackground = Color(0xFFE0E0E0),
            buttonOverlay = Color.White.copy(alpha = 0.7f),
            borderColor = Color.LightGray.copy(alpha = 0.5f)
        ),
        typography = IRKitTypography.default()
    )
}
