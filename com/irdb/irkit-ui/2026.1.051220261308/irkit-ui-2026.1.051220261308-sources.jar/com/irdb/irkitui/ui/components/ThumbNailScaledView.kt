package com.irdb.irkitui.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.irdb.irkit.ImageModel
import com.irdb.irkitui.ui.baseComponents.rememberImageLoader

@Composable
fun ThumbNailScaled(image: ImageModel, isExpanded: Boolean) {
    val imageLoader = rememberImageLoader()
    val thumbSize = if (isExpanded) 96.dp else 92.dp
    val corner = 15.dp
    val shape = RoundedCornerShape(
        topStart = corner,
        bottomStart = corner,
        topEnd = if (isExpanded) corner else 8.dp,
        bottomEnd = if (isExpanded) corner else 8.dp
    )

    Box(
        modifier = Modifier
            .then(if (!isExpanded) Modifier.padding(bottom = 3.dp) else Modifier)
            .size(thumbSize)
            .background(
                color = Color.Transparent,
                shape = shape
            )
    ) {
        AsyncImage(
            model = image.displayImageUrl,
            contentDescription = null,
            imageLoader = imageLoader,
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .clip(shape)
                .align(Alignment.Center)
        )
    }
}
