package com.irdb.irkitui.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.irdb.irkit.ImageModel
import com.irdb.irkitui.ui.baseComponents.rememberImageLoader

@Composable
fun FullSizeImage(
    image: ImageModel,
    isExpanded: Boolean,
    onImageTap: (() -> Unit)? = null
) {
    val imageLoader = rememberImageLoader()

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(
                color = Color.Transparent,
                shape = RoundedCornerShape(
                    topStart = 15.dp,
                    bottomStart = 15.dp,
                    topEnd = if (isExpanded) 15.dp else 2.dp,
                    bottomEnd = if (isExpanded) 15.dp else 2.dp
                )
            )
            .then(
                if (onImageTap != null) {
                    Modifier.clickable { onImageTap() }
                } else {
                    Modifier
                }
            )
    ) {
        if (image is ImageModel.FullImage && image.imageWidth > 0 && image.imageHeight > 0) {
            AsyncImage(
                model = image.displayImageUrl,
                contentDescription = null,
                imageLoader = imageLoader,
                contentScale = ContentScale.FillWidth,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(image.imageWidth.toFloat() / image.imageHeight.toFloat())
                    .clip(
                        RoundedCornerShape( // Add this clip modifier
                            topStart = 15.dp,
                            bottomStart = 15.dp,
                            topEnd = if (isExpanded) 15.dp else 2.dp,
                            bottomEnd = if (isExpanded) 15.dp else 2.dp
                        )
                    )
                    .align(Alignment.Center)
            )
        } else {
            AsyncImage(
                model = image.displayImageUrl,
                contentDescription = null,
                imageLoader = imageLoader,
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 9f) // Default to landscape if dimensions unknown
                    .clip(
                        RoundedCornerShape( // Add this clip modifier
                            topStart = 15.dp,
                            bottomStart = 15.dp,
                            topEnd = if (isExpanded) 15.dp else 2.dp,
                            bottomEnd = if (isExpanded) 15.dp else 2.dp
                        )
                    )
                    .align(Alignment.Center)
            )
        }
    }
}
