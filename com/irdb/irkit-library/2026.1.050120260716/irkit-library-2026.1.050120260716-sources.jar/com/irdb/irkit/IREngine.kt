package com.irdb.irkit

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import android.util.Log
import android.view.View
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.ui.geometry.Offset
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import com.google.gson.Gson
import com.irdb.irkit.models.LiveRecognitionApiResponse
import com.irdb.irkit.config.IRKitConfigManager
import com.irdb.irkit.IRKit
import com.irdb.irkit.enums.CardTypes


import com.irdb.irkit.enums.RecognitionState
import com.irdb.irkit.models.ClipInfoData
import com.irdb.irkit.models.toClipInfoData
import com.irdb.irkit.utils.DeviceCapabilityDetector
import com.irdb.irkit.utils.DeviceCapabilityDetector.DeviceCapabilities
import com.irdb.irkit.utils.DeviceCapabilityDetector.DeviceTier
import android.graphics.Rect
import android.util.Size
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager
import java.util.Date
import java.util.UUID
import java.util.concurrent.Executor
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.max
import kotlin.math.sqrt
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

private fun ImageModel?.getCampaignIdForAnalytics(): Long? {
    return this?.campaignId?.takeIf { campaignId -> campaignId > 0 }?.toLong()
}

private fun ImageModel?.getCampaignNameForAnalytics(): String? {
    return this?.campaignName?.takeIf { campaignName -> campaignName.isNotEmpty() }
}

class IREngine(private val context: Context) {
    private val QUERY_IMAGE_FOVIATION_ZOOM_FACTOR = 0.8f
    private val SEGMENTATION_REGION_INSET_PERCENT = 0.12
    private val TAG = "IREngine"
    private val Timing_Tag = "ImageResult"
    private val CAMERA_SPEC_TAG = "CameraSpec"

    // DEBUG ONLY: Enable Charles Proxy routing for network debugging
    // Set to true to route POST requests through Charles Proxy (192.168.50.188:8888)
    // ONLY works in DEBUG builds - will be ignored in production
    private val ENABLE_CHARLES_PROXY = BuildConfig.DEBUG && BuildConfig.ENABLE_CHARLES_PROXY

    private var cameraProvider: ProcessCameraProvider? = null
    private var imageCapture: ImageCapture? = null
    private var imageAnalyzer: ImageAnalysis? = null
    private val imageProcessor = ImageProcessor()
    private lateinit var cameraExecutor: Executor
    private var lastProcessingTime: Long = 0
    private val processingInterval = 300L // 300ms = 0.3s, same as iOS
    private var trackingId = generateTrackingId()

    // Serializes /lookup network calls so we never fire two at once. Kotlin's
    // Mutex is FIFO-fair — suspended waiters resume in arrival order, so the
    // recognition order is preserved. The cache fast path runs BEFORE the
    // mutex (lock-free), so cache hits never serialize.
    private val lookupMutex = Mutex()
    private var configuration: IRKitConfiguration? = null

    // Frame sequencing for live image processing
    private val frameSequenceCounter = AtomicLong(0)
    private val lastCompletedFrameNumber = AtomicLong(0)
    private val activeUploads = ConcurrentHashMap<String, Pair<HttpURLConnection, Long>>()

    /**
     * Sets the configuration for the IR Engine
     */
    fun setConfiguration(config: IRKitConfiguration) {
        this.configuration = config
    }

    private fun getBaseUrl(): String {
        return configuration?.getIREngineUrl() ?: throw IllegalStateException("IRKitConfiguration not set. Call IREngine.setConfiguration() first.")
    }
    private val tenantBucketName = "irdbMain"
    private val gson = Gson()
    private val gyroscopeManager = GyroscopeManager(context)
    private var isDeviceStable = true
    private var recognitionState = RecognitionState.PAUSED
    private var camera: Camera? = null
    private var preview: Preview? = null
    private var lastFullQueryTime: Long? = null
    // REMOVED: private val uploadSemaphore = Semaphore(1) - Now using LiveRequestQueue for 10 concurrent requests
    private val requestQueue = LiveRequestQueue()

    // Represents a single camera capturing session default value
    private var sessionId = UUID.randomUUID().toString()

    val isRecognitionStatePaused: Boolean
        get() = recognitionState == RecognitionState.PAUSED

    private val debugging = false

    // Toggle flag to control when images should be saved to gallery (for triple-tap feature)
    // Stays enabled until toggled off or app restarts
    private var isSaveToGalleryEnabled = false

    // Device capabilities for adaptive resolution
    private var deviceCapabilities: DeviceCapabilities? = null

    // Segmentation manager for AI-powered bounding box crop
    @Volatile
    private var segmentationManager: com.irdb.irkit.segmentation.SegmentationManager? = null

    // Callback for segmentation bounding box overlay updates.
    // Receives the normalized bbox [0,1] and the rotated camera frame size so the
    // overlay can correctly account for the PreviewView FILL_CENTER transform.
    var onSegmentationBboxUpdate: ((android.graphics.RectF?, android.util.Size?) -> Unit)? = null

    // Callback for segmentation mask bitmap (debug visualization of model output)
    var onSegmentationMaskUpdate: ((android.graphics.Bitmap?) -> Unit)? = null

    // Debug overlay callback for visual debugging
    var onDebugOverlayUpdate: ((
        liveModeCropBounds: Rect?,
        foveatedCropBounds: List<Rect>?,
        imageResolution: Size?
    ) -> Unit)? = null

    fun startNewSession() {
        sessionId = UUID.randomUUID().toString()
        Log.d("sessionId", "Starting new visual search session with ID: $sessionId")
    }

    val previewView: PreviewView by lazy {
        PreviewView(context).apply {
            // Samsung devices often work better with PERFORMANCE mode
            implementationMode = if (isSamsungDevice()) {
                PreviewView.ImplementationMode.PERFORMANCE
            } else {
                PreviewView.ImplementationMode.COMPATIBLE
            }
        }
    }

    companion object {
        private const val FULL_QUERY_INTERVAL = 3.0 // 3 seconds between full queries
    }

    // Lookup workflow confirmed working — enabled for all builds
    private val USE_LOOKUP_FOR_RECOGNITION = true

    private fun isSamsungDevice(): Boolean {
        return android.os.Build.MANUFACTURER.equals("samsung", ignoreCase = true)
    }

    fun getCamera(): Camera? = camera

    fun initializeCamera(lifecycleOwner: LifecycleOwner, previewView: View) {
        cameraExecutor = ContextCompat.getMainExecutor(context)
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)

        // Start gyroscope monitoring
        gyroscopeManager.startGyroscopeUpdates { stable ->
            isDeviceStable = stable
        }

        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            bindCameraUseCases(lifecycleOwner, previewView)
        }, cameraExecutor)
    }

    fun getImageCapture(): ImageCapture? {
        return imageCapture
    }

    fun pauseRecognition() {
        recognitionState = RecognitionState.PAUSED
        // Clear all active requests when pausing
        requestQueue.clearAll()
    }

    fun resumeRecognition() {
        recognitionState = RecognitionState.ACTIVE
        lastProcessingTime = 0
        lastFullQueryTime = null // Reset full query timer to allow immediate processing
        startNewSession()
    }

    /**
     * Toggle saving processed images to gallery.
     * This is triggered by triple-tapping "Create IRCODE" text.
     * The toggle stays enabled until toggled off or app restarts.
     */
    fun toggleSaveToGallery() {
        isSaveToGalleryEnabled = !isSaveToGalleryEnabled
        Log.d(TAG, "Save to gallery toggled: ${if (isSaveToGalleryEnabled) "ENABLED" else "DISABLED"}")
    }

    /**
     * Check if save to gallery is currently enabled.
     */
    fun isSaveToGalleryEnabled(): Boolean {
        return isSaveToGalleryEnabled
    }

    fun pausePreview() {
        // Unbinding the preview here can lead to race conditions with CameraX's lifecycle management,
        // potentially causing a black screen on app resume. CameraX handles this automatically.
        // The preview is now allowed to continue, while frame processing is paused via pauseRecognition().
    }

    fun resumePreview() {
        // Rebinding the preview manually can conflict with CameraX. It's safer to let
        // CameraX manage the preview state based on the LifecycleOwner.
    }

    fun cleanup() {
        gyroscopeManager.stopGyroscopeUpdates()
        // Cleanup request queue
        requestQueue.cleanup()
        // Cleanup segmentation resources
        segmentationManager?.cleanup()
        segmentationManager = null
        // End debug frame saver session
        if (BuildConfig.DEBUG) {
            com.irdb.irkit.segmentation.SegmentationDebugSaver.endSession()
        }
    }

    /**
     * Reload the segmentation model if the backend returned a different model name.
     * Safe to call from any thread — delegates to [SegmentationManager.reloadIfModelChanged].
     * No-op if the model hasn't changed or segmentation was never initialized.
     */
    fun reloadSegmentationModelIfChanged() {
        segmentationManager?.reloadIfModelChanged()
    }

    /**
     * Sets the debug overlay callback for visual debugging of camera crops and resolutions.
     *
     * @param callback Function that receives debug overlay data:
     * - liveModeCropBounds: Rect for live mode crop region
     * - foveatedCropBounds: List of Rects for foveated crop regions (1x, 2x, 4x zoom)
     * - imageResolution: Size of the source image from ImageAnalysis
     */
    fun setDebugOverlayCallback(callback: ((
        liveModeCropBounds: Rect?,
        foveatedCropBounds: List<Rect>?,
        imageResolution: Size?
    ) -> Unit)?) {
        onDebugOverlayUpdate = callback
    }

    /**
     * Enables or disables debug overlay logging and callbacks.
     *
     * @param enabled Whether to enable debug overlay features
     */
    fun setDebugOverlayEnabled(enabled: Boolean) {
        if (enabled) {
            Log.i(CAMERA_SPEC_TAG, "Debug overlay enabled")
            // Don't clear the callback when enabling - keep it for when debug overlay is toggled on
        } else {
            Log.i(CAMERA_SPEC_TAG, "Debug overlay disabled")
            // Don't clear the callback when disabling - just log that it's disabled
            // The overlay composable will handle the showOverlay parameter
        }
    }

    private fun bindCameraUseCases(lifecycleOwner: LifecycleOwner, previewView: View) {
        // Detect device capabilities for adaptive resolution
        deviceCapabilities = DeviceCapabilityDetector.detect(context, cameraProvider)
        val capabilities = DeviceCapabilityDetector.adjustForSamsungDevice(deviceCapabilities!!)

        // Start debug frame saver session if enabled
        if (BuildConfig.DEBUG && com.irdb.irkit.segmentation.SegmentationConfig.saveDebugFrames) {
            com.irdb.irkit.segmentation.SegmentationDebugSaver.startSession(context)
        }

        // Initialize segmentation (runs warmup benchmark and auto-tunes on background thread)
        if (com.irdb.irkit.segmentation.SegmentationConfig.segmentationEnabled) {
            CoroutineScope(Dispatchers.Default).launch {
                try {
                    val manager = com.irdb.irkit.segmentation.SegmentationManager(context)
                    manager.initialize(capabilities.deviceTier)
                    segmentationManager = manager
                    Log.d(TAG, "Segmentation initialized: enabled=${com.irdb.irkit.segmentation.SegmentationConfig.segmentationEnabled}")
                } catch (e: Exception) {
                    Log.e(TAG, "Segmentation init failed: ${e.message}", e)
                    com.irdb.irkit.segmentation.SegmentationConfig.segmentationEnabled = false
                }
            }
        }

        Log.i(CAMERA_SPEC_TAG, "Attempting to bind camera at ${capabilities.optimalResolution.width}x${capabilities.optimalResolution.height}")

        preview = Preview.Builder()
            .setTargetRotation((previewView as PreviewView).display?.rotation ?: 0)
            .build()

        imageCapture = ImageCapture.Builder()
            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
            .setTargetRotation(previewView.display?.rotation ?: 0)
            .build()

        // Try progressive fallback for ImageAnalysis resolution
        val success = bindWithFallback(lifecycleOwner, previewView, capabilities)

        if (!success) {
            Log.e(CAMERA_SPEC_TAG, "All resolution fallbacks failed, using basic Samsung fallback")
            attemptSamsungFallbackInitialization(lifecycleOwner, previewView)
        }
    }

    /**
     * Progressive fallback system for camera binding with different resolutions.
     * Tries each resolution in order until one succeeds.
     */
    private fun bindWithFallback(
        lifecycleOwner: LifecycleOwner,
        previewView: View,
        capabilities: DeviceCapabilities
    ): Boolean {
        val fallbackResolutions = DeviceCapabilityDetector.ResolutionConfig.RESOLUTION_FALLBACK_ORDER

        for (resolution in fallbackResolutions) {
            try {
                Log.i(CAMERA_SPEC_TAG, "Attempting to bind camera at ${resolution.width}x${resolution.height}")

                imageAnalyzer = ImageAnalysis.Builder()
                    .setTargetResolution(resolution)
                    .setBackpressureStrategy(DeviceCapabilityDetector.getBackpressureStrategy(capabilities.deviceTier))
                    .setTargetRotation((previewView as PreviewView).display?.rotation ?: 0)
                    .build()
                    .also {
                        it.setAnalyzer(cameraExecutor) { imageProxy ->
                            processFrame(imageProxy)
                        }
                    }

                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                cameraProvider?.unbindAll()
                camera = cameraProvider?.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    preview,
                    imageCapture,
                    imageAnalyzer
                )

                // Set initial zoom range
                camera?.cameraInfo?.zoomState?.value?.let { zoomState ->
                    Log.d(TAG, "Camera zoom range: ${zoomState.minZoomRatio} to ${zoomState.maxZoomRatio}")
                }

                preview?.setSurfaceProvider((previewView as PreviewView).surfaceProvider)

                Log.i(CAMERA_SPEC_TAG, "Camera bound successfully at ${resolution.width}x${resolution.height}")
                return true

            } catch (e: Exception) {
                Log.w(CAMERA_SPEC_TAG, "Failed to bind at ${resolution.width}x${resolution.height}, trying lower resolution", e)
            }
        }

        return false
    }

    /**
     * Fallback initialization method specifically for Samsung devices
     * when the standard initialization fails. Now works with device tier system.
     */
    private fun attemptSamsungFallbackInitialization(lifecycleOwner: LifecycleOwner, previewView: View) {
        try {
            Log.i(CAMERA_SPEC_TAG, "Attempting Samsung fallback camera initialization")

            // Get device capabilities for Samsung-specific fallback
            val capabilities = deviceCapabilities ?: DeviceCapabilityDetector.detect(context, cameraProvider)
            val samsungCapabilities = DeviceCapabilityDetector.adjustForSamsungDevice(capabilities)

            Log.i(CAMERA_SPEC_TAG, "Samsung fallback using tier: ${samsungCapabilities.deviceTier}")
            Log.i(CAMERA_SPEC_TAG, "Samsung fallback resolution: ${samsungCapabilities.optimalResolution.width}x${samsungCapabilities.optimalResolution.height}")

            // Create a simpler preview configuration for Samsung devices
            val fallbackPreview = Preview.Builder()
                .setTargetRotation((previewView as PreviewView).display?.rotation ?: 0)
                // Don't set target resolution for fallback mode
                .build()

            val fallbackImageCapture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY) // Different capture mode
                .setTargetRotation(previewView.display?.rotation ?: 0)
                .build()

            // Try Samsung-specific resolution fallback
            val samsungFallbackResolutions = listOf(
                android.util.Size(1280, 720),  // Samsung-safe resolution
                android.util.Size(640, 480),   // VGA fallback
                android.util.Size(320, 240)    // QVGA last resort
            )

            var fallbackSuccess = false
            for (resolution in samsungFallbackResolutions) {
                try {
                    Log.i(CAMERA_SPEC_TAG, "Samsung fallback trying ${resolution.width}x${resolution.height}")

                    val fallbackImageAnalyzer = ImageAnalysis.Builder()
                        .setTargetResolution(resolution)
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setTargetRotation(previewView.display?.rotation ?: 0)
                        .build()
                        .also {
                            it.setAnalyzer(cameraExecutor) { imageProxy ->
                                processFrame(imageProxy)
                            }
                        }

                    val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

                    cameraProvider?.unbindAll()

                    // Try binding with all use cases
                    camera = cameraProvider?.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        fallbackPreview,
                        fallbackImageCapture,
                        fallbackImageAnalyzer
                    )

                    preview = fallbackPreview
                    imageCapture = fallbackImageCapture
                    imageAnalyzer = fallbackImageAnalyzer

                    fallbackPreview.setSurfaceProvider(previewView.surfaceProvider)

                    Log.i(CAMERA_SPEC_TAG, "Samsung fallback successful at ${resolution.width}x${resolution.height}")
                    fallbackSuccess = true
                    break

                } catch (e: Exception) {
                    Log.w(CAMERA_SPEC_TAG, "Samsung fallback failed at ${resolution.width}x${resolution.height}, trying lower", e)
                }
            }

            if (!fallbackSuccess) {
                // Last resort: preview only
                Log.w(CAMERA_SPEC_TAG, "Samsung fallback failed, using preview only")
                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                cameraProvider?.unbindAll()
                camera = cameraProvider?.bindToLifecycle(
                    lifecycleOwner,
                    cameraSelector,
                    fallbackPreview
                )
                preview = fallbackPreview
                fallbackPreview.setSurfaceProvider(previewView.surfaceProvider)
            }

        } catch (exc: Exception) {
            Log.e(CAMERA_SPEC_TAG, "Samsung fallback initialization also failed", exc)
        }
    }

    private fun processFrame(imageProxy: ImageProxy) {
        try {
            if (isRecognitionStatePaused) {
                // Silently skip frames when recognition is paused to avoid log spam
                imageProxy.close()
                return
            }

            val currentTime = System.currentTimeMillis()

            // Check if enough time has passed since last processing
            if (currentTime - lastProcessingTime < processingInterval) {
                Log.d(TAG, "Frame skipped: Processing interval not met (${currentTime - lastProcessingTime}ms < ${processingInterval}ms)")
                imageProxy.close()
                return
            }

            // Check device stability unless explicitly ignored
            if (!isDeviceStable) {
                Log.d(TAG, "Frame skipped: Device not still")
                imageProxy.close()
                return
            }

            // Check if it's time for a full query
            val timeSinceLastFullQuery = if (lastFullQueryTime != null) {
                (currentTime - lastFullQueryTime!!) / 1000.0 // Convert to seconds
            } else {
                Double.POSITIVE_INFINITY
            }

            if (timeSinceLastFullQuery >= FULL_QUERY_INTERVAL) {
                Log.d(TAG, "Processing full query (${timeSinceLastFullQuery}s since last)")
                lastFullQueryTime = currentTime
                makeFullImageQuery(imageProxy)
            } else {
                Log.d(TAG, "Skipping full query (${timeSinceLastFullQuery}s < ${FULL_QUERY_INTERVAL}s)")
            }

            lastProcessingTime = currentTime

            // Start lifecycle tracking for live frame
            val lifecycleTrackingId = com.irdb.irkit.utils.ImageLifecycleTracker.startTracking()
            com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                lifecycleTrackingId,
                com.irdb.irkit.utils.ImageLifecycleTracker.Stage.CAPTURE_COMPLETE
            )

            com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                lifecycleTrackingId,
                com.irdb.irkit.utils.ImageLifecycleTracker.Stage.COMPRESSION_START
            )

            // Convert ImageProxy to Bitmap
            val bitmap = imageProxy.toBitmap()

            // Fix orientation using the actual device-reported rotation
            val rotationDegrees = imageProxy.imageInfo.rotationDegrees.toFloat()
            val matrix = Matrix().apply {
                postRotate(rotationDegrees)
            }

            // Create rotated bitmap
            val rotatedBitmap = Bitmap.createBitmap(
                bitmap,
                0,
                0,
                bitmap.width,
                bitmap.height,
                matrix,
                true
            )

            // ── Crop strategy: segmentation bbox or center crop fallback ──
            val croppedBitmap: Bitmap
            val cropRect: Rect
            var segBbox: android.graphics.RectF? = null

            val segManager = segmentationManager
            if (com.irdb.irkit.segmentation.SegmentationConfig.segmentationEnabled && segManager != null) {
                segBbox = segManager.getSegmentationBbox(rotatedBitmap)
            }

            if (segBbox != null) {
                // Crop to AI-detected bounding box
                val bboxLeft = (segBbox.left * rotatedBitmap.width).toInt().coerceIn(0, rotatedBitmap.width - 1)
                val bboxTop = (segBbox.top * rotatedBitmap.height).toInt().coerceIn(0, rotatedBitmap.height - 1)
                val bboxRight = (segBbox.right * rotatedBitmap.width).toInt().coerceIn(1, rotatedBitmap.width)
                val bboxBottom = (segBbox.bottom * rotatedBitmap.height).toInt().coerceIn(1, rotatedBitmap.height)
                val bboxWidth = max(1, bboxRight - bboxLeft)
                val bboxHeight = max(1, bboxBottom - bboxTop)

                cropRect = Rect(bboxLeft, bboxTop, bboxRight, bboxBottom)
                croppedBitmap = Bitmap.createBitmap(rotatedBitmap, bboxLeft, bboxTop, bboxWidth, bboxHeight)

                if (BuildConfig.DEBUG) {
                    Log.d(TAG, "Segmentation crop: ${bboxWidth}x${bboxHeight} at ($bboxLeft,$bboxTop)")
                }
            } else {
                // Fallback: center crop at 60% width (existing behavior)
                val minCropDimension = DeviceCapabilityDetector.ResolutionConfig.MIN_LIVE_CROP_SIZE
                val cropWidth = max((rotatedBitmap.width * 0.6f).toInt(), minCropDimension)
                val cropHeight = cropWidth

                val finalCropWidth = min(cropWidth, rotatedBitmap.width)
                val finalCropHeight = min(cropHeight, rotatedBitmap.height)

                val originX = (rotatedBitmap.width - finalCropWidth) / 2
                val originY = (rotatedBitmap.height - finalCropHeight) / 2

                cropRect = Rect(originX, originY, originX + finalCropWidth, originY + finalCropHeight)
                croppedBitmap = Bitmap.createBitmap(rotatedBitmap, originX, originY, finalCropWidth, finalCropHeight)

                if (BuildConfig.DEBUG) {
                    Log.d(TAG, "Center crop fallback: ${finalCropWidth}x${finalCropHeight}")
                }
            }

            // Notify segmentation bbox overlay — pass frame size so the overlay can
            // correctly account for the PreviewView FILL_CENTER coordinate transform.
            onSegmentationBboxUpdate?.invoke(
                segBbox,
                android.util.Size(rotatedBitmap.width, rotatedBitmap.height)
            )

            // Notify mask overlay for debug visualization
            onSegmentationMaskUpdate?.invoke(segmentationManager?.getDebugMaskBitmap())

            // Scale to target size (upscale if needed, downscale only if much larger)
            val targetDimension = DeviceCapabilityDetector.ResolutionConfig.TARGET_LIVE_CROP_SIZE.toFloat()
            val scaledBitmap = if (croppedBitmap.width > targetDimension * 1.5f || croppedBitmap.height > targetDimension * 1.5f) {
                val scale = targetDimension / max(croppedBitmap.width, croppedBitmap.height)
                val nw = max(1, (croppedBitmap.width * scale).toInt())
                val nh = max(1, (croppedBitmap.height * scale).toInt())
                Bitmap.createScaledBitmap(croppedBitmap, nw, nh, true)
            } else {
                croppedBitmap
            }

            // Calculate 12% inset region for the upload (matches iOS segmentationRegionInsetPercent)
            val finalImageWidth = scaledBitmap.width
            val finalImageHeight = scaledBitmap.height
            val insetX = floor(finalImageWidth * SEGMENTATION_REGION_INSET_PERCENT).toInt()
            val insetY = floor(finalImageHeight * SEGMENTATION_REGION_INSET_PERCENT).toInt()
            val insetRegion = Region(
                x = insetX,
                y = insetY,
                width = maxOf(1, finalImageWidth - 2 * insetX),
                height = maxOf(1, finalImageHeight - 2 * insetY)
            )

            val outputStream = ByteArrayOutputStream()
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 65, outputStream)
            val imageData = outputStream.toByteArray()

            com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                lifecycleTrackingId,
                com.irdb.irkit.utils.ImageLifecycleTracker.Stage.COMPRESSION_COMPLETE
            )

            // Save to Photos (when save toggle is enabled)
            if (isSaveToGalleryEnabled) {
                saveImageToGalleryFromBytes(imageData)
                Log.d(TAG, "Image saved to gallery (save mode enabled)")
            }

            // Save debug frame for segmentation evaluation (debug builds only)
            if (BuildConfig.DEBUG && com.irdb.irkit.segmentation.SegmentationConfig.saveDebugFrames) {
                com.irdb.irkit.segmentation.SegmentationDebugSaver.saveFrame(imageData)
            }

            // Log dimensions and file size for debugging
            if (BuildConfig.DEBUG) {
                Log.d(CAMERA_SPEC_TAG, "ImageProxy received: ${imageProxy.width}x${imageProxy.height}")
                Log.d(CAMERA_SPEC_TAG, "Rotated bitmap: ${rotatedBitmap.width}x${rotatedBitmap.height}")
                Log.d(CAMERA_SPEC_TAG, "Live crop final: ${scaledBitmap.width}x${scaledBitmap.height}")
                Log.d(TAG, "Crop type: ${if (segBbox != null) "segmentation" else "center"}, File size: ${imageData.size / 1024}KB")
            }

            // Debug overlay callback — pass the rotated frame size (not the raw sensor
            // size) so any consumer can correctly normalize cropRect coordinates.
            onDebugOverlayUpdate?.invoke(
                cropRect,
                null,
                Size(rotatedBitmap.width, rotatedBitmap.height)
            )

            // Upload image with regions
            uploadLiveImage(
                imageData,
                listOf(insetRegion),
                lifecycleTrackingId = lifecycleTrackingId
            )

            // Clean up bitmaps
            bitmap.recycle()
            rotatedBitmap.recycle()
            croppedBitmap.recycle()
            if (scaledBitmap != croppedBitmap) {
                scaledBitmap.recycle()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error processing frame: ${e.message}", e)
        } finally {
            imageProxy.close()
        }
    }

    private fun makeFullImageQuery(imageProxy: ImageProxy) {
        try {
            // Start lifecycle tracking for live capture
            val lifecycleTrackingId = com.irdb.irkit.utils.ImageLifecycleTracker.startTracking()
            com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                lifecycleTrackingId,
                com.irdb.irkit.utils.ImageLifecycleTracker.Stage.CAPTURE_COMPLETE
            )

            com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                lifecycleTrackingId,
                com.irdb.irkit.utils.ImageLifecycleTracker.Stage.COMPRESSION_START
            )
            val imageData = createTripleFoveatedQueryImage(
                imageProxy.toBitmap(),
                isNewlyCaptured = true,
                isFromLiveCapture = true,
                rotationDegrees = imageProxy.imageInfo.rotationDegrees.toFloat()
            )
            com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                lifecycleTrackingId,
                com.irdb.irkit.utils.ImageLifecycleTracker.Stage.COMPRESSION_COMPLETE
            )

            uploadLiveImage(imageData, lifecycleTrackingId = lifecycleTrackingId)
        } catch (e: Exception) {
            Log.e(TAG, "Error making full image query: ${e.message}", e)
        }
    }

    private fun ImageProxy.toBitmap(): Bitmap {
        val buffer = planes[0].buffer
        val bytes = ByteArray(buffer.remaining())
        buffer.get(bytes)
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
    }

    private data class Region(
        val x: Int,
        val y: Int,
        val width: Int,
        val height: Int
    )

    /**
     * this code uploads live images to the IREngine directly
     * Live image is defined as a picture taken with out the user clicking the button
     * normally at a rate of ~3/second
     *
     */

    private fun uploadLiveImage(
        imageData: ByteArray,
        regions: List<Region> = emptyList(),
        lifecycleTrackingId: String? = null
    ) {

        val job = CoroutineScope(Dispatchers.IO).launch {
            // Use lifecycleTrackingId when available to align analytics + lifecycle timing
            val uploadTrackingId = lifecycleTrackingId ?: generateTrackingId()

            // Assign frame number for this upload
            val currentFrameNumber = frameSequenceCounter.incrementAndGet()

            try {
                // Record recognition and upload start
                lifecycleTrackingId?.let {
                    com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                        it,
                        com.irdb.irkit.utils.ImageLifecycleTracker.Stage.RECOGNITION_START
                    )
                    com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                        it,
                        com.irdb.irkit.utils.ImageLifecycleTracker.Stage.UPLOAD_START
                    )
                }

                // Build URL with region parameters
                // get the base URL from the prefs Environment
                        val config = IRKitConfigManager.getConfiguration()
        val prefsUrlToIREngine = config.getUrlToIREngine().ifBlank { IRKit.getInstance().getConfiguration().getIREngineUrl() }
        val prefsAPIKeyForIREngine = config.getAPIKeyForIREngine().ifBlank { IRKit.getInstance().getConfiguration().getAPIKey() }

                val base = if (prefsUrlToIREngine.endsWith("/")) prefsUrlToIREngine else "$prefsUrlToIREngine/"
                val lensSearchString = config.getLensSearchString()
                    ?.trim()
                    ?.takeIf { it.isNotEmpty() }
                val uploadPath = lensSearchString ?: tenantBucketName
                val urlBuilder = StringBuilder("${base}$uploadPath?content=false&live=true")

                // Add region parameters
                regions.forEach { region ->
                    urlBuilder.append("&region=${region.x},${region.y},${region.width},${region.height}")
                }

                val url = URL(urlBuilder.toString())

                // Log endpoint for development debugging only
                if (BackendService.isDebugMode()) {
                    Log.d("EndPoint", "uploadLive url: $url")
                    Log.d("EndPoint", "uploadLive apikey: $prefsAPIKeyForIREngine")
                }

                val connection = if (ENABLE_CHARLES_PROXY) {
                    val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress("192.168.50.188", 8888))
                    (url.openConnection(proxy) as HttpURLConnection).apply {
                        // Trust Charles Proxy's self-signed certificate (DEBUG ONLY)
                        if (this is HttpsURLConnection) {
                            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                                override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                                override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
                            })
                            val sslContext = SSLContext.getInstance("SSL")
                            sslContext.init(null, trustAllCerts, SecureRandom())
                            sslSocketFactory = sslContext.socketFactory
                            hostnameVerifier = HostnameVerifier { _, _ -> true }
                        }
                    }
                } else {
                    url.openConnection() as HttpURLConnection
                }.apply {
                    requestMethod = "POST"
                    doOutput = true

                    setRequestProperty("Content-Type", "image/jpeg")
                    setRequestProperty("Connection", "keep-alive")
                    setRequestProperty("Tracking-Id", uploadTrackingId)
                    setRequestProperty("apikey", prefsAPIKeyForIREngine)
                    setRequestProperty("sequence-id", sessionId)

                    // Reduced timeouts to match iOS (5 seconds) - much more responsive!
                    // Charles Proxy gets longer timeout for debugging
                    connectTimeout = if (ENABLE_CHARLES_PROXY) 60000 else 5000 // 60s for proxy, 5s normal (was 30s)
                    readTimeout = if (ENABLE_CHARLES_PROXY) 60000 else 5000 // 60s for proxy, 5s normal (was 30s)
                }

                // Store connection and frame number for potential cancellation
                activeUploads[uploadTrackingId] = Pair(connection, currentFrameNumber)

                // Register with request queue for concurrent tracking and stale cancellation
                requestQueue.registerRequest(uploadTrackingId, connection, coroutineContext[kotlinx.coroutines.Job]!!)

                if (debugging) {
                    // Log URL
                    Log.d(TAG + "1", "========")
                    Log.d(TAG + "1", "Request URL: $urlBuilder")

                    // Log all request headers
                    connection.requestProperties.forEach { (key, value) ->
                        Log.d(TAG + "1", "Header - $key: $value")
                    }
                    Log.d(TAG + "1", "TrackingId: $uploadTrackingId")
                    Log.d(TAG + "1", "Charles Proxy enabled: $ENABLE_CHARLES_PROXY")
                }

                try {
                    // Save to gallery if flag is enabled
                    if (isSaveToGalleryEnabled) {
                        saveImageToGalleryFromBytes(imageData)
                        Log.d(TAG, "Live image saved to gallery (save mode enabled)")
                    }

                    // Write image data
                    connection.outputStream.use { it.write(imageData) }

                    // Record upload complete
                    lifecycleTrackingId?.let {
                        com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                            it,
                            com.irdb.irkit.utils.ImageLifecycleTracker.Stage.UPLOAD_COMPLETE
                        )
                    }

                    // This happens when the APIKey has expired and need to be renewed.
                    val responseCode = try {
                        connection.responseCode
                    } catch (e: Exception) {
                        Log.w(TAG, "Failed to get response code (Charles Proxy issue?): ${e.message}")
                        // If we can't get response code, assume it was successful for debugging
                        HttpURLConnection.HTTP_OK
                    }

                    if (responseCode == HttpURLConnection.HTTP_UNAUTHORIZED) {
                        Log.e(TAG, "HttpURLConnection.HTTP_UNAUTHORIZED")
                        // Get new environment info and API key
                        // Note: Removed semaphore pause - with 10 concurrent requests, we don't need to block all
                        BackendService.getEnvironmentInformationAndStoreInPrefs()
                    } else {
                        when (responseCode) {
                            HttpURLConnection.HTTP_OK -> {
                                // Check if this frame is outdated (newer frame already completed)
                                val lastCompleted = lastCompletedFrameNumber.get()
                                if (currentFrameNumber < lastCompleted) {
                                    // This frame is older than the last completed frame, drop it
                                    if (BuildConfig.DEBUG) {
                                        Log.d(TAG, "Dropping frame $currentFrameNumber (last completed: $lastCompleted)")
                                    }
                                    activeUploads.remove(uploadTrackingId)
                                    com.irdb.irkit.utils.ImageLifecycleTracker.recordFrameDropped()
                                    lifecycleTrackingId?.let {
                                        com.irdb.irkit.utils.ImageLifecycleTracker.completeTracking(
                                            it,
                                            wasRecognized = false,
                                            wasDropped = true
                                        )
                                    }
                                    return@launch
                                }

                                // This frame is newer, update the last completed frame number
                                lastCompletedFrameNumber.set(currentFrameNumber)

                                // Cancel all older active uploads
                                val iterator = activeUploads.entries.iterator()
                                while (iterator.hasNext()) {
                                    val entry = iterator.next()
                                    val (oldConnection, oldFrameNumber) = entry.value
                                    if (oldFrameNumber < currentFrameNumber && entry.key != uploadTrackingId) {
                                        try {
                                            oldConnection.disconnect()
                                            if (BuildConfig.DEBUG) {
                                                Log.d(TAG, "Cancelled older frame $oldFrameNumber")
                                            }
                                            com.irdb.irkit.utils.ImageLifecycleTracker.recordFrameDropped()
                                        } catch (e: Exception) {
                                            // Ignore errors when disconnecting
                                        }
                                        iterator.remove()
                                    }
                                }

                                // Read response
                                val response =
                                    connection.inputStream.bufferedReader().use { it.readText() }
                                try {
                                    val apiResponse = parseApiResponse(response)
                                    val useLookup = shouldUseLookupForRecognition()

                                    // Record recognition complete
                                    lifecycleTrackingId?.let {
                                        com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                                            it,
                                            com.irdb.irkit.utils.ImageLifecycleTracker.Stage.RECOGNITION_COMPLETE
                                        )
                                    }

                                    val hasRecognition = apiResponse.entry != null || apiResponse.asset != null
                                    Log.d("SCAN_ANALYTICS", "Recognition result: entry=${apiResponse.entry}, asset=${apiResponse.asset != null}, hasRecognition=$hasRecognition, useLookup=${shouldUseLookupForRecognition()}")
                                    var handledByLookup = false

                                    if (useLookup && hasRecognition) {
                                        val lookupImage = fetchImageFromLookup(
                                            rawRecognitionJson = response,
                                            cacheKey = LookupCache.cacheKeyFor(apiResponse.entry, apiResponse.asset),
                                            trackingId = uploadTrackingId,
                                            bucketName = tenantBucketName,
                                            logThisInHistory = apiResponse.asset == null,
                                            isFromManualCapture = false
                                        )
                                        if (lookupImage != null) {
                                            try {
                                                val lookupImageId = lookupImage.imageId
                                                fetchImageAndNotify(
                                                    lookupImageId,
                                                    uploadTrackingId,
                                                    tenantBucketName,
                                                    preFetchedImage = lookupImage
                                                )

                                                // Record frame completed successfully
                                                com.irdb.irkit.utils.ImageLifecycleTracker.recordFrameCompleted()

                                                // Complete lifecycle tracking
                                                lifecycleTrackingId?.let {
                                                    com.irdb.irkit.utils.ImageLifecycleTracker.completeTracking(
                                                        it,
                                                        wasRecognized = true,
                                                        imageId = lookupImageId
                                                    )
                                                }
                                                handledByLookup = true
                                            } catch (e: Exception) {
                                                Log.e(TAG, "Lookup notify failed: ${e.message}", e)
                                            }
                                        }
                                    }

                                    if (handledByLookup) {
                                        return@launch
                                    }

                                    if ( (apiResponse.asset != null) && (apiResponse.entry != null) ){
                                        try {
                                            withContext(Dispatchers.Main) {
                                                apiResponse.clip
                                                if (BuildConfig.DEBUG) {
                                                    Log.d(
                                                        TAG,
                                                        "asset recognized with ID: $apiResponse.asset"
                                                    )
                                                }
                                                notifyAssetRecognized(
                                                    apiResponse.toClipInfoData(),
                                                    apiResponse.entry,
                                                    uploadTrackingId,
                                                    tenantBucketName
                                                )

                                                // Record frame completed successfully
                                                com.irdb.irkit.utils.ImageLifecycleTracker.recordFrameCompleted()

                                                // Complete lifecycle tracking
                                                lifecycleTrackingId?.let {
                                                    com.irdb.irkit.utils.ImageLifecycleTracker.completeTracking(
                                                        it,
                                                        wasRecognized = true,
                                                        imageId = apiResponse.entry
                                                    )
                                                }
                                            }
                                        } catch (e: Exception) {
                                            // If notifying asset fails, still mark as recognized
                                            Log.e(TAG, "Failed to notify asset recognized: ${e.message}", e)
                                            lifecycleTrackingId?.let {
                                                com.irdb.irkit.utils.ImageLifecycleTracker.completeTracking(
                                                    it,
                                                    wasRecognized = true,
                                                    imageId = apiResponse.entry
                                                )
                                            }
                                        }
                                    } else {
                                        if (apiResponse.entry != null) {
                                            val ircode = apiResponse.entry
                                            try {
                                                // Fetch image details first, then notify
                                                fetchImageAndNotify(
                                                    ircode,
                                                    uploadTrackingId,
                                                    tenantBucketName
                                                )

                                                // Record frame completed successfully
                                                com.irdb.irkit.utils.ImageLifecycleTracker.recordFrameCompleted()

                                                // Complete lifecycle tracking
                                                lifecycleTrackingId?.let {
                                                    com.irdb.irkit.utils.ImageLifecycleTracker.completeTracking(
                                                        it,
                                                        wasRecognized = true,
                                                        imageId = ircode
                                                    )
                                                }
                                            } catch (e: Exception) {
                                                // If fetching image details fails, still mark as recognized
                                                // (the server recognized it, we just couldn't load details)
                                                Log.e(TAG, "Failed to fetch/notify recognized image: ${e.message}", e)
                                                lifecycleTrackingId?.let {
                                                    com.irdb.irkit.utils.ImageLifecycleTracker.completeTracking(
                                                        it,
                                                        wasRecognized = true,
                                                        imageId = ircode
                                                    )
                                                }
                                            }
                                        } else {
                                            notifyImageNotRecognized(uploadTrackingId)

                                            // Complete lifecycle tracking for not recognized
                                            lifecycleTrackingId?.let {
                                                com.irdb.irkit.utils.ImageLifecycleTracker.completeTracking(
                                                    it,
                                                    wasRecognized = false,
                                                    imageId = null
                                                )
                                            }
                                        }
                                    }

                                } catch (e: Exception) {
                                    Log.e(TAG, "Error parsing response: ${e.message}")
                                    throw APIError.ParsingError("Failed to parse API response", e)
                                }
                            }

                            in 400..499 -> {
                                val errorResponse =
                                    connection.errorStream?.bufferedReader()?.use { it.readText() }
                                Log.e(TAG, "Client error: $responseCode, Response: $errorResponse")
                                throw APIError.NetworkError(
                                    message = when (responseCode) {
                                        HttpURLConnection.HTTP_BAD_REQUEST -> "Invalid request"
                                        HttpURLConnection.HTTP_UNAUTHORIZED -> "Unauthorized access"
                                        HttpURLConnection.HTTP_FORBIDDEN -> "Access forbidden"
                                        HttpURLConnection.HTTP_NOT_FOUND -> "Resource not found"
                                        else -> "Client error: $responseCode"
                                    },
                                    code = responseCode
                                )
                            }

                            in 500..599 -> {
                                val errorResponse =
                                    connection.errorStream?.bufferedReader()?.use { it.readText() }
                                Log.e(TAG, "Server error: $responseCode, Response: $errorResponse")
                                throw APIError.ServerError(
                                    message = "Server error: $responseCode",
                                    code = responseCode
                                )
                            }

                            else -> {
                                val errorResponse =
                                    connection.errorStream?.bufferedReader()?.use { it.readText() }
                                Log.e(
                                    TAG,
                                    "Unknown response code: $responseCode, Response: $errorResponse"
                                )
                                throw APIError.UnknownError("Unknown response code: $responseCode")
                            }
                        }
                    }
                } finally {
                    connection.disconnect()
                    // Clean up from active uploads tracking
                    activeUploads.remove(uploadTrackingId)
                    // Unregister from request queue
                    requestQueue.unregisterRequest(uploadTrackingId)
                }
            } catch (e: Exception) {
                // Check if this was a cancellation due to stale request cleanup
                if (e is java.net.SocketException && e.message?.contains("Socket closed") == true) {
                    Log.d(TAG, "Request cancelled by stale request cleanup (frame $currentFrameNumber)")
                    // Don't treat this as an error - it's expected behavior
                    return@launch
                }

                val error = when (e) {
                    is APIError -> e
                    is java.net.SocketTimeoutException ->
                        APIError.NetworkError("Request timed out", -1)
                    is java.net.UnknownHostException ->
                        APIError.NetworkError("No internet connection or host not found", -1)
                    is java.util.concurrent.CancellationException -> {
                        // Coroutine was cancelled - this is expected
                        Log.d(TAG, "Request coroutine cancelled (frame $currentFrameNumber)")
                        return@launch
                    }
                    else -> APIError.UnknownError("Unexpected error: ${e.message}", e)
                }

                Log.e(TAG, "Error uploading image: ${error.message}", e)

                // Complete tracking on error
                lifecycleTrackingId?.let {
                    com.irdb.irkit.utils.ImageLifecycleTracker.completeTracking(
                        it,
                        wasRecognized = false,
                        imageId = null
                    )
                }

                withContext(Dispatchers.Main) {
                    when (error) {
                        is APIError.NetworkError -> {
                            if (error.code == HttpURLConnection.HTTP_UNAUTHORIZED ||
                                error.code == HttpURLConnection.HTTP_FORBIDDEN
                            ) {
                                // Handle authentication errors specifically
                                Log.e(TAG, "Authentication error: ${error.message}")
                            }
                        }
                        is APIError.ServerError -> {
                            // Maybe implement retry logic for server errors
                            Log.e(TAG, "Server error: ${error.message}")
                        }
                        else -> {
                            Log.e(TAG, "Other error: ${error.message}")
                        }
                    }

                    notifyImageNotRecognized(uploadTrackingId)
                }
            }
        }
    }

    private fun parseApiResponse(jsonString: String): LiveRecognitionApiResponse {
        return gson.fromJson(jsonString, LiveRecognitionApiResponse::class.java)
    }

    private fun shouldUseLookupForRecognition(): Boolean {
        return USE_LOOKUP_FOR_RECOGNITION
    }

    private suspend fun fetchImageFromLookup(
        rawRecognitionJson: String,
        cacheKey: String?,
        trackingId: String,
        bucketName: String,
        logThisInHistory: Boolean,
        isFromManualCapture: Boolean
    ): ImageModel? = withContext(Dispatchers.IO) {
        // Fast path — cache hit. Lock-free, this is the common case.
        cacheKey?.let { LookupCache.get(it) }?.let { cached ->
            return@withContext ImageModel.fromImageDto(
                cached,
                trackingId = trackingId,
                bucketName = bucketName,
                isFromManualCapture = isFromManualCapture
            )
        }

        // No cacheKey (rare: entry & asset both null) — direct lookup, can't dedup.
        if (cacheKey == null) {
            return@withContext try {
                val imageDto = lookupImage(rawRecognitionJson, logThisInHistory)
                ImageModel.fromImageDto(
                    imageDto,
                    trackingId = trackingId,
                    bucketName = bucketName,
                    isFromManualCapture = isFromManualCapture
                )
            } catch (e: Exception) {
                Log.e(TAG, "Lookup image resolution failed (no cacheKey): ${e.message}", e)
                null
            }
        }

        // Serial dispatch. Only one /lookup runs at a time across this IREngine.
        // Mutex queues waiters in FIFO order, so call ordering is preserved
        // (R1 always resolves before R2 if R1 acquired the lock first).
        lookupMutex.withLock {
            // Inside the lock: the previous holder may have just populated the
            // cache for this same key. Re-check before firing the network call.
            LookupCache.get(cacheKey)?.let { cached ->
                return@withLock ImageModel.fromImageDto(
                    cached,
                    trackingId = trackingId,
                    bucketName = bucketName,
                    isFromManualCapture = isFromManualCapture
                )
            }
            try {
                val imageDto = lookupImage(rawRecognitionJson, logThisInHistory)
                LookupCache.put(cacheKey, imageDto)
                ImageModel.fromImageDto(
                    imageDto,
                    trackingId = trackingId,
                    bucketName = bucketName,
                    isFromManualCapture = isFromManualCapture
                )
            } catch (e: Exception) {
                Log.e(TAG, "Lookup image resolution failed: ${e.message}", e)
                null
            }
        }
    }

    private fun notifyImageRecognized(imageId: String, trackingId: String, bucketName: String) {
        if (BuildConfig.DEBUG) {
            Log.d(Timing_Tag, "Image recognized: TrackingID: $trackingId")
        }

        // Fetch the image and create a proper ImageSearchResult for handleImageRecognized
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val observer = ImageRecognitionObserver.getInstance()
                val cachedImage = observer.getCachedImage(imageId)
                val fetchedImage = if (cachedImage == null) {
                    android.util.Log.d("ImageResult", "Cache MISS for imageId: $imageId - Loading from REST API (IREngine)")
                    val image = ImageModel.fetchImage(imageId, trackingId, bucketName)
                    // Cache the fetched image
                    image?.let { observer.cacheImage(it, imageId) }
                    image
                } else {
                    android.util.Log.d("ImageResult", "Cache HIT for imageId: $imageId - Using cached data (IREngine)")
                    cachedImage
                }

                if (fetchedImage != null) {
                    val imageSearchResult = ImageSearchResult.createSuccess(
                        image = fetchedImage,
                        trackingId = trackingId,
                        bucketName = bucketName,
                        queryTimeMs = 0.0, // Unknown for fallback case
                        isFromLiveVisualSearch = true // This is from live recognition
                    )
                    observer.handleImageRecognized(imageSearchResult)
                } else {
                    // Fall back to handleImageSeen if fetch fails
                    observer.handleImageSeen(imageId, trackingId, bucketName)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in notifyImageRecognized fallback: ${e.message}")
                // Fall back to handleImageSeen if there's an error
                ImageRecognitionObserver.getInstance().handleImageSeen(imageId, trackingId, bucketName)
            }
        }
    }

    private suspend fun fetchImageAndNotify(
        imageId: String,
        trackingId: String,
        bucketName: String,
        preFetchedImage: ImageModel? = null
    ) {
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "Fetching image details for ID: $imageId")
        }

        // Check if this is the same image as the last seen image - if so, don't show notification again
        val observer = ImageRecognitionObserver.getInstance()
        val currentLastSeenImage = observer._lastSeenImage.value
        Log.d("SCAN_ANALYTICS", "fetchImageAndNotify: imageId=$imageId, lastSeenId=${currentLastSeenImage?.imageId}, isDuplicate=${currentLastSeenImage?.imageId == imageId}")
        if (currentLastSeenImage != null && currentLastSeenImage.imageId == imageId) {
            if (BuildConfig.DEBUG) {
                Log.d(Timing_Tag, "Image recognized: TrackingID: $trackingId (duplicate, skipping notification)")
            }
            // NOTE: Still send scan analytics for every recognition even if UI notification is skipped.
            // To restore "first only" behavior, remove this block.
            Log.d("SCAN_ANALYTICS", "DUPLICATE PATH: sending analytics for imageId=$imageId")
            if (!trackingId.equals("deeplink")) {
                try {
                    val analyticsClient = com.irdb.analytics.AnalyticsClient.getInstance()
                    val imageUrlOfScan = trackingId.takeIf { it.isNotEmpty() }?.let { tid ->
                        val bucket = currentLastSeenImage.bucketName?.ifEmpty { "irdbMain" } ?: "irdbMain"
                        analyticsClient.getQueryImageUrlForTrackingId(tid, bucket)
                    }
                    analyticsClient.trackScanEvent(
                        scanType = com.irdb.analytics.ScanType.LIVE,
                        matched = true,
                        imageId = currentLastSeenImage.imageId,
                        campaignId = currentLastSeenImage.getCampaignIdForAnalytics(),
                        campaignName = currentLastSeenImage.getCampaignNameForAnalytics(),
                        scanTrackingId = trackingId,
                        similarCount = (currentLastSeenImage as? ImageModel.FullImage)?.countSimilar,
                        failed = false,
                        imageUrlOfScan = imageUrlOfScan,
                        viewSource = com.irdb.analytics.ViewSource.LIVE_SCAN,
                        imageTitle = currentLastSeenImage.title,
                        imageUrl = currentLastSeenImage.displayImageUrl,
                        userIDOwner = currentLastSeenImage.imageUser?.userId?.takeIf { it > 0 }?.toString(),
                        usernameOwner = currentLastSeenImage.imageUser?.userName?.takeIf { it.isNotEmpty() }
                    )
                } catch (_: IllegalStateException) {
                    // AnalyticsClient not initialized
                } catch (e: Exception) {
                    Log.e(TAG, "Error tracking duplicate scan analytics", e)
                }
            }
            return
        }

        try {
            // Check cache first before making REST API call (unless we already have an image)
            val observer = ImageRecognitionObserver.getInstance()
            val cachedImage = observer.getCachedImage(imageId)
            val fetchedImage = preFetchedImage ?: if (cachedImage == null) {
                android.util.Log.d("ImageResult", "Cache MISS for imageId: $imageId - Loading from REST API (fetchImageAndNotify)")
                val image = ImageModel.fetchImage(imageId, trackingId, bucketName)
                // Cache the fetched image
                image?.let { observer.cacheImage(it, imageId) }
                image
            } else {
                android.util.Log.d("ImageResult", "Cache HIT for imageId: $imageId - Using cached data (fetchImageAndNotify)")
                cachedImage
            }

            // Only notify after image details are fetched
            if (fetchedImage != null) {
                Log.d("IRCODE_FIELDS", "===== RESOLVED ImageModel =====")
                Log.d("IRCODE_FIELDS", fetchedImage.toString())
                Log.d("IRCODE_FIELDS", "===== END RESOLVED ImageModel =====")

                if (preFetchedImage != null && cachedImage == null) {
                    observer.cacheImage(fetchedImage, imageId)
                }
                    if (BuildConfig.DEBUG) {
                        Log.d(Timing_Tag, "Image recognized: TrackingID: $trackingId")
                    }

                    // Pre-load expanded card data in parallel
                    val preloadJob = ImageRecognitionObserver.getInstance().scope.launch {
                        try {
                            // Pre-load products if it's a product card
                            if (fetchedImage.getCardTypeEmum() == CardTypes.ProductCard && fetchedImage.campaignId > 0) {
                                if (BuildConfig.DEBUG) {
                                    Log.d(TAG, "Pre-loading products for campaign ID: ${fetchedImage.campaignId}")
                                }
                                val products = IRKit.getInstance().getProducts(fetchedImage.campaignId)
                            }

                            if (BuildConfig.DEBUG) {
                                Log.d(TAG, "All expanded card data pre-loaded for ID: $imageId")
                            }
                        } catch (e: Exception) {
                            // Log but don't fail the main flow
                            Log.w(TAG, "Failed to pre-load expanded card data for ID: $imageId", e)
                        }
                    }

                    // Use the observer's scope to handle the UI updates
                    ImageRecognitionObserver.getInstance().scope.launch {
                        withContext(Dispatchers.Main) {
                            val observer = ImageRecognitionObserver.getInstance()
                            observer.seenImages[imageId] = Date() to fetchedImage
                            observer._lastSeenImage.value = fetchedImage
                            observer._isLoadingDetails.value = false
                            observer._isRecognizingAny.value = true

                            // Track analytics if not a deeplink
                            if (!trackingId.equals("deeplink")) {
                                Log.d("SCAN_ANALYTICS", "FULL PATH: sending analytics for imageId=${fetchedImage?.imageId}")
                                // Track via ImageRecognitionObserver's internal tracking method
                                // This uses AnalyticsClient directly if initialized
                                try {
                                    val analyticsClient = com.irdb.analytics.AnalyticsClient.getInstance()
                                    val scanTypeEnum = com.irdb.analytics.ScanType.LIVE

                                    // Construct imageUrlOfScan from trackingId and bucketName (required after match per analytics spec)
                                    val imageUrlOfScan = trackingId.takeIf { it.isNotEmpty() }?.let { tid ->
                                        val bucket = fetchedImage?.bucketName?.ifEmpty { "irdbMain" } ?: "irdbMain"
                                        analyticsClient.getQueryImageUrlForTrackingId(tid, bucket)
                                    }

                                    analyticsClient.trackScanEvent(
                                        scanType = scanTypeEnum,
                                        matched = true,
                                        imageId = fetchedImage?.imageId,
                                        campaignId = fetchedImage.getCampaignIdForAnalytics(),
                                        campaignName = fetchedImage.getCampaignNameForAnalytics(),
                                        scanTrackingId = trackingId,
                                        similarCount = (fetchedImage as? ImageModel.FullImage)?.countSimilar,
                                        failed = false,
                                        imageUrlOfScan = imageUrlOfScan,
                                        viewSource = com.irdb.analytics.ViewSource.LIVE_SCAN,
                                        imageTitle = fetchedImage?.title,
                                        imageUrl = fetchedImage?.displayImageUrl,
                                        userIDOwner = fetchedImage?.imageUser?.userId?.takeIf { it > 0 }?.toString(),
                                        usernameOwner = fetchedImage?.imageUser?.userName?.takeIf { it.isNotEmpty() }
                                        // bucketName comes from AnalyticsConfig, not from image data
                                    )
                                } catch (e: IllegalStateException) {
                                    // AnalyticsClient not initialized - gracefully skip tracking
                                } catch (e: Exception) {
                                    Log.e(TAG, "Error tracking analytics event", e)
                                }
                            } else {
                                fetchedImage.fromDeepLink = true
                            }
                        }
                    }
            } else {
                if (BuildConfig.DEBUG) {
                    Log.d(TAG, "Failed to fetch image details for ID: $imageId")
                }
                // Fall back to the original method if fetch fails
                notifyImageRecognized(imageId, trackingId, bucketName)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching image details for ID: $imageId", e)
            // Fall back to the original method if fetch fails
            notifyImageRecognized(imageId, trackingId, bucketName)
        }
    }

    private fun notifyAssetRecognized(clipInfoData: ClipInfoData, imageId: String,  trackingId: String, bucketName: String) {
        if (BuildConfig.DEBUG) {
            Log.d(TAG, "Asset recognized with ID: ${clipInfoData.assetId}")
        }
        ImageRecognitionObserver.getInstance().handleAssetSeen(imageId, trackingId, bucketName, clipInfoData)
    }

    private fun notifyImageNotRecognized(trackingId: String) {
        if (BuildConfig.DEBUG) {
            Log.d(Timing_Tag, "Image NOT recognized: TrackingID: $trackingId")
        }
        ImageRecognitionObserver.getInstance().handleImageNotSeen()
    }

    private fun generateTrackingId(): String {
        // Get current time in milliseconds and convert to hex, padded to 12 chars
        val timeInMilliseconds = System.currentTimeMillis()
        val timeHex = timeInMilliseconds.toString(16).padStart(12, '0')

        // Invert each hex character
        val invertedTimeHex = timeHex.map { char ->
            if (char == '-') {
                char
            } else {
                (15 - char.toString().toInt(16)).toString(16)
            }
        }.joinToString("")

        // Generate 10 random bytes
        val randomBytes = ByteArray(10).apply {
            SecureRandom().nextBytes(this)
        }
        val randHex = randomBytes.joinToString("") {
            "%02x".format(it)
        }

        // Format the UUID v7-like string with specific parts
        val timePart1 = invertedTimeHex.substring(0, 8)
        val timePart2 = invertedTimeHex.substring(8, 12)
        val randPart1 = randHex.substring(0, 3)
        val randPart2 = randHex.substring(3, 6)
        val randPart3 = randHex.substring(6, 18)

        return "$timePart1$timePart2${"7"}$randPart1${"8"}$randPart2$randPart3".uppercase()
    }

    suspend fun processImageData(
        imageData: ByteArray,
        lifecycleTrackingId: String? = null
    ): ImageSearchResult = withContext(Dispatchers.IO) {
        val startTime = System.nanoTime()

        lifecycleTrackingId?.let {
            com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                it,
                com.irdb.irkit.utils.ImageLifecycleTracker.Stage.RECOGNITION_START
            )
        }

        val result = processSnapShotImage(imageData, isNewlyCaptured = true, lifecycleTrackingId)
        val queryTimeMs = (System.nanoTime() - startTime) / 1_000_000_000.0

        lifecycleTrackingId?.let {
            com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                it,
                com.irdb.irkit.utils.ImageLifecycleTracker.Stage.RECOGNITION_COMPLETE
            )
        }

        return@withContext if (result != null) {
            ImageSearchResult.createSuccess(
                image = result,
                trackingId = trackingId,
                bucketName = tenantBucketName,
                queryTimeMs = queryTimeMs,
                isFromLiveVisualSearch = false
            )
        } else {
            ImageSearchResult.createFailure(
                trackingId = trackingId,
                bucketName = tenantBucketName,
                queryTimeMs = queryTimeMs,
                isFromLiveVisualSearch = false
            )
        }
    }

    suspend fun processSelectedImage(uri: Uri): ImageSearchResult = withContext(Dispatchers.IO) {
        try {
            val startTime = System.nanoTime()
            val imageBytes = readImageBytes(uri) ?: return@withContext ImageSearchResult.createFailure(
                trackingId = trackingId,
                bucketName = tenantBucketName,
                queryTimeMs = 0.0,
                isFromLiveVisualSearch = false
            )

            val result = processSnapShotImage(imageBytes, isNewlyCaptured = false)
            val queryTimeMs = (System.nanoTime() - startTime) / 1_000_000_000.0

            return@withContext if (result != null) {
                ImageSearchResult.createSuccess(
                    image = result,
                    trackingId = trackingId,
                    bucketName = tenantBucketName,
                    queryTimeMs = queryTimeMs,
                    isFromLiveVisualSearch = false
                )
            } else {
                ImageSearchResult.createFailure(
                    trackingId = trackingId,
                    bucketName = tenantBucketName,
                    queryTimeMs = queryTimeMs,
                    isFromLiveVisualSearch = false
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in processSelectedImage: ${e.message}")
            return@withContext ImageSearchResult.createFailure(
                trackingId = trackingId,
                bucketName = tenantBucketName,
                queryTimeMs = 0.0,
                isFromLiveVisualSearch = false
            )
        }
    }

    /*
        This function processes captured image NOT live images
     **/
    private suspend fun processSnapShotImage(
        imageData: ByteArray,
        isNewlyCaptured: Boolean,
        lifecycleTrackingId: String? = null
    ): ImageModel? {
                    val config = IRKitConfigManager.getConfiguration()
            val prefsAPIKeyForIREngine = config.getAPIKeyForIREngine()

        try {
            val foveatedImageData = createTripleFoveatedQueryImage(
                imageData,
                isNewlyCaptured,
                isFromLiveCapture = false
            )

            // Save to Photos
            // saveImageToGalleryFromBytes(foveatedImageData)

            // Create URL and connection using environment-managed prefs (align with live uploads)
            val prefsUrlToIREngine = config.getUrlToIREngine()
            val lensSearchString = config.getLensSearchString()
                ?.trim()
                ?.takeIf { it.isNotEmpty() }
            val url = if (lensSearchString != null) {
                val base = if (prefsUrlToIREngine.endsWith("/")) {
                    prefsUrlToIREngine
                } else {
                    "$prefsUrlToIREngine/"
                }
                URL("${base}$lensSearchString?content=false&live=false")
            } else {
                URL("$prefsUrlToIREngine$tenantBucketName?content=false&live=false")
            }

            // Log endpoint for development debugging only
            if (BackendService.isDebugMode()) {
                Log.d("EndPoint", "uploadSnapshot url: $url")
            }

            val snapshotTrackingId = generateTrackingId()
            val connection = if (ENABLE_CHARLES_PROXY) {
                val proxy = Proxy(Proxy.Type.HTTP, InetSocketAddress("192.168.50.188", 8888))
                (url.openConnection(proxy) as HttpURLConnection).apply {
                    // Trust Charles Proxy's self-signed certificate (DEBUG ONLY)
                    if (this is HttpsURLConnection) {
                        val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {}
                            override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
                        })
                        val sslContext = SSLContext.getInstance("SSL")
                        sslContext.init(null, trustAllCerts, SecureRandom())
                        sslSocketFactory = sslContext.socketFactory
                        hostnameVerifier = HostnameVerifier { _, _ -> true }
                    }
                }
            } else {
                url.openConnection() as HttpURLConnection
            }.apply {
                requestMethod = "POST"
                doOutput = true
                setRequestProperty("Content-Type", "image/jpeg")
                setRequestProperty("Tracking-Id", snapshotTrackingId)
                setRequestProperty("apikey", prefsAPIKeyForIREngine)
                // Longer timeouts for Charles Proxy debugging
                connectTimeout = if (ENABLE_CHARLES_PROXY) 60000 else 30000 // 60s for proxy, 30s normal
                readTimeout = if (ENABLE_CHARLES_PROXY) 60000 else 30000 // 60s for proxy, 30s normal
            }

            try {
                // Record upload start
                lifecycleTrackingId?.let {
                    com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                        it,
                        com.irdb.irkit.utils.ImageLifecycleTracker.Stage.UPLOAD_START
                    )
                }

                // Write image data
                connection.outputStream.use { it.write(foveatedImageData) }

                // Record upload complete
                lifecycleTrackingId?.let {
                    com.irdb.irkit.utils.ImageLifecycleTracker.recordStage(
                        it,
                        com.irdb.irkit.utils.ImageLifecycleTracker.Stage.UPLOAD_COMPLETE
                    )
                }
                when (val responseCode = connection.responseCode) {
                    HttpURLConnection.HTTP_OK -> {
                        val response =
                            connection.inputStream.bufferedReader().use { it.readText() }
                        val apiResponse = parseApiResponse(response)
                        val useLookup = shouldUseLookupForRecognition()
                        val hasRecognition = apiResponse.entry != null || apiResponse.asset != null

                        if (useLookup && hasRecognition) {
                            val lookupImage = fetchImageFromLookup(
                                rawRecognitionJson = response,
                                cacheKey = LookupCache.cacheKeyFor(apiResponse.entry, apiResponse.asset),
                                trackingId = trackingId,
                                bucketName = tenantBucketName,
                                logThisInHistory = apiResponse.asset == null,
                                isFromManualCapture = true
                            )
                            if (lookupImage != null) {
                                return lookupImage
                            }
                        }

                        if ( (apiResponse.asset != null) && (apiResponse.entry != null) ){
                            withContext(Dispatchers.Main) {
                                apiResponse.clip
                                if (BuildConfig.DEBUG) {
                                    Log.d(
                                        TAG,
                                        "asset recognized with ID: $apiResponse.asset"
                                    )
                                }
                            }

                            val clipData = apiResponse.toClipInfoData()
                            try {
                                val ircode = BackendService.getImageFromAsset(clipData)
                                // Convert to ImageModel
                                return ImageModel.fromImageDto(
                                    ircode,
                                    trackingId,
                                    tenantBucketName,
                                    isFromManualCapture = true
                                )
                            } catch (e: Exception) {
                                Log.e(TAG, "Failed to get image from asset: ${e.message}")
                                return null
                            }
                        } else {
                            // Get the imageId and fetch full image details
                            val imageId = apiResponse.entry ?: return null
                            val ircode = getImage(imageId)

                            // Convert to ImageModel
                            return ImageModel.fromImageDto(
                                ircode,
                                trackingId,
                                tenantBucketName,
                                isFromManualCapture = true
                            )
                        }
                    }

                    // This happens when the APIKey has expired and need to be renewed.
                    HttpURLConnection.HTTP_UNAUTHORIZED -> {
                        // Get new environment info and API key
                        // Note: Removed semaphore pause - with 10 concurrent requests, we don't need to block all
                        BackendService.getEnvironmentInformationAndStoreInPrefs()
                        // going to lose that call
                        return null
                    }

                    else -> {
                        val errorResponse =
                            connection.errorStream?.bufferedReader()?.use { it.readText() }
                        Log.e(
                            TAG,
                            "Error response code: $responseCode, Response: $errorResponse"
                        )
                        return null
                    }
                }
            } finally {
                connection.disconnect()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in processSnapShotImage: ${e.message}")
            return null
        }
    }

    private fun readImageBytes(uri: Uri): ByteArray? {
        return context.contentResolver.openInputStream(uri)?.use { inputStream ->
            inputStream.readBytes()
        }
    }

    private fun createTripleFoveatedQueryImage(
        imageData: ByteArray,
        isNewlyCaptured: Boolean,
        isFromLiveCapture: Boolean = false
    ): ByteArray {
        val sourceBitmap = BitmapFactory.decodeByteArray(imageData, 0, imageData.size)
            ?: throw IllegalArgumentException("Failed to decode image data")

        try {
            return createTripleFoveatedQueryImage(sourceBitmap, isNewlyCaptured, isFromLiveCapture)
        } finally {
            sourceBitmap.recycle()
        }
    }

    private fun createTripleFoveatedQueryImage(
        sourceBitmap: Bitmap,
        isNewlyCaptured: Boolean,
        isFromLiveCapture: Boolean = false,
        rotationDegrees: Float = 90f
    ): ByteArray {
        // List to keep track of all created bitmaps that need recycling
        val bitmapsToRecycle = mutableListOf<Bitmap>()

        try {
            // Only rotate if it's from live capture
            val bitmapToProcess = if (isFromLiveCapture) {
                // Fix orientation using device-reported rotation
                val matrix = Matrix().apply {
                    postRotate(rotationDegrees)
                }

                // Create rotated bitmap
                val rotatedBitmap = Bitmap.createBitmap(
                    sourceBitmap,
                    0,
                    0,
                    sourceBitmap.width,
                    sourceBitmap.height,
                    matrix,
                    true
                )
                bitmapsToRecycle.add(rotatedBitmap)
                rotatedBitmap
            } else {
                sourceBitmap
            }

            // Get original dimensions from the processed bitmap
            val originalWidth = bitmapToProcess.width.toFloat()
            val originalHeight = bitmapToProcess.height.toFloat()
            var originalSquareSize = min(originalWidth, originalHeight)

            if (isNewlyCaptured) {
                originalSquareSize *= QUERY_IMAGE_FOVIATION_ZOOM_FACTOR
            }

            // Target each crop at 1280x1280 minimum
            val targetCropSize = DeviceCapabilityDetector.ResolutionConfig.TARGET_FOVEATED_CROP_SIZE
            val finalImageHeight = targetCropSize * 3 // Three crops stacked vertically

            // Create result bitmap
            val resultBitmap = Bitmap.createBitmap(targetCropSize, finalImageHeight, Bitmap.Config.ARGB_8888)
            bitmapsToRecycle.add(resultBitmap)
            val canvas = Canvas(resultBitmap)

            // Calculate the center square region
            val overlapX = (originalWidth - originalSquareSize) / 2
            val overlapY = (originalHeight - originalSquareSize) / 2

            // Track crop bounds for debug overlay
            val cropBounds = mutableListOf<Rect>()

            // Process each zoom level (in reverse order: 4x, 2x, 1x)
            for (i in 2 downTo 0) {
                // Calculate zoom factor: 1x, 2x, 4x zoom
                val zoomFactor = Math.pow(2.0, i.toDouble()).toFloat()

                // Calculate the size of the region to crop (smaller for higher zoom)
                val cropSize = originalSquareSize / zoomFactor

                // Center the crop region
                val cropX = (overlapX + (originalSquareSize - cropSize) / 2).toInt()
                val cropY = (overlapY + (originalSquareSize - cropSize) / 2).toInt()

                // Ensure we don't exceed bitmap bounds
                val safeWidth = min(cropSize.toInt(), bitmapToProcess.width - cropX)
                val safeHeight = min(cropSize.toInt(), bitmapToProcess.height - cropY)

                // Crop the zoomed region from high-res source
                val zoomedBitmap = Bitmap.createBitmap(
                    bitmapToProcess,
                    cropX.coerceIn(0, bitmapToProcess.width - safeWidth),
                    cropY.coerceIn(0, bitmapToProcess.height - safeHeight),
                    safeWidth,
                    safeHeight
                )
                bitmapsToRecycle.add(zoomedBitmap)

                // Scale to target 1280x1280 (upscale if needed)
                val scaledBitmap = Bitmap.createScaledBitmap(
                    zoomedBitmap,
                    targetCropSize,
                    targetCropSize,
                    true
                )
                bitmapsToRecycle.add(scaledBitmap)

                // Draw at the appropriate vertical position (2->bottom, 1->middle, 0->top)
                canvas.drawBitmap(
                    scaledBitmap,
                    0f,
                    (targetCropSize * (2 - i)).toFloat(),
                    null
                )

                // Track crop bounds for debug overlay
                cropBounds.add(Rect(cropX, cropY, cropX + safeWidth, cropY + safeHeight))
            }

            // Debug overlay callback for foveated crops
            if (BuildConfig.DEBUG) {
                Log.d(CAMERA_SPEC_TAG, "Foveated source: ${bitmapToProcess.width}x${bitmapToProcess.height}")
                Log.d(CAMERA_SPEC_TAG, "Foveated result: ${resultBitmap.width}x${resultBitmap.height}")
                Log.d(CAMERA_SPEC_TAG, "Crop sizes - 1x: ${cropBounds[2].width()}x${cropBounds[2].height()}, 2x: ${cropBounds[1].width()}x${cropBounds[1].height()}, 4x: ${cropBounds[0].width()}x${cropBounds[0].height()}")
            }

            onDebugOverlayUpdate?.invoke(
                null,
                cropBounds,
                Size(bitmapToProcess.width, bitmapToProcess.height)
            )

            // Create output bytes
            val outputStream = ByteArrayOutputStream()
            resultBitmap.compress(Bitmap.CompressFormat.JPEG, 40, outputStream)
            return outputStream.toByteArray()
        } finally {
            // Clean up all bitmaps
            bitmapsToRecycle.forEach { bitmap ->
                if (!bitmap.isRecycled) {
                    bitmap.recycle()
                }
            }
        }
    }

    private fun Float.pow(exponent: Int): Float {
        return Math.pow(this.toDouble(), exponent.toDouble()).toFloat()
    }

    private data class BoundingBox(
        val left: Int,
        val top: Int,
        val right: Int,
        val bottom: Int
    )

    private fun calculateBoundingBox(points: List<Offset>): BoundingBox {
        val minX = points.minOf { it.x }.toInt()
        val minY = points.minOf { it.y }.toInt()
        val maxX = points.maxOf { it.x }.toInt()
        val maxY = points.maxOf { it.y }.toInt()

        // Add padding (10% on each side)
        val width = maxX - minX
        val height = maxY - minY
        val padding = (minOf(width, height) * 0.1f).toInt()

        return BoundingBox(
            left = (minX - padding).coerceAtLeast(0),
            top = (minY - padding).coerceAtLeast(0),
            right = (maxX + padding).coerceAtMost(previewView.width),
            bottom = (maxY + padding).coerceAtMost(previewView.height)
        )
    }

    private fun Bitmap.toByteArray(): ByteArray {
        val outputStream = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.JPEG, 65, outputStream)
        return outputStream.toByteArray()
    }

    private fun saveImageToGallery(bitmap: Bitmap) {
        val filename = "IRKit_${System.currentTimeMillis()}.jpg"
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/IRKit")
        }

        try {
            context.contentResolver.let { resolver ->
                // Insert the image into MediaStore
                val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                imageUri?.let { uri ->
                    resolver.openOutputStream(uri)?.use { outputStream ->
                        // Compress and save the bitmap
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, outputStream)
                    }
                    Log.d(TAG, "Image saved successfully: $filename")
                } ?: Log.e(TAG, "Failed to create new MediaStore record.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error saving image to gallery: ${e.message}")
        }
    }

    fun saveImageToGalleryFromBytes(imageData: ByteArray) {
        val filename = "IRKit_${System.currentTimeMillis()}.jpg"
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/IRKit")
        }

        try {
            context.contentResolver.let { resolver ->
                // Insert the image into MediaStore
                val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                imageUri?.let { uri ->
                    resolver.openOutputStream(uri)?.use { outputStream ->
                        // Write the bytes directly
                        outputStream.write(imageData)
                    }
                    Log.d(TAG, "Image saved successfully: $filename")
                } ?: Log.e(TAG, "Failed to create new MediaStore record.")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error saving image to gallery: ${e.message}")
        }
    }
}
