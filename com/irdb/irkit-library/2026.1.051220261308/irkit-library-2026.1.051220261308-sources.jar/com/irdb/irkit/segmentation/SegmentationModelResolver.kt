package com.irdb.irkit.segmentation

/**
 * Resolves which ONNX segmentation model to use based on lens characteristics
 * returned by the getLens API.
 *
 * Priority:
 * 1. segmentationModel field (explicit override)
 * 2. lensType field (implicit default)
 * 3. Fallback to legacy model
 */
object SegmentationModelResolver {

    // ── ONNX model file constants ────────────────────────────────────────────
    const val MODEL_GAZENET_LEGACY = "segmentation_gazenet_transformer.onnx"
    const val MODEL_GAZENET_TV = "GazeNetTV.onnx"
    const val MODEL_GAZENET_BIG_THINGS = "GazeNetBigThings.onnx"
    const val MODEL_NONE = "none"

    // ── Lookup tables ──────────────────────────────────────────────────────
    // To add a new model: add the ONNX constant above, then add one entry here.

    private val segmentationModelMap = mapOf(
        "GazeNet-1.0"         to MODEL_GAZENET_LEGACY,
        "GazeNetTV-1.0"       to MODEL_GAZENET_TV,
        "GazeNetBigThings-1.0" to MODEL_GAZENET_BIG_THINGS,
        "none"                to MODEL_NONE,
    )

    private val lensTypeMap = mapOf(
        "generic" to MODEL_GAZENET_LEGACY,
        "TV"      to MODEL_GAZENET_TV,
    )

    /**
     * Determine the ONNX model filename from lens characteristics.
     *
     * @param lensType       Value of characteristics.lensType (e.g. "TV", "generic")
     * @param segmentationModel Value of characteristics.segmentationModel
     *                          (e.g. "GazeNetTV-1.0", "none")
     * @return One of the MODEL_* constants. When [MODEL_NONE] is returned the
     *         caller should skip segmentation and fall back to center crop.
     */
    fun resolve(lensType: String?, segmentationModel: String?): String {
        // 1. Explicit segmentationModel override
        if (!segmentationModel.isNullOrBlank()) {
            segmentationModelMap[segmentationModel]?.let { return it }
        }

        // 2. Fall back to lensType
        if (!lensType.isNullOrBlank()) {
            lensTypeMap[lensType]?.let { return it }
        }

        // 3. Default
        return MODEL_GAZENET_LEGACY
    }
}
