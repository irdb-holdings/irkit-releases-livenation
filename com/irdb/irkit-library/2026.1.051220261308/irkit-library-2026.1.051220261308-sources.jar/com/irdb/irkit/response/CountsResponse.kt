package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName

/*
"Counts": {
			"countRead": 0,
			"countUnRead": 0,
			"emailVerified": false,
			"phoneVerified": false,
			"totalArchivedCount": 0,
			"totalHistoryCount": 5,
			"totalImagesCount": 0,
			"totalNotificationsCount": 0,
			"totalSavedCount": 0
		}
 */

data class CountsResponse(
    @SerializedName("Counts")
    val counts: CountsData
)

data class CountsData(

    @SerializedName("countRead")
    val countRead: Int = 0,

    @SerializedName("countUnRead")
    val countUnRead: Int = 0,

    @SerializedName("emailVerified")
    val emailVerified: Boolean,

    @SerializedName("phoneVerified")
    val phoneVerified: Boolean,

    @SerializedName("totalArchivedCount")
    val totalArchivedCount: Int = 0,

    @SerializedName("totalHistoryCount")
    val totalHistoryCount: Int = 0,

    @SerializedName("totalImagesCount")
    val totalImagesCount: Int = 0,

    @SerializedName("totalNotificationsCount")
    val totalNotificationsCount: Int = 0,

    @SerializedName("totalSavedCount")
    val totalSavedCount: Int = 0
)

data class CountsDto(
    val countRead: Int = 0,
    val countUnRead: Int = 0,
    val emailVerified: Boolean,
    val phoneVerified: Boolean,
    val totalArchivedCount: Int = 0,
    val totalHistoryCount: Int = 0,
    val totalImagesCount: Int = 0,
    val totalNotificationsCount: Int = 0,
    val totalSavedCount: Int = 0
) {
    companion object {
        fun fromCountsData(countsData: CountsData): CountsDto {
            return CountsDto(
                countRead = countsData.countRead,
                countUnRead = countsData.countUnRead,
                emailVerified = countsData.emailVerified,
                phoneVerified = countsData.phoneVerified,
                totalArchivedCount = countsData.totalArchivedCount,
                totalHistoryCount = countsData.totalHistoryCount,
                totalImagesCount = countsData.totalImagesCount,
                totalNotificationsCount = countsData.totalNotificationsCount,
                totalSavedCount = countsData.totalSavedCount
            )
        }
    }
}
