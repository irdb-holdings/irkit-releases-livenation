package com.irdb.irkitui.ui.baseComponents

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.vectorResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.irdb.irkitui.theme.IRKitUITheme

@Composable
fun ResultCardCallToActionButtonV2(
    text: String,
    linkIcon: Int? = null,
    iconVector: ImageVector? = null,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    useFixedWidth: Boolean = false,
    showIcon: Boolean = true,
    backgroundColor: Color = Color(0xFF1C1C1E),
    textColor: Color = Color.White,
    borderColor: Color = Color(0xFF3A3A3C)
) {
    val buttonModifier = if (useFixedWidth) {
        modifier.width(170.dp)
    } else {
        modifier.wrapContentWidth()
    }

    Row(
        modifier = buttonModifier
            .shadow(
                elevation = 2.dp,
                shape = RoundedCornerShape(25.dp),
                spotColor = Color.White.copy(alpha = 0.1f)
            )
            .border(
                width = 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(25.dp)
            )
            .background(
                color = backgroundColor,
                shape = RoundedCornerShape(25.dp)
            )
            .clickable(onClick = onClick)
            .padding(start = 4.dp, end = 8.dp, top = 2.dp, bottom = 2.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Show icon from resource ID or ImageVector
        if (showIcon && linkIcon != null && linkIcon != 0) {
            val resVector = ImageVector.vectorResource(linkIcon)
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = resVector,
                    contentDescription = text,
                    tint = Color.Unspecified,
                    modifier = Modifier.size(26.dp)
                )
            }
        } else if (showIcon && iconVector != null) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .background(Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = iconVector,
                    contentDescription = text,
                    tint = Color.Black,
                    modifier = Modifier.size(26.dp)
                )
            }
        }

        Text(
            text = text,
            style = MaterialTheme.typography.bodyMedium,
            color = textColor,
            textAlign = TextAlign.Center,
            modifier = Modifier
                .padding(horizontal = 10.dp, vertical = 6.dp),
            softWrap = true,
            maxLines = Int.MAX_VALUE,
            overflow = TextOverflow.Visible
        )
    }
}

@Preview(showBackground = false)
@Composable
fun ResultCardCallToActionButtonV2Preview() {
    IRKitUITheme {
        androidx.compose.foundation.layout.Column {
            ResultCardCallToActionButtonV2(
                text = "Visit Website",
                onClick = { },
                showIcon = false
            )

            ResultCardCallToActionButtonV2(
                text = "Social Link",
                onClick = { },
                showIcon = false
            )

            ResultCardCallToActionButtonV2(
                text = "Home Page",
                onClick = { },
                showIcon = false
            )

            ResultCardCallToActionButtonV2(
                text = "This is a test of a long text",
                onClick = { },
                showIcon = false
            )
        }
    }
}