package com.irdb.irkitui.configuration

/**
 * Controls where the close button appears on the expanded image detail view.
 * Each client can choose a placement via [ClientConfigBase.expandedCloseButtonPlacement].
 */
enum class ExpandedCloseButtonPlacement {
    topRight,
    bottomCenter
}
