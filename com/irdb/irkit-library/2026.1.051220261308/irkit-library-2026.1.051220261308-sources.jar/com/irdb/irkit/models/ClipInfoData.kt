package com.irdb.irkit.models

/**
 * Data class representing metadata information about a video clip or asset segment.
 *
 * This class holds information about where in a video asset a specific clip begins and ends,
 * along with identifiers for both the asset and any associated image recognition results.
 *
 * @property imageId The unique identifier for the image recognition result, if applicable.
 *                 This may be null if the clip doesn't have an associated recognized image.
 * @property assetId The unique identifier for the video asset or media file containing this clip.
 *                 This identifies the source video where the clip was extracted from.
 * @property timeRangeMin The start time of the clip within the video asset, measured in seconds.
 *                       This represents where the clip begins in the timeline.
 * @property timeRangeMax The end time of the clip within the video asset, measured in seconds.
 *                       This represents where the clip ends in the timeline.
 *
 * @see LiveRecognitionApiResponse.toClipInfoData()
 */
data class ClipInfoData(
    val imageId: String?,
    val assetId: String?,
    val timeRangeMin: Double?,
    val timeRangeMax: Double?
)

/**
 * Extension function to convert a [LiveRecognitionApiResponse] to a [ClipInfoData] object.
 *
 * This function extracts the relevant timing and identification information from the API response
 * to create a structured representation of the video clip metadata.
 *
 * @return [ClipInfoData] containing the extracted clip information
 */
fun LiveRecognitionApiResponse.toClipInfoData(): ClipInfoData =
    ClipInfoData(
        imageId = this.entry,
        assetId = this.asset,
        timeRangeMin = this.clip?.time?.min,
        timeRangeMax = this.clip?.time?.max
    )
