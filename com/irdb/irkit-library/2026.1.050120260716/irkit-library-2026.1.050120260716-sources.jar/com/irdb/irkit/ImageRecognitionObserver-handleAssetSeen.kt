package com.irdb.irkit

import com.irdb.irkit.models.ClipInfoData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Date

private fun ImageModel?.getCampaignIdForAnalytics(): Long? {
    return this?.campaignId?.takeIf { campaignId -> campaignId > 0 }?.toLong()
}

private fun ImageModel?.getCampaignNameForAnalytics(): String? {
    return this?.campaignName?.takeIf { campaignName -> campaignName.isNotEmpty() }
}

/**
 * Handles the recognition of an asset when it is seen by the image recognition system.
 *
 * This function processes assets (which can be images, videos, or other media) that are detected
 * by the recognition observer. It manages the asset loading lifecycle, caching, analytics tracking,
 * and state updates for the recognition system.
 *
 * The function performs the following operations:
 * 1. Checks if the asset is already being processed to avoid duplicate operations
 * 2. Creates a placeholder asset if needed while loading
 * 3. Fetches the full asset data from the backend or retrieves it from cache
 * 4. Tracks one matched-scan analytics event on the FIRST recognition only (excluding deeplinks).
 *    Repeat recognitions of the same image are intentionally NOT tracked here — the
 *    AnalyticsClient dedup gate also blocks them per analytics_doc (3).md §"Scan Result - Match".
 * 5. Updates the observer's state with the recognized asset
 * 6. Manages loading states and timeouts
 *
 * @param imageId The unique identifier for the asset being recognized
 * @param trackingId The tracking identifier for analytics and monitoring purposes.
 *                   Use "deeplink" to indicate the asset was accessed via deeplink
 * @param bucketName The storage bucket name where the asset is located
 * @param clipInfoData Metadata information about the asset clip being processed
 *
 * @see ImageRecognitionObserver
 * @see ClipInfoData
 * @see ImageModel
 */
fun ImageRecognitionObserver.handleAssetSeen(imageId: String, trackingId : String, bucketName: String, clipInfoData: ClipInfoData) {
    scope.launch {
        // If we're already showing this image and it's not a placeholder, just update timestamp.
        // Per analytics_doc (3).md §"Scan Result - Match", repeated recognitions of the same image
        // already shown in the preview popup must NOT emit a new POST. No analytics call here.
        seenImages[imageId]?.let { (_, currentImage) ->
            if (currentImage !is ImageModel.Placeholder) {
                seenImages[imageId] = Date() to currentImage
                return@launch
            }
        }

        // If we're already loading this image, don't start another loading process
        if (currentlyLoadingImageId == imageId) return@launch

        currentlyLoadingImageId = imageId

        // Create timeout coroutine
        val timeoutJob = scope.launch {
            delay(500) // 0.5 seconds timeout
            _isLoadingDetails.value = true
            if (seenImages[imageId] == null) {
                val placeholderImage = ImageModel.Placeholder(imageId)
                seenImages[imageId] = Date() to placeholderImage
                _lastSeenImage.value = placeholderImage
                _isRecognizingAny.value = true
            }
        }

        // Fetch actual data
        try {
            val cachedImage = getCachedImage(imageId)
            val matchedImage = if (cachedImage == null) {
                android.util.Log.d("ImageResult", "Cache MISS for imageId: $imageId - Loading from REST API (Asset)")
                val fetchedImage = ImageModel.fetchImageFromAsset(clipInfoData, trackingId, bucketName)
                // do not track deeplinks
                if (!trackingId.equals("deeplink")) { // Using literal instead of constants reference
                    if (fetchedImage != null) {
                        // Track via internal method using AnalyticsClient
                        // Launch in separate coroutine to avoid blocking live mode processing
                        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                            try {
                                val analyticsClient = com.irdb.analytics.AnalyticsClient.getInstance()

                                // Construct imageUrlOfScan from trackingId and bucketName (required after match per analytics spec)
                                val imageUrlOfScan = trackingId.takeIf { it.isNotEmpty() }?.let { tid ->
                                    val bucket = fetchedImage.bucketName.ifEmpty { "irdbMain" }
                                    analyticsClient.getQueryImageUrlForTrackingId(tid, bucket)
                                }

                                analyticsClient.trackScanEvent(
                                    scanType = com.irdb.analytics.ScanType.LIVE,
                                    matched = true,
                                    imageId = fetchedImage.imageId,
                                    campaignId = fetchedImage.getCampaignIdForAnalytics(),
                                    campaignName = fetchedImage.getCampaignNameForAnalytics(),
                                    scanTrackingId = trackingId,
                                    similarCount = (fetchedImage as? ImageModel.FullImage)?.countSimilar,
                                    failed = false,
                                    imageUrlOfScan = imageUrlOfScan,
                                    viewSource = com.irdb.analytics.ViewSource.LIVE_SCAN,
                                    imageTitle = fetchedImage.title,
                                    imageUrl = fetchedImage.displayImageUrl,
                                    userIDOwner = fetchedImage.imageUser?.userId?.takeIf { it > 0 }?.toString(),
                                    usernameOwner = fetchedImage.imageUser?.userName?.takeIf { it.isNotEmpty() }
                                    // bucketName comes from AnalyticsConfig, not from image data
                                )
                            } catch (e: IllegalStateException) {
                                // AnalyticsClient not initialized - gracefully skip tracking
                            } catch (e: Exception) {
                                android.util.Log.e("ImageRecognitionObserver", "Error tracking analytics event", e)
                            }
                        }
                    }
                } else {
                    // Set tells the rest of the code it was not searched on it was brought into the system
                    // through a deeplink or application link
                    if (fetchedImage != null) {
                        fetchedImage.fromDeepLink = true
                    }
                }
                fetchedImage
            } else {
                android.util.Log.d("ImageResult", "Cache HIT for imageId: $imageId - Using cached data (Asset)")
                // Cache hit means the image was already loaded (and analytics already fired) earlier
                // in the session. Per analytics_doc (3).md §"Scan Result - Match", do not emit another
                // POST for the same imageID until the preview popup is dismissed. The dedup gate in
                // AnalyticsClient.trackScanEvent provides a second line of defence.
                cachedImage
            }

            matchedImage?.let { image ->
                if (getCachedImage(imageId) == null) {
                    cacheImage(image, imageId)
                }
                withContext(Dispatchers.Main) {
                    seenImages[imageId] = Date() to image
                    _lastSeenImage.value = image
                    _isLoadingDetails.value = false
                    _isRecognizingAny.value = true
                }
            }
        } finally {
            timeoutJob.cancel()
            currentlyLoadingImageId = null
            _isLoadingDetails.value = false
        }
    }
}
