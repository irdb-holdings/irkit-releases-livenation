/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.irdb.analytics;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.irdb.analytics";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String ANALYTICS_LIBRARY_VERSION = "2026.1.051220261308";
}
