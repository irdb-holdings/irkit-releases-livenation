package com.irdb.irkit

import com.google.gson.reflect.TypeToken
import com.irdb.irkit.response.SimilarResponse
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

// https://us-central1-ircode-1a662.cloudfunctions.net/development-v1_43/IREngine/similar?imageID=01978E86458E77CAB40EAA1F39070F6A

suspend fun BackendService.similar(imageID: String): SimilarResponse =
    withContext(Dispatchers.IO) {
        val endpoint = "/IREngine/similar?imageID=$imageID"

        val response = request<BaseResponse<SimilarResponse>>(
            endpoint = endpoint,
            method = HttpMethod.GET,
            responseType = object : TypeToken<BaseResponse<SimilarResponse>>() {}.type
//            headerParameters = mapOf("auth" to fbToken),
        )

        if (!response.succeeded || response.payload == null) {
            throw BackendServiceError.ServerError(response.errorMessage)
        }

        val payload = requireNotNull(response.payload) { "Payload should not be null after null check" }
        payload.results
    }
