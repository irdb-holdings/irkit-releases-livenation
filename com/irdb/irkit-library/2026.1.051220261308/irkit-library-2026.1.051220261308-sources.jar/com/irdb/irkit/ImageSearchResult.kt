package com.irdb.irkit

/**
 * A wrapper class that encapsulates both the image search result and its metadata.
 * This is used to return comprehensive information about an image search operation,
 * whether it was successful or not.
 */
data class ImageSearchResult(
    // The matched image model, if any
    val matchedImage: ImageModel?,

    // Search metadata
    val trackingId: String,
    val bucketName: String,
    val queryTimeMs: Double,
    val isFromLiveVisualSearch: Boolean,

    // Search status
    val isSuccess: Boolean = matchedImage != null,

    // Timestamp of the search
    val timestamp: Long = System.currentTimeMillis()
) {
    companion object {
        fun createSuccess(
            image: ImageModel,
            trackingId: String,
            bucketName: String,
            queryTimeMs: Double,
            isFromLiveVisualSearch: Boolean
        ): ImageSearchResult = ImageSearchResult(
            matchedImage = image,
            trackingId = trackingId,
            bucketName = bucketName,
            queryTimeMs = queryTimeMs,
            isFromLiveVisualSearch = isFromLiveVisualSearch
        )

        fun createFailure(
            trackingId: String,
            bucketName: String,
            queryTimeMs: Double,
            isFromLiveVisualSearch: Boolean
        ): ImageSearchResult = ImageSearchResult(
            matchedImage = null,
            trackingId = trackingId,
            bucketName = bucketName,
            queryTimeMs = queryTimeMs,
            isFromLiveVisualSearch = isFromLiveVisualSearch
        )
    }
}