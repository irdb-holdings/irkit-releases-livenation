package com.irdb.irkitui.ui.baseComponents

import android.content.res.Configuration
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.irdb.irkitui.theme.IRKitUITheme
import com.irdb.irkitui.theme.SaveButtonIconColor
import com.irdb.irkitui.theme.SaveButtonTextColor

object SaveButtonDimens {
    val iconPadding = 8.dp
    val textFontSize = 12.sp
    val previewSpacing = 8.dp
    val previewPadding = 8.dp
}

@Composable
fun SaveButton(
    modifier: Modifier = Modifier,
    onSaveButtonClick: () -> Unit,
    added: Boolean = false,
    count: Int = 0,
    // We'll need to provide resource IDs or image vectors externally since this is a library
    addedIcon: ImageVector? = null,
    outlineIcon: ImageVector? = null
) {
    ShadowButton(
        modifier = modifier,
        onClick = onSaveButtonClick
    ) {
        if (addedIcon != null && outlineIcon != null) {
            Icon(
                imageVector = if (added) addedIcon else outlineIcon,
                contentDescription = "Save",
                tint = SaveButtonIconColor,
                modifier = Modifier.padding(SaveButtonDimens.iconPadding)
            )
        }
        ButtonCountText(
            count = count
        )
    }
}

@Preview(showBackground = true)
@Composable
fun SaveButtonPreview() {
    IRKitUITheme {
        Column(
            verticalArrangement = Arrangement.spacedBy(SaveButtonDimens.previewSpacing),
            modifier = Modifier.padding(SaveButtonDimens.previewPadding)
        ) {
            SaveButton(
                onSaveButtonClick = { },
                added = true,
                count = 2,
                addedIcon = null,
                outlineIcon = null
            )

            SaveButton(
                onSaveButtonClick = { },
                added = false,
                addedIcon = null,
                outlineIcon = null
            )
        }
    }
}

@Preview(showBackground = true, uiMode = Configuration.UI_MODE_NIGHT_YES)
@Composable
fun SaveButtonDarkPreview() {
    IRKitUITheme(darkTheme = true) {
        Column(
            verticalArrangement = Arrangement.spacedBy(SaveButtonDimens.previewSpacing),
            modifier = Modifier.padding(SaveButtonDimens.previewPadding)
        ) {
            SaveButton(
                onSaveButtonClick = { },
                added = true,
                count = 2,
                addedIcon = null,
                outlineIcon = null
            )

            SaveButton(
                onSaveButtonClick = { },
                added = false,
                addedIcon = null,
                outlineIcon = null
            )
        }
    }
}
