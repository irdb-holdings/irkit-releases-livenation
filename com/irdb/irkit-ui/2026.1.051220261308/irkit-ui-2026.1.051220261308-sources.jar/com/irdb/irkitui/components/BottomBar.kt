package com.irdb.irkitui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.irdb.irkitui.CameraMode
import com.irdb.irkitui.theme.IRKitUITheme

// Constants for better maintainability
private const val BOTTOM_BAR_BUTTON_HEIGHT = 54
private const val BOTTOM_BAR_ROW_HEIGHT = 500
private const val BOTTOM_BAR_HORIZONTAL_PADDING = 40
private const val BOTTOM_BAR_HEIGHT_RATIO = 0.407f
private const val BOTTOM_BAR_HEIGHT_OFFSET = 10
private const val BOTTOM_BAR_BACKGROUND_ALPHA = 0.3f
private const val BOTTOM_BAR_SPACER_HEIGHT = 5
private const val BOTTOM_BAR_VERTICAL_PADDING = 10
private const val NAVIGATION_BAR_BOTTOM_PADDING = 25

/**
 * Main app's custom BottomBar with branded buttons.
 * This uses custom drawable resources for a polished look.
 */
@Composable
fun BottomBar(
    modifier: Modifier = Modifier,
    onCaptureClick: () -> Unit,
    onSelectImageClick: () -> Unit,
    isExpanded: Boolean,
    onCloseClick: () -> Unit,
    onTorchClick: () -> Unit,
    torchState: Boolean,
    hasVisibleNavigationBar: Boolean,
    cameraMode: CameraMode,
    onAppModeChanged: (CameraMode) -> Unit,
    showGalleryButton: Boolean = true
) {
    val buttonContainerHeight = BOTTOM_BAR_BUTTON_HEIGHT.dp

    Box(
        modifier = Modifier
            .fillMaxSize()
            .then(modifier)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(color = Color.Black.copy(alpha = BOTTOM_BAR_BACKGROUND_ALPHA))
                .height(calculateBottomBarHeight(LocalConfiguration.current.screenWidthDp, LocalDensity.current))
                .align(Alignment.BottomCenter)
                .then(
                    if (!hasVisibleNavigationBar) {
                        Modifier.padding(bottom = NAVIGATION_BAR_BOTTOM_PADDING.dp)
                    } else {
                        Modifier.navigationBarsPadding()
                    }
                )
        ) {
            Spacer(modifier = Modifier.height(BOTTOM_BAR_SPACER_HEIGHT.dp))

            BottomBarButtons(
                isExpanded = isExpanded,
                buttonContainerHeight = buttonContainerHeight,
                onCaptureClick = onCaptureClick,
                onSelectImageClick = onSelectImageClick,
                onCloseClick = onCloseClick,
                onTorchClick = onTorchClick,
                torchState = torchState,
                cameraMode = cameraMode,
                showGalleryButton = showGalleryButton
            )
        }
    }
}

@Composable
private fun BottomBarButtons(
    isExpanded: Boolean,
    buttonContainerHeight: androidx.compose.ui.unit.Dp,
    onCaptureClick: () -> Unit,
    onSelectImageClick: () -> Unit,
    onCloseClick: () -> Unit,
    onTorchClick: () -> Unit,
    torchState: Boolean,
    cameraMode: CameraMode,
    showGalleryButton: Boolean
) {
    Row(
        modifier = Modifier
            .height(BOTTOM_BAR_ROW_HEIGHT.dp)
            .padding(horizontal = BOTTOM_BAR_HORIZONTAL_PADDING.dp)
            .background(Color.Transparent),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (!isExpanded) {
            Box(
                modifier = Modifier
                    .height(buttonContainerHeight)
                    .wrapContentHeight(align = Alignment.CenterVertically)
            ) {
                if (showGalleryButton) {
                    androidx.compose.material3.IconButton(onClick = onSelectImageClick) {
                        androidx.compose.material3.Icon(
                            imageVector = androidx.compose.material.icons.Icons.Default.PhotoLibrary,
                            contentDescription = "Select Image",
                            tint = androidx.compose.ui.graphics.Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(0.5f))

            Box(
                modifier = Modifier
                    .wrapContentHeight(align = Alignment.CenterVertically)
                    .height(buttonContainerHeight + 8.dp)
                    .background(Color.White, CircleShape)
                    .padding(8.dp)
            ) {
                androidx.compose.material3.IconButton(onClick = onCaptureClick) {
                    androidx.compose.material3.Icon(
                        imageVector = androidx.compose.material.icons.Icons.Default.CameraAlt,
                        contentDescription = "Capture",
                        tint = androidx.compose.ui.graphics.Color.Black
                    )
                }
            }

            Spacer(modifier = Modifier.weight(0.5f))

            Box(
                modifier = Modifier
                    .height(buttonContainerHeight)
                    .wrapContentHeight(align = Alignment.CenterVertically)
            ) {
                androidx.compose.material3.IconButton(onClick = onTorchClick) {
                    androidx.compose.material3.Icon(
                        imageVector = if (torchState) androidx.compose.material.icons.Icons.Default.FlashOn else androidx.compose.material.icons.Icons.Default.FlashOff,
                        contentDescription = if (torchState) "Turn off flashlight" else "Turn on flashlight",
                        tint = if (torchState) androidx.compose.ui.graphics.Color.Yellow else androidx.compose.ui.graphics.Color.White
                    )
                }
            }
        } else {
            // X button is now positioned below the expanded content in CameraScreen
            // Keep the bottom bar empty when expanded to maintain layout consistency
            Spacer(modifier = Modifier.weight(1f))
            Spacer(modifier = Modifier.size(80.dp)) // Placeholder to maintain layout
            Spacer(modifier = Modifier.weight(1f))
        }
    }
}

private fun calculateBottomBarHeight(screenWidthDp: Int, density: androidx.compose.ui.unit.Density): androidx.compose.ui.unit.Dp {
    return with(density) {
        // Calculate base height using screen width ratio
        val baseHeight = (screenWidthDp * BOTTOM_BAR_HEIGHT_RATIO) - BOTTOM_BAR_HEIGHT_OFFSET

        // Ensure minimum height for small screens (around 120dp minimum)
        val minHeight = 120

        // Use the larger of calculated height or minimum height
        maxOf(baseHeight.toInt(), minHeight).dp
    }
}

@Preview(name = "Bottom Bar Dark Mode", showBackground = true)
@Composable
fun BottomBarDarkPreview() {
    IRKitUITheme(darkTheme = true) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        ) {
            BottomBar(
                onCaptureClick = { },
                onSelectImageClick = { },
                isExpanded = false,
                onCloseClick = { },
                onTorchClick = { },
                torchState = false,
                hasVisibleNavigationBar = false,
                cameraMode = CameraMode.SNAPSHOT,
                onAppModeChanged = { }
            )
        }
    }
}

@Preview(name = "Bottom Bar Expanded Light Mode", showBackground = true)
@Composable
fun BottomBarExpandedLightPreview() {
    IRKitUITheme(darkTheme = false) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        ) {
            BottomBar(
                onCaptureClick = { },
                onSelectImageClick = { },
                isExpanded = true,
                onCloseClick = { },
                onTorchClick = { },
                torchState = false,
                hasVisibleNavigationBar = false,
                cameraMode = CameraMode.SNAPSHOT,
                onAppModeChanged = { }
            )
        }
    }
}

@Preview(name = "Bottom Bar Expanded Dark Mode", showBackground = true)
@Composable
fun BottomBarExpandedDarkPreview() {
    IRKitUITheme(darkTheme = true) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
        ) {
            BottomBar(
                onCaptureClick = { },
                onSelectImageClick = { },
                isExpanded = true,
                onCloseClick = { },
                onTorchClick = { },
                torchState = false,
                hasVisibleNavigationBar = false,
                cameraMode = CameraMode.SNAPSHOT,
                onAppModeChanged = { }
            )
        }
    }
}
