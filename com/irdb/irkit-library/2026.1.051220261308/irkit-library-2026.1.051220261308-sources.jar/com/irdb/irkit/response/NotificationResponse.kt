package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName
import com.irdb.irkit.dto.NotificationItemDto

// Response wrapper for notifications API

data class NotificationResponse(
    @SerializedName("Notifications")
    val notifications: List<NotificationItemDto> = emptyList()
)
