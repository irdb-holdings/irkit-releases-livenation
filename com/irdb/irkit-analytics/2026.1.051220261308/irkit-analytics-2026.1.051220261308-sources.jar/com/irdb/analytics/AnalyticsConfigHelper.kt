package com.irdb.analytics

import kotlin.time.Duration.Companion.seconds

/**
 * Builds the sessionSource string dynamically from its component parts.
 * Format: "{platform}-{companyName}-{bucketName}"
 *
 * @param platform The platform identifier (e.g., "Android")
 * @param companyName The company name (e.g., "ksl", "irdb")
 * @param bucketName The analytics bucket name (e.g., "ksldemo", "irdbMain")
 * @return The constructed sessionSource string (e.g., "Android-ksl-ksldemo")
 */
fun buildSessionSource(platform: String, companyName: String, bucketName: String): String {
    return "$platform-$companyName".lowercase()
}

/**
 * Refresh an event's `sessionSource` after `/lenses` resolves the lens
 * identifiers. `bucketName` is intentionally NOT touched: per §2.2 of the
 * analytics spec it must be the matched-asset's collection (set by the call
 * site from the /lookup response), or omitted entirely on status / non-asset
 * events. Stamping the lens primary onto buffered events would re-introduce
 * the misattribution we are eliminating. Returns a NEW
 * [com.irdb.analytics.models.EventPayload] so any held reference (the buffer
 * snapshot) stays consistent.
 */
internal fun rebrandEventBucket(
    event: com.irdb.analytics.models.EventPayload,
    @Suppress("UNUSED_PARAMETER") bucketName: String,
    sessionSource: String
): com.irdb.analytics.models.EventPayload {
    return event.copy(
        parameters = event.parameters.toMutableMap().apply {
            this["sessionSource"] = sessionSource
        }
    )
}

/**
 * Helper function to create AnalyticsConfig from Java.
 * Provides sensible defaults for all parameters.
 */
fun createAnalyticsConfig(
    apiEndpoint: String,
    apiKey: String,
    companyName: String,
    bucketName: String,
    isDebugBuild: Boolean
): AnalyticsConfig {
    return AnalyticsConfig(
        apiEndpoint = apiEndpoint,
        apiKey = apiKey,
        companyName = companyName,
        bucketName = bucketName,
        enableMocking = true,  // Mock/log only (no network calls)
        enableDebugLogging = isDebugBuild,
        autoTrackLifecycle = true,  // REQUIRED for session tracking
        autoDetectDeviceInfo = true,
        enableCaching = true,
        cacheRetentionPolicy = CacheRetentionPolicy.CLEAR_ON_SUCCESS,
        maxBatchSize = 100,
        flushInterval = 1.seconds,
        autoSyncOnConnectivity = true
    )
}
