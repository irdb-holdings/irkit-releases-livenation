package com.irdb.irkitui.ui.dimens

import androidx.compose.ui.unit.dp

object ExpandedContentDimens {
    val horizontalPadding = 3.dp
    val verticalPadding = 12.dp
    val cardHorizontalPadding = 16.dp
    val sectionSpacing = 8.dp
    val metaTablePadding = 4.dp
    val metaRowVerticalPadding = 2.dp
}
