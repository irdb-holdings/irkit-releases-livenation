package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName

/*{
	"Completed": true,
	"Time": "2025-5-7 18:45:08.270",
	"TimeUsed": 35,
	"GCRLog": "development-v1-43-1306562873-98",
	"NextOffset": 0,
	"Total": 0,
	"Count": 0,
	"Pages": 0,
	"Environment": "DEV",
	"GCFVersion": "development-v1-43-00335-cix",
	"Results": {
		"History": true
	}
}*/

data class ImageHistoryAddResponse(
    @SerializedName("History")
    val history: Boolean
)
