package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName

/*
{
	"Completed": true,
	"Time": "2025-5-19 18:13:36.533",
	"TimeUsed": 25,
	"GCRLog": "development-v1-43-2702525306-435",
	"NextOffset": 0,
	"Total": 0,
	"Count": 0,
	"Pages": 0,
	"Environment": "DEV",
	"GCFVersion": "development-v1-43-00442-boh",
	"Results": {
		"Removed": true
	}
}
*/

data class ImageHistoryDeleteResponse(
    @SerializedName("Removed")
    val removed: Boolean
)
