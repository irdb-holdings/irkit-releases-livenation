package com.irdb.irkit.enums

//enum class ImageStates {
//    Published,
//    Draft;
//
//    val description: String
//        get() = when (this) {
//            Published -> "publish"
//            Draft -> "draft"
//        }
//}

enum class ImageStatus {
    DRAFT,
    PUBLISH;

    override fun toString(): String {
        return when (this) {
            DRAFT -> "draft"
            PUBLISH -> "publish"
        }
    }
}
