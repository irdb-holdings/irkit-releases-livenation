package com.irdb.analytics

import android.app.Application
import android.content.Context
import android.util.Log
import com.irdb.analytics.models.AnalyticsDebugInfo
import com.irdb.analytics.models.CacheStats
import com.irdb.analytics.models.EventPayload
import com.irdb.analytics.models.UserContext
import com.irdb.analytics.utils.SessionTrackingIdGenerator
import com.irdb.analytics.utils.UuidV7Canonicalizer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Main public API for analytics tracking.
 * Provides a simple, clean interface for apps to track events.
 */
class AnalyticsClient private constructor(
    private val config: AnalyticsConfig,
    private val context: Context
) {
    private val logger = AnalyticsLogger(config)
    private val timerManager = TimerManager(logger)
    private val deviceInfoDetector = DeviceInfoDetector(context)
    private val locationProvider = LocationProvider(context, logger)
    private val locationGeocoder = LocationGeocoder(context, logger)
    private val userPreferences = UserPreferences(context)
    // v2.0: advertisingIdProvider removed (deviceIFA no longer sent)
    private val cache = AnalyticsCache(context, config, logger)
    private val repository = AnalyticsRepository(config, logger, cache)
    private val lifecycleTracker = LifecycleTracker(this, config, logger, userPreferences)
    private val networkMonitor = NetworkMonitor(
        context,
        onConnectivityRestored = { flush() },
        logger,
        onTransportChanged = { /* server now derives source IP per-event; nothing to refresh */ }
    )
    private val scanMatchDeduplicator = ScanMatchDeduplicator()
    private val viewCompressedDeduplicator = ViewCompressedDeduplicator()
    private val viewEventBuffer = ViewEventBuffer(logger)
    private val firstCompressedTimeToDisplayTracker = FirstCompressedTimeToDisplayTracker()

    // ─── Pre-bucket-resolution event hold ─────────────────────────────────
    //
    // /lenses (which carries the real bucket / sessionSource) is deferred to
    // lens-open to keep app startup REST-free. Any analytics events that fire
    // BEFORE /lenses returns would otherwise ship with the placeholder bucket
    // (e.g. "--") and a malformed sessionSource — corrupting the server's
    // very first row per session.
    //
    // Strategy:
    //   1. On first-ever launch: hold events in memory until setBucketName()
    //      is called with the real /lenses value, then rewrite and flush.
    //   2. On subsequent launches: load the last-known bucket from
    //      UserPreferences before the first event fires (see init{} below).
    //      If present, treat the bucket as already resolved — the buffer is
    //      bypassed entirely, events go straight to the repository, and the
    //      existing SQLite offline cache covers any process death even when
    //      the REST backend is unreachable.
    //
    // Cap: the in-memory buffer is bounded so a permanently-offline /lenses
    // does not grow without limit. Past the cap, events are dropped with a
    // logger warning rather than risking OOM.
    private val bucketResolved = java.util.concurrent.atomic.AtomicBoolean(false)
    private val pendingPreBucketEvents =
        java.util.Collections.synchronizedList(mutableListOf<EventPayload>())

    private var userContext: UserContext? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    
    // Current session tracking ID: generated each time onSessionStarted() is called
    // This ID is used for all events until the next onSessionStarted() call
    // @Volatile so the synchronous write in onSessionStarted() is visible to
    // subsequent reads on Dispatchers.IO (e.g. trackStatusEvent's coroutine
    // reading sessionTrackingID via buildEventParameters). Without this, a
    // SESSION_STARTED event fired immediately after onSessionStarted() could
    // fall back to SessionTrackingIdGenerator.generate() and ship a different
    // UUID than the one used by the rest of the session — server-side correlation
    // would lose that session entirely.
    @Volatile
    private var currentSessionTrackingId: String? = null
    
    // Session-level geocoding cache: geocode once per session, reuse for all events
    // Key: "lat,lng" rounded to 4 decimal places, Value: geocoded address string
    private var sessionGeocodeCache: Pair<String, String>? = null
    
    /**
     * Round coordinates to 4 decimal places (~11 meters precision) for session caching.
     * This prevents cache misses for tiny GPS variations within the same location.
     */
    private fun roundCoordinate(coord: Double): Double {
        return (coord * 10000).toInt().toDouble() / 10000
    }
    
    /**
     * Get cache key for coordinates (rounded to avoid cache misses from minor GPS variations).
     */
    private fun getLocationCacheKey(latitude: Double, longitude: Double): String {
        val roundedLat = roundCoordinate(latitude)
        val roundedLng = roundCoordinate(longitude)
        return "$roundedLat,$roundedLng"
    }
    
    /**
     * Get location lookup for coordinates, using session-level cache.
     * Geocodes once per session and reuses the result for all events.
     */
    private suspend fun getSessionLocationLookup(latitude: Double, longitude: Double): String? {
        val cacheKey = getLocationCacheKey(latitude, longitude)
        
        // Check session cache first
        sessionGeocodeCache?.let { (cachedKey, cachedAddress) ->
            if (cachedKey == cacheKey) {
                logger.logDebug("📍 [Geocoder] Session cache HIT: $cachedAddress")
                return cachedAddress
            } else {
                // Location changed significantly, clear cache and geocode new location
                logger.logDebug("📍 [Geocoder] Location changed, clearing session cache")
                sessionGeocodeCache = null
            }
        }
        
        // No cache hit - geocode once for this session
        logger.logDebug("📍 [Geocoder] Geocoding once for this session: lat=$latitude, lng=$longitude")
        val locationLookup = locationGeocoder.getLocationLookup(latitude, longitude)
        
        // Cache the result for this session
        if (locationLookup != null) {
            sessionGeocodeCache = cacheKey to locationLookup
            logger.logDebug("📍 [Geocoder] Session cache updated: $locationLookup")
        }
        
        return locationLookup
    }
    
    init {
        // Bucket-cache fast path: if a previous session already learned the
        // real bucket from /lenses, restore it synchronously here so the very
        // first tracked event ships with the correct bucketName / sessionSource
        // even if the REST backend is slow or offline at startup. The buffer
        // becomes a fallback for the rare first-ever launch path only.
        val cachedBucket = userPreferences.loadCachedBucketName(config.companyName)
        if (!cachedBucket.isNullOrBlank()) {
            config.bucketName = cachedBucket
            bucketResolved.set(true)
            logger.logDebug(
                "🪣 Loaded cached bucket for company '${config.companyName}': '$cachedBucket' " +
                    "(buffer bypassed; events ship immediately)"
            )
        }

        // Initialize repository (loads cached events)
        scope.launch {
            repository.initialize()
        }
        
        // Load persisted userID and merge into userContext if not already set
        scope.launch {
            val persistedUserId = userPreferences.loadUserId()
            persistedUserId?.let { userId ->
                // If userContext is not set, create a minimal one with persisted userID
                // This ensures userID is available for all events even before setUserContext is called
                if (userContext == null) {
                    val deviceInfo = if (config.autoDetectDeviceInfo) {
                        deviceInfoDetector.detectDeviceInfo()
                    } else {
                        null
                    }
                    
                    userContext = UserContext(
                        userId = userId,
                        sessionSource = buildSessionSource("Android", config.companyName, config.bucketName),
                        deviceType = deviceInfo?.deviceType ?: UserContext.DEVICE_TYPE_ANDROID,
                        userAgent = deviceInfo?.userAgent,
                        networkType = deviceInfo?.networkType
                    )
                } else {
                    // If userContext exists but doesn't have userId, merge it in
                    if (userContext?.userId.isNullOrEmpty()) {
                        userContext = userContext?.copy(userId = userId)
                    }
                }
            }
        }
        
        // Check for unsent session-ended event from previous session
        // This handles cases where the app was killed, crashed, or force-stopped
        scope.launch {
            logger.logDebug("🔍 [Recovery] Checking for pending session end from previous session...")
            val pendingSessionEnd = userPreferences.loadPendingSessionEnd()
            if (pendingSessionEnd != null) {
                logger.logDebug("🔄 [Recovery] Found pending session-ended event from previous session: ${pendingSessionEnd.sessionTrackingId}")
                logger.logDebug("🔄 [Recovery] Session start: ${pendingSessionEnd.sessionStartTimestamp}, end: ${pendingSessionEnd.sessionEndTimestamp}")
                logger.logDebug("🔄 [Recovery] Duration: ${pendingSessionEnd.sessionEndTimestamp - pendingSessionEnd.sessionStartTimestamp}ms")
                
                // Send session-ended event for the PREVIOUS session
                // CRITICAL: Use the original sessionTrackingId from the closed session
                trackSessionStoppedStatusEvent(
                    durationMs = pendingSessionEnd.sessionEndTimestamp - pendingSessionEnd.sessionStartTimestamp,
                    additionalParams = mapOf(
                        // Override `created` so the wire timestamp reflects the actual past session-end,
                        // not the moment this recovery code runs.
                        "created" to pendingSessionEnd.sessionEndTimestamp,
                        "sessionTrackingID" to pendingSessionEnd.sessionTrackingId
                    )
                )
                
                // Force immediate send
                flush()
                
                // Clear pending session after successful queue
                // Note: Even if flush fails, we clear it because the event is now in the cache
                // and will be retried automatically by the repository
                userPreferences.clearPendingSessionEnd()
                
                logger.logDebug("📤 [Recovery] Queued deferred session-ended event for session: ${pendingSessionEnd.sessionTrackingId}")
            } else {
                logger.logDebug("🔍 [Recovery] No pending session end found (app was likely killed while in foreground)")
            }
        }
        
        // Initialize lifecycle tracking
        if (context is Application) {
            lifecycleTracker.initialize(context)
        }
        
        // Start network monitoring if enabled
        if (config.autoSyncOnConnectivity) {
            networkMonitor.start()
        }
    }
    
    /**
     * Set user context (called when user logs in/out)
     */
    fun setUserContext(userContext: UserContext) {
        // Merge with auto-detected device info
        val deviceInfo = if (config.autoDetectDeviceInfo) {
            deviceInfoDetector.detectDeviceInfo()
        } else {
            null
        }

        // Preserve currentSessionTrackingId if it exists (active session takes precedence)
        // Otherwise use the sessionTrackingId from the provided userContext
        val sessionTrackingId = currentSessionTrackingId?.takeIf { it.isNotEmpty() }
            ?: userContext.sessionTrackingId?.takeIf { it.isNotEmpty() }

        // Resolve userId: use provided value, or fall back to persistent anonymous UUIDv7
        val resolvedUserId = userContext.userId?.let { userId ->
            UuidV7Canonicalizer.canonicalizeOrNull(userId) ?: userId
        } ?: userPreferences.getOrCreateAnonymousUserId()

        this.userContext = userContext.copy(
            userId = resolvedUserId,
            deviceType = if (userContext.deviceType != UserContext.DEVICE_TYPE_ANDROID) {
                userContext.deviceType
            } else {
                deviceInfo?.deviceType ?: userContext.deviceType
            },
            userAgent = userContext.userAgent ?: deviceInfo?.userAgent,
            networkType = userContext.networkType ?: deviceInfo?.networkType,
            sessionSource = buildSessionSource("Android", config.companyName, config.bucketName),
            sessionTrackingId = sessionTrackingId
        )
        
        // Persist userID for use in all subsequent analytics calls
        userPreferences.saveUserId(this.userContext?.userId)
    }
    
    /**
     * Get current user context (for preserving fields like sessionTrackingId)
     */
    fun getUserContext(): UserContext? {
        return userContext
    }
    
    /**
     * Clear user context (on logout)
     */
    fun clearUserContext() {
        userContext = null
        userPreferences.clearUserId()
    }
    
    /**
     * Track scan event
     * 
     * For Scan Result — Match events:
     * - Only submits matches when they are new and unique
     * - If the same match is returned within the same second, it counts as a single match
     * - Deduplication is handled automatically for matched=true events
     * 
     * Match Data Fields (Required after successful scan match per analytics spec):
     * - userIDOwner: The userID of the user who owns the matched image
     * - usernameOwner: The username of the user who owns the matched image
     * - These fields must be included in all subsequent events related to the matched scan
     */
    fun trackScanEvent(
        scanType: ScanType,
        matched: Boolean,
        imageId: String? = null,
        campaignId: Long? = null,
        campaignName: String? = null,
        scanTrackingId: String? = null,
        similarCount: Int? = null,
        failed: Boolean = false,
        imageUrlOfScan: String? = null,
        viewSource: ViewSource? = null,
        imageTitle: String? = null,
        imageUrl: String? = null,
        bucketName: String? = null,
        userIDOwner: String? = null,
        usernameOwner: String? = null,
        category: String? = null,
        // Live+ frame-capture overrides — see FrameCaptureContext. When non-null,
        // these replace the default emit-time `created` / `sessionTrackingID` so
        // the scan event reports the moment the user actually scanned, not when
        // the async match pipeline returned. Null = fall back to emit-time
        // stamping (current behavior for snapshot/creator and any path that
        // doesn't propagate ctx).
        capturedAtMs: Long? = null,
        capturedSessionTrackingId: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            // Per analytics_doc.md: "omit this call entirely for Live Visual Search" when no match.
            // No-match events are only for snapshot and camera roll modes.
            if (!matched && !failed && scanType == ScanType.LIVE) {
                logger.logDebug("📊 [Scan Event] Suppressing no-match event for live scan (per spec)")
                return@launch
            }

            // Live Visual Search dedup per analytics_doc (3).md §"Scan Result - Match":
            //   "For Live Visual Search based matches, only submit matches when they are new
            //    and unique."
            // Snapshot, creator, and captureButton scans are deliberate user actions — every one
            // is a distinct event and must always POST. Dedup applies to LIVE only.
            //
            // Cleared via:
            //   - onMatchPopupDismissed() — wired from IRKitLens dismiss handlers (notification clients)
            //   - onSessionStarted() / onSessionStopped() — lens session boundaries
            //   - onAppBackgrounded() — equivalent to "preview popup paused" per spec §7
            // No-notification clients (no IRKitLens UI) rely on the session/lifecycle clears.
            if (matched && imageId != null && scanType == ScanType.LIVE) {
                if (!scanMatchDeduplicator.shouldSubmitMatch(imageId)) {
                    logger.logDebug("📊 [Scan Event] Skipping duplicate live match for imageID=$imageId (already displayed in current popup)")
                    return@launch
                }
            }
            
            // Per analytics_doc_v2.1.md §"Scan Result - Match" (lines 447-478):
            // duration on a scan-result-match is ALWAYS 0 — the event opens a
            // new local timer for the match section, it does not close one.
            // Reading SCAN_MATCH here would leak the previous match's elapsed
            // time onto the new scan event. The timer is (re)started below so
            // post-match events have a consistent reference point.
            val duration = 0L

            if (matched) {
                timerManager.startTimer(TimerManager.TimerType.SCAN_MATCH)
            }
            
            val optionalParams = mutableMapOf<String, Any>()
            imageId?.let { optionalParams["imageID"] = it }
            campaignId?.let { optionalParams["campaignID"] = it }
            campaignName?.let { optionalParams["campaignName"] = it }
            scanTrackingId?.let { rawScanTrackingId ->
                optionalParams["scanTrackingID"] =
                    UuidV7Canonicalizer.canonicalizeOrNull(rawScanTrackingId) ?: rawScanTrackingId
            }
            similarCount?.let { optionalParams["similarCount"] = it }
            imageUrlOfScan?.takeIf { it.isNotBlank() }?.let { optionalParams["imageUrlOfScan"] = it }
            imageTitle?.takeIf { it.isNotBlank() }?.let { optionalParams["imageTitle"] = it }
            imageUrl?.takeIf { it.isNotBlank() }?.let { optionalParams["imageUrl"] = it }
            viewSource?.let { optionalParams["viewSource"] = it.value }
            userIDOwner?.let { optionalParams["userIDOwner"] = it }
            usernameOwner?.let { optionalParams["usernameOwner"] = it }
            category?.let { optionalParams["category"] = it }
            
            // Per spec: bucketName must come from the matched asset. If the
            // caller didn't supply one (or it's empty), OMIT the field — DO
            // NOT fall back to the lens primary (config.bucketName), because
            // that's the misattribution we're eliminating.
            val mergedAdditional = (additionalParams + mapOf(
                "scanType" to scanType.value,
                "duration" to duration,
                "matched" to matched,
            )).toMutableMap()
            if (failed) {
                mergedAdditional["failed"] = true
            }
            bucketName?.takeIf { it.isNotBlank() }?.let { mergedAdditional["bucketName"] = it }

            // Frame-capture-time overrides for the session-after-scan race fix.
            // These ride through the additionalParams override path in
            // buildEventParameters() so we don't need a parallel code path.
            capturedAtMs?.let { mergedAdditional["created"] = it }
            capturedSessionTrackingId
                ?.takeIf { it.isNotBlank() }
                ?.let { mergedAdditional["sessionTrackingID"] = it }

            val parameters = buildEventParameters(
                eventName = "scan",
                additionalParams = mergedAdditional
            ) + optionalParams
            
            val event = EventPayload(
                eventName = "scan",
                timestamp = System.currentTimeMillis(),
                parameters = parameters
            )
            
            // Verification logging for campaign fields
            if (imageId != null) {
                logger.logDebug("📊 [Scan Event] imageId=$imageId, campaignId=$campaignId, campaignName=$campaignName")
            }
            
            enqueueEvent(event)
            // shouldSubmitMatch() above already updates currentMatchedImageId when admitting a match,
            // so no separate markAsSubmitted() call is needed here.
        }
    }
    
    /**
     * Track view event (LEGACY - Immediate Send Pattern)
     * 
     * DEPRECATED for COMPRESSED/EXPANDED views in Live mode notification cards.
     * Use bufferViewEvent() + sendBufferedViewEvent() instead for the new buffered pattern.
     * 
     * This method is still valid for:
     * - FULL view type (ImageDetailsView dialog)
     * - Library section views (History, Save, etc.)
     * - Any view that doesn't need buffering/duration tracking
     * 
     * For Live mode notification cards (compressed/expanded):
     * - Use bufferViewEvent() when card appears
     * - Use sendBufferedViewEvent() when user takes action
     * - This provides duration and timeToDisplay automatically
     * 
     * Match Data Fields (Include when viewing matched content):
     * - userIDOwner: The userID of the user who owns the matched image
     * - usernameOwner: The username of the user who owns the matched image
     * - imageUrlOfScan: URL of image submitted by user to make the match
     */
    fun trackViewEvent(
        viewType: ViewType,
        viewSource: ViewSource,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        userIDOwner: String? = null,
        usernameOwner: String? = null,
        imageUrlOfScan: String? = null,
        // Per-asset bucket from the matched ImageModel. When null, the default
        // applied by buildEventParameters (config.bucketName, the lens primary)
        // is used — appropriate only for non-asset events. Match analytics MUST
        // pass the asset's bucket for correct /Statistics attribution.
        bucketName: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            // Deduplicate view/compressed for the same imageId (e.g. repeated callbacks from UI)
            if (viewType == ViewType.COMPRESSED && imageId != null) {
                if (!viewCompressedDeduplicator.shouldSubmitViewCompressed(imageId)) {
                    logger.logDebug("📊 [View Event] Skipping duplicate view/compressed for imageId=$imageId")
                    return@launch
                }
            }

            val timerType = when (viewType) {
                ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
                ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
                ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
            }

            // Get duration from previous view (if any)
            val duration = when (viewType) {
                ViewType.COMPRESSED -> 0L  // Starting compressed view
                ViewType.EXPANDED -> timerManager.getDuration(TimerManager.TimerType.COMPRESSED_VIEW)
                ViewType.FULL -> timerManager.getDuration(TimerManager.TimerType.EXPANDED_VIEW)
            }

            // Stop previous view timer
            when (viewType) {
                ViewType.COMPRESSED -> { /* No previous */ }
                ViewType.EXPANDED -> timerManager.stopTimer(TimerManager.TimerType.COMPRESSED_VIEW)
                ViewType.FULL -> timerManager.stopTimer(TimerManager.TimerType.EXPANDED_VIEW)
            }

            // Start timer for this view
            timerManager.startTimer(timerType)

            val optionalParams = mutableMapOf<String, Any>()
            imageId?.let { optionalParams["imageID"] = it }
            campaignId?.let { optionalParams["campaignID"] = it }
            campaignName?.let { optionalParams["campaignName"] = it }
            userIDOwner?.let { optionalParams["userIDOwner"] = it }
            usernameOwner?.let { optionalParams["usernameOwner"] = it }
            imageUrlOfScan?.let { optionalParams["imageUrlOfScan"] = it }

            // CRITICAL: Ensure viewType is always set and cannot be overwritten by additionalParams
            // Merge additionalParams first, then explicitly set viewType, viewSource, and duration
            val mergedParams = additionalParams.toMutableMap()
            mergedParams["viewType"] = viewType.value
            mergedParams["viewSource"] = viewSource.value
            mergedParams["duration"] = duration
            mergedParams.remove("timeToDisplay")

            val explicitScanTrackingId = extractScanTrackingId(additionalParams)
            val providedTimeToDisplay = (additionalParams["timeToDisplay"] as? Number)?.toLong()
            consumeTimeToDisplayForView(
                viewType = viewType,
                scanTrackingId = explicitScanTrackingId,
                timeToDisplay = providedTimeToDisplay
            )?.let { normalizedTimeToDisplay ->
                mergedParams["timeToDisplay"] = normalizedTimeToDisplay
            }
            // Per-asset bucket override — wins over the buildEventParameters
            // default (line ~1575) via the additionalParams merge at ~1674.
            bucketName?.takeIf { it.isNotEmpty() }?.let { mergedParams["bucketName"] = it }

            val parameters = buildEventParameters(
                eventName = "view",
                additionalParams = mergedParams
            ) + optionalParams

            val event = EventPayload(
                eventName = "view",
                timestamp = System.currentTimeMillis(),
                parameters = parameters
            )

            // Verification logging for campaign fields
            if (imageId != null) {
                logger.logDebug("📊 [View Event] imageId=$imageId, campaignId=$campaignId, campaignName=$campaignName")
            }

            enqueueEvent(event)

            if (viewType == ViewType.COMPRESSED && imageId != null) {
                viewCompressedDeduplicator.markViewCompressedSubmitted(imageId)
            }
        }
    }
    
    /**
     * Buffer a view event to be sent later when user takes action.
     *
     * New Pattern (Buffered Events):
     * - When notification card appears → Call bufferViewEvent (don't send yet)
     * - When user takes action (expand, dismiss, click link) → Call sendBufferedViewEvent
     * - Event is sent WITH duration and timeToDisplay
     *
     * @param viewType The type of view (compressed, expanded, full)
     * @param viewSource The source of the view (liveScan, snapshot, etc.)
     * @param imageId Optional imageID for deduplication
     * @param campaignId Optional campaign ID
     * @param campaignName Optional campaign name
     * @param userIDOwner Optional owner user ID (for matched content)
     * @param usernameOwner Optional owner username (for matched content)
     * @param imageUrlOfScan URL of image submitted by user to make the match (required after match)
     * @param trackingId Optional tracking ID for ImageLifecycleTracker (for timeToDisplay calculation)
     * @param additionalParams Additional parameters to include in event
     */
    fun bufferViewEvent(
        viewType: ViewType,
        viewSource: ViewSource,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        userIDOwner: String? = null,
        usernameOwner: String? = null,
        imageUrlOfScan: String? = null,
        trackingId: String? = null,
        // Per-asset bucket — see trackViewEvent's bucketName param. Stuffed into
        // additionalParams so it round-trips through the buffer and lands in
        // the final POST when sendBufferedViewEvent fires.
        bucketName: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            // Check if should buffer (deduplication)
            if (!viewEventBuffer.shouldBuffer(imageId, viewType)) {
                logger.logDebug("📊 [Buffer] Skipping duplicate buffer for imageId=$imageId, viewType=${viewType.value}")
                return@launch
            }

            // Fold bucketName into additionalParams so the buffer carries it
            // through to sendBufferedViewEvent's buildEventParameters call.
            val effectiveAdditional = bucketName?.takeIf { it.isNotEmpty() }?.let {
                additionalParams + ("bucketName" to it)
            } ?: additionalParams

            // Create buffered event
            val bufferedEvent = ViewEventBuffer.BufferedViewEvent(
                viewType = viewType,
                viewSource = viewSource,
                imageId = imageId,
                campaignId = campaignId,
                campaignName = campaignName,
                userIDOwner = userIDOwner,
                usernameOwner = usernameOwner,
                imageUrlOfScan = imageUrlOfScan,
                startTimestamp = System.currentTimeMillis(),
                trackingId = trackingId,
                additionalParams = effectiveAdditional
            )
            
            // Buffer the event
            val buffered = viewEventBuffer.bufferViewEvent(bufferedEvent)
            if (buffered) {
                logger.logDebug("📊 [Buffer] Buffered ${viewType.value} event for imageId=$imageId, trackingId=$trackingId")
                
                // Start timer for this view type
                val timerType = when (viewType) {
                    ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
                    ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
                    ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
                }
                timerManager.startTimer(timerType)
            }
        }
    }
    
    /**
     * Send the buffered view event with duration and timeToDisplay.
     * Called when user takes action (expand, dismiss, click link, etc.)
     *
     * @param timeToDisplay Optional timeToDisplay value (in milliseconds) from ImageLifecycleTracker
     * @return true if event was sent, false if no buffered event
     */
    suspend fun sendBufferedViewEvent(timeToDisplay: Long? = null): Boolean {
        return viewEventBuffer.sendBufferedEvent(
            getDuration = { startTimestamp ->
                // Calculate duration from start timestamp
                System.currentTimeMillis() - startTimestamp
            },
            getTimeToDisplay = { _ ->
                // Use provided timeToDisplay value
                timeToDisplay
            }
        )?.let { bufferedEvent ->
            // Calculate duration
            val duration = System.currentTimeMillis() - bufferedEvent.startTimestamp

            val scanTrackingId = extractScanTrackingId(
                additionalParams = bufferedEvent.additionalParams,
                fallbackTrackingId = bufferedEvent.trackingId
            )
            val finalTimeToDisplay = consumeTimeToDisplayForView(
                viewType = bufferedEvent.viewType,
                scanTrackingId = scanTrackingId,
                timeToDisplay = timeToDisplay
            )

            // Stop timer for this view type
            val timerType = when (bufferedEvent.viewType) {
                ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
                ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
                ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
            }
            timerManager.stopTimer(timerType)

            // Build optional params
            val optionalParams = mutableMapOf<String, Any>()
            bufferedEvent.imageId?.let { optionalParams["imageID"] = it }
            bufferedEvent.campaignId?.let { optionalParams["campaignID"] = it }
            bufferedEvent.campaignName?.let { optionalParams["campaignName"] = it }
            bufferedEvent.userIDOwner?.let { optionalParams["userIDOwner"] = it }
            bufferedEvent.usernameOwner?.let { optionalParams["usernameOwner"] = it }
            bufferedEvent.imageUrlOfScan?.let { optionalParams["imageUrlOfScan"] = it }

            finalTimeToDisplay?.let { optionalParams["timeToDisplay"] = it }

            // Merge with additional params from buffered event
            val mergedParams = bufferedEvent.additionalParams.toMutableMap()
            mergedParams["viewType"] = bufferedEvent.viewType.value
            mergedParams["viewSource"] = bufferedEvent.viewSource.value
            mergedParams["duration"] = duration

            val parameters = buildEventParameters(
                eventName = "view",
                additionalParams = mergedParams
            ) + optionalParams

            // CRITICAL: Use the original start timestamp, NOT current time
            // The timestamp must reflect when the event ACTUALLY happened, not when it's sent
            val event = EventPayload(
                eventName = "view",
                timestamp = bufferedEvent.startTimestamp,
                parameters = parameters
            )

            logger.logDebug("📊 [Buffer] Sent ${bufferedEvent.viewType.value} event for imageId=${bufferedEvent.imageId}, duration=${duration}, timeToDisplay=${finalTimeToDisplay ?: "<omitted>"}, imageUrlOfScan=${bufferedEvent.imageUrlOfScan}, timestamp=${bufferedEvent.startTimestamp}")

            enqueueEvent(event)

            true
        } ?: false
    }

    /**
     * Synchronously send buffered view event and wait for persistence.
     * Use for critical exit paths where event loss is unacceptable.
     *
     * @param timeToDisplay Optional timeToDisplay value (in milliseconds) from ImageLifecycleTracker
     * @return true if event was sent, false if no buffered event
     */
    suspend fun sendBufferedViewEventSync(timeToDisplay: Long? = null): Boolean {
        return viewEventBuffer.sendBufferedEvent(
            getDuration = { startTimestamp ->
                // Calculate duration from start timestamp
                System.currentTimeMillis() - startTimestamp
            },
            getTimeToDisplay = { _ ->
                // Use provided timeToDisplay value
                timeToDisplay
            }
        )?.let { bufferedEvent ->
            // Calculate duration
            val duration = System.currentTimeMillis() - bufferedEvent.startTimestamp

            val scanTrackingId = extractScanTrackingId(
                additionalParams = bufferedEvent.additionalParams,
                fallbackTrackingId = bufferedEvent.trackingId
            )
            val finalTimeToDisplay = consumeTimeToDisplayForView(
                viewType = bufferedEvent.viewType,
                scanTrackingId = scanTrackingId,
                timeToDisplay = timeToDisplay
            )

            // Stop timer for this view type
            val timerType = when (bufferedEvent.viewType) {
                ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
                ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
                ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
            }
            timerManager.stopTimer(timerType)

            // Build optional params
            val optionalParams = mutableMapOf<String, Any>()
            bufferedEvent.imageId?.let { optionalParams["imageID"] = it }
            bufferedEvent.campaignId?.let { optionalParams["campaignID"] = it }
            bufferedEvent.campaignName?.let { optionalParams["campaignName"] = it }
            bufferedEvent.userIDOwner?.let { optionalParams["userIDOwner"] = it }
            bufferedEvent.usernameOwner?.let { optionalParams["usernameOwner"] = it }
            bufferedEvent.imageUrlOfScan?.let { optionalParams["imageUrlOfScan"] = it }

            finalTimeToDisplay?.let { optionalParams["timeToDisplay"] = it }

            // Merge with additional params from buffered event
            val mergedParams = bufferedEvent.additionalParams.toMutableMap()
            mergedParams["viewType"] = bufferedEvent.viewType.value
            mergedParams["viewSource"] = bufferedEvent.viewSource.value
            mergedParams["duration"] = duration

            val parameters = buildEventParameters(
                eventName = "view",
                additionalParams = mergedParams
            ) + optionalParams

            // CRITICAL: Use the original start timestamp, NOT current time
            // The timestamp must reflect when the event ACTUALLY happened, not when it's sent
            val event = EventPayload(
                eventName = "view",
                timestamp = bufferedEvent.startTimestamp,
                parameters = parameters
            )

            logger.logDebug("📊 [Buffer] Sent ${bufferedEvent.viewType.value} event (sync) for imageId=${bufferedEvent.imageId}, duration=${duration}, timeToDisplay=${finalTimeToDisplay ?: "<omitted>"}, imageUrlOfScan=${bufferedEvent.imageUrlOfScan}, timestamp=${bufferedEvent.startTimestamp}")

            // Use synchronous enqueue that waits for cache save
            enqueueEventSync(event)

            true
        } ?: false
    }
    
    /**
     * Clear the view event buffer without sending.
     * Called when card is dismissed or user navigates away without action.
     */
    fun clearViewEventBuffer() {
        scope.launch {
            viewEventBuffer.clearBuffer()
        }
    }
    
    /**
     * Track library section view event (History, Save, My IRCodes, Trash, Profile)
     * 
     * This is separate from trackViewEvent() because library sections use section timers
     * (which are managed separately) rather than view timers.
     * 
     * @param viewSource The library section being viewed (HISTORY, SAVE, MY_IRCODES, TRASH, PROFILE)
     * @param previousSectionDuration Duration spent in previous section (lap model)
     */
    fun trackLibrarySectionView(
        viewSource: ViewSource,
        previousSectionDuration: Long = 0L
    ) {
        scope.launch {
            // CRITICAL: Ensure viewType is always set for library section views
            val parameters = buildEventParameters(
                eventName = "view",
                additionalParams = mapOf(
                    "viewType" to ViewType.FULL.value,
                    "viewSource" to viewSource.value,
                    "duration" to previousSectionDuration
                )
            )
            
            val event = EventPayload(
                eventName = "view",
                timestamp = System.currentTimeMillis(),
                parameters = parameters
            )
            
            enqueueEvent(event)
        }
    }
    
    /**
     * Track button pressed event
     *
     * Per analytics_doc_v2.1.md, buttonPressed events do NOT carry `failed` or
     * `buttonTitle`. Failure semantics live on the v2.1 `link` event
     * (deeplinkError category) and the scan-failure event — not here.
     *
     * Match Data Fields (Include when button is related to matched content):
     * - userIDOwner: The userID of the user who owns the matched image
     * - usernameOwner: The username of the user who owns the matched image
     */
    fun trackButtonPressedEvent(
        buttonType: ButtonType,
        buttonSource: ButtonSource,
        buttonLink: String? = null,
        linkToFollow: String? = null,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        userIDOwner: String? = null,
        usernameOwner: String? = null,
        // Per-asset bucket for image-tied button presses (close-X on a
        // recognition popup, link/scan-to-site tap, etc.). Null/empty for
        // non-image button events — the field will be omitted from the POST.
        bucketName: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            // Get duration from active timer based on context
            val viewType = additionalParams["viewType"]?.toString()
            val duration = when (buttonSource) {
                ButtonSource.HOME_VIEW -> {
                    if (viewType == ViewType.EXPANDED.value) {
                        timerManager.getDuration(TimerManager.TimerType.EXPANDED_VIEW)
                    } else {
                        timerManager.getDuration(TimerManager.TimerType.COMPRESSED_VIEW)
                    }
                }
                ButtonSource.IRCODE_VIEW -> {
                    // Check FULL_VIEW timer first (ImageDetailsView)
                    val fullViewDuration = timerManager.getDuration(TimerManager.TimerType.FULL_VIEW)
                    if (fullViewDuration > 0) {
                        fullViewDuration
                    } else {
                        // Fall back to EXPANDED_VIEW timer (expanded notification)
                        timerManager.getDuration(TimerManager.TimerType.EXPANDED_VIEW)
                    }
                }
                ButtonSource.PROFILE_VIEW -> timerManager.getDuration(TimerManager.TimerType.SECTION_PROFILE)
                else -> timerManager.getDuration(TimerManager.TimerType.GLOBAL_SESSION)
            }

            val optionalParams = mutableMapOf<String, Any>()
            buttonLink?.let { optionalParams["buttonLink"] = it }
            linkToFollow?.let { optionalParams["linkToFollow"] = it }
            imageId?.let { optionalParams["imageID"] = it }
            campaignId?.let { optionalParams["campaignID"] = it }
            campaignName?.let { optionalParams["campaignName"] = it }
            userIDOwner?.let { optionalParams["userIDOwner"] = it }
            usernameOwner?.let { optionalParams["usernameOwner"] = it }

            val mergedAdditional = (additionalParams + mapOf(
                "buttonType" to buttonType.value,
                "buttonSource" to buttonSource.value,
                "duration" to duration,
            )).toMutableMap()
            // Only include bucketName when the caller has it from the
            // matched asset. No lens-default fallback (per spec).
            bucketName?.takeIf { it.isNotBlank() }?.let { mergedAdditional["bucketName"] = it }

            val parameters = buildEventParameters(
                eventName = "buttonPressed",
                additionalParams = mergedAdditional
            ) + optionalParams

            val event = EventPayload(
                eventName = "buttonPressed",
                timestamp = System.currentTimeMillis(),
                parameters = parameters
            )

            // Verification logging for campaign fields
            if (imageId != null) {
                logger.logDebug("📊 [Button Press Event] imageId=$imageId, campaignId=$campaignId, campaignName=$campaignName")
            }

            enqueueEvent(event)
        }
    }

    /**
     * Synchronously track button pressed event and wait for persistence.
     * Use for critical exit paths where event loss is unacceptable.
     */
    suspend fun trackButtonPressedEventSync(
        buttonType: ButtonType,
        buttonSource: ButtonSource,
        buttonLink: String? = null,
        linkToFollow: String? = null,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        userIDOwner: String? = null,
        usernameOwner: String? = null,
        // Per-asset bucket — see [trackButtonPressedEvent].
        bucketName: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        // Get duration from active timer based on context
        val viewType = additionalParams["viewType"]?.toString()
        val duration = when (buttonSource) {
            ButtonSource.HOME_VIEW -> {
                if (viewType == ViewType.EXPANDED.value) {
                    timerManager.getDuration(TimerManager.TimerType.EXPANDED_VIEW)
                } else {
                    timerManager.getDuration(TimerManager.TimerType.COMPRESSED_VIEW)
                }
            }
            ButtonSource.IRCODE_VIEW -> {
                // Check FULL_VIEW timer first (ImageDetailsView)
                val fullViewDuration = timerManager.getDuration(TimerManager.TimerType.FULL_VIEW)
                if (fullViewDuration > 0) {
                    fullViewDuration
                } else {
                    // Fall back to EXPANDED_VIEW timer (expanded notification)
                    timerManager.getDuration(TimerManager.TimerType.EXPANDED_VIEW)
                }
            }
            ButtonSource.PROFILE_VIEW -> timerManager.getDuration(TimerManager.TimerType.SECTION_PROFILE)
            else -> timerManager.getDuration(TimerManager.TimerType.GLOBAL_SESSION)
        }

        val optionalParams = mutableMapOf<String, Any>()
        buttonLink?.let { optionalParams["buttonLink"] = it }
        linkToFollow?.let { optionalParams["linkToFollow"] = it }
        imageId?.let { optionalParams["imageID"] = it }
        campaignId?.let { optionalParams["campaignID"] = it }
        campaignName?.let { optionalParams["campaignName"] = it }
        userIDOwner?.let { optionalParams["userIDOwner"] = it }
        usernameOwner?.let { optionalParams["usernameOwner"] = it }

        val mergedAdditional = (additionalParams + mapOf(
            "buttonType" to buttonType.value,
            "buttonSource" to buttonSource.value,
            "duration" to duration,
        )).toMutableMap()
        bucketName?.takeIf { it.isNotBlank() }?.let { mergedAdditional["bucketName"] = it }

        val parameters = buildEventParameters(
            eventName = "buttonPressed",
            additionalParams = mergedAdditional
        ) + optionalParams

        val event = EventPayload(
            eventName = "buttonPressed",
            timestamp = System.currentTimeMillis(),
            parameters = parameters
        )

        // Verification logging for campaign fields
        if (imageId != null) {
            logger.logDebug("📊 [Button Press Event] (sync) imageId=$imageId, campaignId=$campaignId, campaignName=$campaignName")
        }

        // Use synchronous enqueue that waits for cache save
        enqueueEventSync(event)
    }

    /**
     * v2.1 link event — microsite open associated with a matched IRCODE.
     *
     * buttonType=TAPPED: user tapped the compressed match bar to open the microsite.
     *   `duration` is the match-bar dwell (COMPRESSED_VIEW timer).
     * buttonType=AUTO_OPEN: scan-to-site auto-launched the microsite the instant the
     *   scan succeeded; preview UI is bypassed entirely. `duration` and `timeToDisplay`
     *   are omitted per spec.
     *
     * Distinct from `trackButtonPressedEvent(buttonType=LINK/LINK_TO_SITE)`, which still
     * represents a tap on a link inside an already-expanded match view.
     */
    fun trackLinkEvent(
        buttonType: ButtonType,
        linkToFollow: String,
        imageId: String,
        scanTrackingId: String,
        viewSource: ViewSource = ViewSource.LIVE_SCAN,
        bucketName: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        userIDOwner: String? = null,
        usernameOwner: String? = null,
        imageUrl: String? = null,
        imageTitle: String? = null,
        imageUrlOfScan: String? = null,
        // Spec line 948: `failed=true` (with `category=deeplinkError`) marks a
        // navigation that did not complete. Successful navigations omit the
        // field entirely — never POST `failed:false`.
        failed: Boolean? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            val event = buildLinkEvent(
                buttonType = buttonType,
                linkToFollow = linkToFollow,
                imageId = imageId,
                scanTrackingId = scanTrackingId,
                viewSource = viewSource,
                bucketName = bucketName,
                campaignId = campaignId,
                campaignName = campaignName,
                userIDOwner = userIDOwner,
                usernameOwner = usernameOwner,
                imageUrl = imageUrl,
                imageTitle = imageTitle,
                imageUrlOfScan = imageUrlOfScan,
                failed = failed,
                additionalParams = additionalParams
            )
            logger.logDebug("📊 [Link Event] buttonType=${buttonType.value}, imageId=$imageId, scanTrackingID=$scanTrackingId, failed=${failed ?: "<omitted>"}")
            enqueueEvent(event)
        }
    }

    /**
     * Synchronously track a link event and wait for persistence.
     * Required for the `tapped`-to-external-Chrome path where foreground is lost
     * before the async queue can flush.
     */
    suspend fun trackLinkEventSync(
        buttonType: ButtonType,
        linkToFollow: String,
        imageId: String,
        scanTrackingId: String,
        viewSource: ViewSource = ViewSource.LIVE_SCAN,
        bucketName: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        userIDOwner: String? = null,
        usernameOwner: String? = null,
        imageUrl: String? = null,
        imageTitle: String? = null,
        imageUrlOfScan: String? = null,
        // See [trackLinkEvent] — null on success, true on deeplink failure.
        failed: Boolean? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        val event = buildLinkEvent(
            buttonType = buttonType,
            linkToFollow = linkToFollow,
            imageId = imageId,
            scanTrackingId = scanTrackingId,
            viewSource = viewSource,
            bucketName = bucketName,
            campaignId = campaignId,
            campaignName = campaignName,
            userIDOwner = userIDOwner,
            usernameOwner = usernameOwner,
            imageUrl = imageUrl,
            imageTitle = imageTitle,
            imageUrlOfScan = imageUrlOfScan,
            failed = failed,
            additionalParams = additionalParams
        )
        logger.logDebug("📊 [Link Event] (sync) buttonType=${buttonType.value}, imageId=$imageId, scanTrackingID=$scanTrackingId, failed=${failed ?: "<omitted>"}")
        enqueueEventSync(event)
    }

    private suspend fun buildLinkEvent(
        buttonType: ButtonType,
        linkToFollow: String,
        imageId: String,
        scanTrackingId: String,
        viewSource: ViewSource,
        bucketName: String?,
        campaignId: String?,
        campaignName: String?,
        userIDOwner: String?,
        usernameOwner: String?,
        imageUrl: String?,
        imageTitle: String?,
        imageUrlOfScan: String?,
        failed: Boolean?,
        additionalParams: Map<String, Any>
    ): EventPayload {
        val merged = additionalParams.toMutableMap()
        merged["buttonType"] = buttonType.value
        merged["viewSource"] = viewSource.value
        merged["linkToFollow"] = linkToFollow
        merged["imageID"] = imageId
        merged["scanTrackingID"] = scanTrackingId

        // Duration only for TAPPED — the match-bar dwell. AUTO_OPEN has no preceding
        // dwell to measure; per spec the field must be omitted entirely.
        if (buttonType == ButtonType.TAPPED) {
            merged["duration"] = timerManager.getDuration(TimerManager.TimerType.COMPRESSED_VIEW)
        }

        // `failed` and its companion `category` are emitted ONLY on actual
        // failures. Successful navigations omit both — no `failed:false` padding.
        if (failed == true) {
            merged["failed"] = true
            merged.putIfAbsent("category", "deeplinkError")
        }

        bucketName?.takeIf { it.isNotBlank() }?.let { merged["bucketName"] = it }
        campaignId?.let { merged["campaignID"] = it }
        campaignName?.let { merged["campaignName"] = it }
        userIDOwner?.let { merged["userIDOwner"] = it }
        usernameOwner?.let { merged["usernameOwner"] = it }
        imageUrl?.let { merged["imageUrl"] = it }
        imageTitle?.let { merged["imageTitle"] = it }
        imageUrlOfScan?.let { merged["imageUrlOfScan"] = it }

        val parameters = buildEventParameters(
            eventName = "link",
            additionalParams = merged
        )

        return EventPayload(
            eventName = "link",
            timestamp = System.currentTimeMillis(),
            parameters = parameters
        )
    }

    /**
     * Track status event
     */
    fun trackSessionStartedStatusEvent(
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        trackStatusEvent(
            statusType = StatusType.SESSION_STARTED,
            additionalParams = additionalParams + mapOf(
                "duration" to 0L,
                "appSource" to APP_SOURCE
            )
        )
    }

    fun trackSessionStoppedStatusEvent(
        durationMs: Long,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        trackStatusEvent(
            statusType = StatusType.SESSION_STOPPED,
            additionalParams = additionalParams + mapOf(
                "duration" to durationMs
            )
        )
    }

    suspend fun trackSessionStoppedStatusEventSync(
        durationMs: Long,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        trackStatusEventSync(
            statusType = StatusType.SESSION_STOPPED,
            additionalParams = additionalParams + mapOf(
                "duration" to durationMs
            )
        )
    }

    fun trackStatusEvent(
        statusType: StatusType,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            val optionalParams = mutableMapOf<String, Any>()
            imageId?.let { optionalParams["imageID"] = it }
            campaignId?.let { optionalParams["campaignID"] = it }
            campaignName?.let { optionalParams["campaignName"] = it }
            
            val parameters = buildEventParameters(
                eventName = "status",
                additionalParams = additionalParams + mapOf(
                    "statusType" to statusType.value
                )
            ).plus(optionalParams).let { raw ->
                normalizeStatusParameters(
                    statusType = statusType,
                    rawParameters = raw,
                    additionalParams = additionalParams
                )
            }
            
            // For deferred / recovery events, the caller passes `created` in additionalParams
            // (a past epoch ms). buildEventParameters honors it because additionalParams is
            // merged in last, so the wire `created` field already reflects the right time.
            // Use the same value here so EventPayload.timestamp (cache ordering) matches.
            val eventTimestamp = (additionalParams["created"] as? Long) ?: System.currentTimeMillis()
            
            val event = EventPayload(
                eventName = "status",
                timestamp = eventTimestamp,
                parameters = parameters
            )
            
            // Verification logging for campaign fields
            if (imageId != null) {
                logger.logDebug("📊 [Status Event] imageId=$imageId, campaignId=$campaignId, campaignName=$campaignName")
            }
            
            enqueueEvent(event)
        }
    }

    /**
     * Synchronously track status event and wait for cache persistence.
     * Use for critical events (like session-ended) that must be persisted before app termination.
     *
     * This method blocks until the event is saved to the SQLite cache.
     */
    suspend fun trackStatusEventSync(
        statusType: StatusType,
        imageId: String? = null,
        campaignId: String? = null,
        campaignName: String? = null,
        additionalParams: Map<String, Any> = emptyMap()
    ) {
        val optionalParams = mutableMapOf<String, Any>()
        imageId?.let { optionalParams["imageID"] = it }
        campaignId?.let { optionalParams["campaignID"] = it }
        campaignName?.let { optionalParams["campaignName"] = it }

        val parameters = buildEventParameters(
            eventName = "status",
            additionalParams = additionalParams + mapOf(
                "statusType" to statusType.value
            )
        ).plus(optionalParams).let { raw ->
            normalizeStatusParameters(
                statusType = statusType,
                rawParameters = raw,
                additionalParams = additionalParams
            )
        }

        // For deferred / recovery events, the caller passes `created` in additionalParams
        // (a past epoch ms). buildEventParameters honors it because additionalParams is
        // merged in last, so the wire `created` field already reflects the right time.
        // Use the same value here so EventPayload.timestamp (cache ordering) matches.
        val eventTimestamp = (additionalParams["created"] as? Long) ?: System.currentTimeMillis()

        val event = EventPayload(
            eventName = "status",
            timestamp = eventTimestamp,
            parameters = parameters
        )

        // Verification logging for campaign fields
        if (imageId != null) {
            logger.logDebug("📊 [Status Event] (sync) imageId=$imageId, campaignId=$campaignId, campaignName=$campaignName")
        }

        logger.logDebug("📊 [Status Event] (sync) statusType=${statusType.value}")

        // Use synchronous enqueue that waits for cache save
        enqueueEventSync(event)
    }

    private fun normalizeStatusParameters(
        statusType: StatusType,
        rawParameters: Map<String, Any?>,
        additionalParams: Map<String, Any>
    ): Map<String, Any?> {
        if (statusType != StatusType.SESSION_STARTED && statusType != StatusType.SESSION_STOPPED) {
            return rawParameters
        }

        val deviceInfo = if (config.autoDetectDeviceInfo) {
            deviceInfoDetector.detectDeviceInfo()
        } else {
            null
        }

        val normalized = rawParameters.toMutableMap()
        val fallbackNetwork = getDetectedNetworkType()
        normalized["sessionSource"] = (normalized["sessionSource"] as? String)
            ?.takeIf { it.isNotBlank() }
            ?: buildSessionSource("Android", config.companyName, config.bucketName)
        normalized["appSource"] = APP_SOURCE
        normalized["deviceType"] = (normalized["deviceType"] as? String)
            ?.takeIf { it.isNotBlank() }
            ?: deviceInfo?.deviceType
            ?: UserContext.DEVICE_TYPE_ANDROID
        normalized["deviceModel"] = (normalized["deviceModel"] as? String)
            ?.takeIf { it.isNotBlank() }
            ?: deviceInfo?.deviceModel
            ?: "unknown"
        normalized["osVersion"] = (normalized["osVersion"] as? String)
            ?.takeIf { it.isNotBlank() }
            ?: deviceInfo?.osVersion
            ?: "unknown"
        normalized["userAgent"] = (normalized["userAgent"] as? String)
            ?.takeIf { it.isNotBlank() }
            ?: deviceInfo?.userAgent
            ?: "unknown"
        normalized["network"] = (normalized["network"] as? String)
            ?.takeIf { it.isNotBlank() }
            ?: fallbackNetwork
        normalized["created"] = when (val createdValue = normalized["created"]) {
            is Number -> createdValue.toLong()
            is String -> {
                val trimmed = createdValue.trim()
                if (trimmed.isBlank()) {
                    System.currentTimeMillis()
                } else {
                    trimmed.toLongOrNull()
                        ?: runCatching { java.time.Instant.parse(trimmed).toEpochMilli() }.getOrNull()
                        ?: System.currentTimeMillis()
                }
            }
            else -> System.currentTimeMillis()
        }
        normalized["libraryVersion"] = (normalized["libraryVersion"] as? String)
            ?.takeIf { it.isNotBlank() }
            ?: userContext?.libraryVersion?.takeIf { it.isNotBlank() }
            ?: BuildConfig.ANALYTICS_LIBRARY_VERSION
        if (statusType == StatusType.SESSION_STARTED) {
            normalized["duration"] = 0L
        } else {
            normalized["duration"] = (additionalParams["duration"] as? Number)?.toLong()
                ?: (normalized["duration"] as? Number)?.toLong()
                ?: 0L
        }

        val allowedKeys = setOf(
            "statusType",
            "created",
            "sessionTrackingID",
            "userType",
            "userID",
            "duration",
            "sessionSource",
            "appSource",
            "deviceType",
            "deviceModel",
            "osVersion",
            "userAgent",
            "libraryVersion",
            "network",
            "locationLat",
            "locationLng",
            "locationLookup"
        )

        return normalized.filterKeys { key -> key in allowedKeys }
    }

    /**
     * Track user account created event.
     * This should be called immediately after a user account is successfully created.
     * All required fields per analytics spec are automatically included from userContext.
     */
    fun trackUserAccountCreated() {
        scope.launch {
            val currentContext = userContext
            if (currentContext == null) {
                logger.logError("Cannot track userAccountCreated: userContext is null")
                return@launch
            }
            
            // Build additional parameters with user-specific fields
            val additionalParams = mutableMapOf<String, Any>()
            
            // userName is required
            currentContext.username?.let { additionalParams["userName"] = it }
            
            // userProfileUrl is optional but include if available
            currentContext.userProfileUrl?.let { additionalParams["userProfileUrl"] = it }
            
            // All other required fields (userID, userType, sessionTrackingID, location, device info, etc.)
            // are automatically included via buildEventParameters() from userContext
            
            val parameters = buildEventParameters(
                eventName = "status",
                additionalParams = additionalParams + mapOf(
                    "statusType" to StatusType.USER_ACCOUNT_CREATED.value
                )
            )
            
            val event = EventPayload(
                eventName = "status",
                timestamp = System.currentTimeMillis(),
                parameters = parameters
            )
            
            // Send immediately (enqueue will handle sending)
            enqueueEvent(event)
            
            // Force immediate flush to send this critical event right away
            repository.flushEvents()
        }
    }
    
    /**
     * Generic event tracking
     */
    fun trackEvent(
        eventName: String,
        parameters: Map<String, Any> = emptyMap()
    ) {
        scope.launch {
            val eventParams = buildEventParameters(eventName, parameters)
            
            val event = EventPayload(
                eventName = eventName,
                timestamp = System.currentTimeMillis(),
                parameters = eventParams
            )
            
            enqueueEvent(event)
        }
    }
    
    /**
     * Timer management
     */
    suspend fun startViewTimer(viewType: ViewType) {
        val timerType = when (viewType) {
            ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
            ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
            ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
        }
        timerManager.startTimer(timerType)
    }
    
    suspend fun stopViewTimer(viewType: ViewType): Long {
        val timerType = when (viewType) {
            ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
            ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
            ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
        }
        return timerManager.stopTimer(timerType)
    }
    
    suspend fun getViewDuration(viewType: ViewType): Long {
        val timerType = when (viewType) {
            ViewType.COMPRESSED -> TimerManager.TimerType.COMPRESSED_VIEW
            ViewType.EXPANDED -> TimerManager.TimerType.EXPANDED_VIEW
            ViewType.FULL -> TimerManager.TimerType.FULL_VIEW
        }
        return timerManager.getDuration(timerType)
    }
    
    fun startScanMatchTimer() {
        scope.launch {
            timerManager.startTimer(TimerManager.TimerType.SCAN_MATCH)
        }
    }
    
    suspend fun stopScanMatchTimer(): Long {
        return timerManager.stopTimer(TimerManager.TimerType.SCAN_MATCH)
    }
    
    fun startSectionTimer(section: ViewSource) {
        scope.launch {
            val timerType = when (section) {
                ViewSource.HISTORY -> TimerManager.TimerType.SECTION_HISTORY
                ViewSource.SAVE -> TimerManager.TimerType.SECTION_SAVE
                ViewSource.MY_IRCODES -> TimerManager.TimerType.SECTION_MY_IRCODES
                ViewSource.TRASH -> TimerManager.TimerType.SECTION_TRASH
                ViewSource.PROFILE -> TimerManager.TimerType.SECTION_PROFILE
                else -> null
            }
            timerType?.let { timerManager.startTimer(it) }
        }
    }
    
    suspend fun stopSectionTimer(section: ViewSource): Long {
        val timerType = when (section) {
            ViewSource.HISTORY -> TimerManager.TimerType.SECTION_HISTORY
            ViewSource.SAVE -> TimerManager.TimerType.SECTION_SAVE
            ViewSource.MY_IRCODES -> TimerManager.TimerType.SECTION_MY_IRCODES
            ViewSource.TRASH -> TimerManager.TimerType.SECTION_TRASH
            ViewSource.PROFILE -> TimerManager.TimerType.SECTION_PROFILE
            else -> return 0L
        }
        return timerManager.stopTimer(timerType)
    }
    
    fun onAppBackgrounded() {
        scope.launch {
            timerManager.pauseAll()
            // Per spec §7, backgrounding is equivalent to "preview popup paused." Clear live-match
            // dedup so a re-foreground that recognizes the same image fires a fresh POST.
            // Critical for no-notification clients that have no UI dismiss handler.
            scanMatchDeduplicator.clear()
            viewCompressedDeduplicator.clear()
            firstCompressedTimeToDisplayTracker.clear()
        }
    }

    fun onAppForegrounded() {
        scope.launch {
            timerManager.resumeAll()
        }
    }

    fun onSessionStarted() {
        // Generate the session ID and update userContext SYNCHRONOUSLY so the
        // very next event the caller fires (e.g. trackStatusEvent SESSION_STARTED
        // in IRKitLens) reads the new ID instead of racing against a launch on
        // Dispatchers.IO. Side effects that don't gate event emission (IP cache
        // clear, timer start) stay async.
        val newId = SessionTrackingIdGenerator.generate()
        currentSessionTrackingId = newId
        userContext?.let { context ->
            userContext = context.copy(sessionTrackingId = newId)
        }
        logger.logDebug("🆔 [Session] New session started with ID: $newId")

        scope.launch {
            timerManager.startTimer(TimerManager.TimerType.GLOBAL_SESSION)
            // New session = fresh dedup state. The previous session's currentMatchedImageId
            // is meaningless once a new sessionTrackingID begins.
            scanMatchDeduplicator.clear()
            viewCompressedDeduplicator.clear()
            firstCompressedTimeToDisplayTracker.clear()
        }
    }

    suspend fun onSessionStopped(): Long {
        // Bound dedup state to the session lifetime: once a session ends, any subsequent
        // session must be free to POST the same imageID as a fresh match.
        scanMatchDeduplicator.clear()
        viewCompressedDeduplicator.clear()
        firstCompressedTimeToDisplayTracker.clear()
        return timerManager.stopTimer(TimerManager.TimerType.GLOBAL_SESSION)
    }
    
    /**
     * Get global session duration without stopping the timer
     */
    suspend fun getGlobalSessionDuration(): Long {
        return timerManager.getDuration(TimerManager.TimerType.GLOBAL_SESSION)
    }
    
    /**
     * Get current session tracking ID for lifecycle tracking.
     * Returns the current session ID or generates a new one if not set.
     * This is used by LifecycleTracker to preserve the session ID when saving pending session end.
     */
    fun getCurrentSessionTrackingId(): String {
        return currentSessionTrackingId ?: SessionTrackingIdGenerator.generate()
    }

    /**
     * Peek the currently-active session tracking ID without minting a new one.
     *
     * Used by the Live+ frame-capture path to snapshot which session the user's
     * action belongs to *at the moment they act*, so the resulting scan event
     * can be attributed correctly even if the async match completes after
     * `sessionStopped`. Returns `null` when no session is active — callers
     * should fall back to emit-time stamping in that case.
     */
    fun peekCurrentSessionTrackingId(): String? {
        return currentSessionTrackingId?.takeIf { it.isNotEmpty() }
    }

    /**
     * Get the analytics bucket name currently in use.
     */
    fun getBucketName(): String = config.bucketName

    /**
     * Update the analytics bucket name. IRKitUI calls this once /lenses
     * resolves at lens-open, since the real bucket (lens primaryCollection)
     * isn't known when the SDK initializes. Subsequent /Statistics POSTs and
     * sessionSource derivations pick up the new value.
     *
     * On the FIRST call with a real (non-blank, non-placeholder) value, this
     * also flushes the pre-bucket-resolution event buffer: each held event's
     * `bucketName` and `sessionSource` are rewritten to the correct values
     * before being enqueued for upload. This guarantees 100% of /Statistics
     * POSTs ship with correct bucket / sessionSource — including events like
     * `sessionStarted` that are fired *before* /lenses returns.
     */
    fun setBucketName(bucketName: String) {
        if (bucketName.isBlank() || bucketName == config.bucketName) return
        config.bucketName = bucketName

        // Persist the resolved bucket so the NEXT app launch can skip the
        // buffer entirely (see init{} above). Keyed by companyName so a dev
        // who switches -PirkitClient between runs does not poison the cache.
        userPreferences.saveCachedBucketName(config.companyName, bucketName)

        // Atomic flip + snapshot under the buffer's lock. Concurrency contract:
        //   - If a tracker thread hits enqueueEvent BEFORE this block runs,
        //     it sees `bucketResolved == false` *under the lock*, adds to
        //     the buffer, and is then drained here — same lock guarantees
        //     it lands in the snapshot.
        //   - If a tracker thread hits enqueueEvent AFTER this block runs,
        //     it sees `bucketResolved == true` *under the lock* and routes
        //     directly to the repository.
        //   - There is NO interval where a tracker could check
        //     `bucketResolved == false` then add to a buffer that has just
        //     been drained — the lock serializes the decision and the action.
        val resolvedBucket = bucketName
        val resolvedSessionSource =
            buildSessionSource("Android", config.companyName, resolvedBucket)
        val held: List<EventPayload> = synchronized(pendingPreBucketEvents) {
            if (!bucketResolved.compareAndSet(false, true)) {
                // Already resolved by an earlier setBucketName call. Subsequent
                // setBucketName invocations are bucket UPDATES (rare; only if
                // /lenses returns a different value next session). They mutate
                // config.bucketName above, persist to UserPreferences, but
                // have nothing to drain — every tracker since the first
                // resolution went straight to the repository.
                emptyList()
            } else {
                val snapshot = pendingPreBucketEvents.toList()
                pendingPreBucketEvents.clear()
                snapshot
            }
        }
        if (held.isNotEmpty()) {
            logger.logDebug(
                "🔄 Bucket resolved → '$resolvedBucket'. Rewriting and flushing " +
                    "${held.size} buffered event(s)."
            )
            for (event in held) {
                repository.enqueueEvent(
                    rebrandEventBucket(event, resolvedBucket, resolvedSessionSource)
                )
            }
        }
    }

    /**
     * Internal: enqueue an event, OR hold it in memory until [setBucketName]
     * resolves the real bucket from /lenses. All [trackXxxEvent] methods
     * route through this helper so no code path can ship pre-resolution
     * placeholder values to the server.
     *
     * On returning users (any launch after the first successful /lenses), the
     * cached bucket loaded in init{} flips [bucketResolved] to true before any
     * tracker runs — events go straight to the repository and the buffer never
     * sees them.
     *
     * Concurrency: the [bucketResolved] read AND the buffer add are inside
     * the same synchronized block as [setBucketName]'s flip + drain. This
     * removes the orphan-event race where a thread could check
     * `bucketResolved == false`, get preempted, and have its event added to a
     * just-drained buffer. The repository call itself happens outside the lock
     * to avoid holding it across asynchronous downstream work.
     */
    private fun enqueueEvent(event: EventPayload) {
        val routedToBuffer = synchronized(pendingPreBucketEvents) {
            if (bucketResolved.get()) {
                false  // route to repository — outside the lock
            } else {
                if (pendingPreBucketEvents.size >= MAX_PENDING_PRE_BUCKET_EVENTS) {
                    logger.logDebug(
                        "⚠️  Pre-bucket buffer full ($MAX_PENDING_PRE_BUCKET_EVENTS). " +
                            "Dropping event '${event.eventName}'. /lenses may have stalled."
                    )
                    return  // dropped; non-local exit from enqueueEvent
                }
                pendingPreBucketEvents.add(event)
                true
            }
        }
        if (routedToBuffer) {
            // Mirror AnalyticsRepository's per-event log lines so buffered
            // events still appear in logcat at tracking time (not just at
            // flush time). Logger calls are intentionally outside the lock —
            // they don't influence the buffer's race-free invariants.
            logger.logEvent(event.eventName, event.parameters)
            logger.logEventOneLine(event.eventName, event.parameters)
            logger.logDebug(
                "⏸  Holding event '${event.eventName}' until bucket resolves " +
                    "(buffer size: ${pendingPreBucketEvents.size})"
            )
        } else {
            repository.enqueueEvent(event)
        }
    }

    /**
     * Internal: synchronous variant of [enqueueEvent]. Used by the few
     * trackers that must persist their event before app termination
     * (button presses on the way out, etc.).
     *
     * Pre-resolution sync semantics analysis: the contract these callers care
     * about ("persisted to disk before this returns") is intentionally
     * weakened for the narrow first-ever-launch window. The cached-bucket
     * fast path in init{} means returning users hit [bucketResolved.get() ==
     * true] from event #1, so this is a non-issue in practice.
     *
     * Even on first-ever launch, the only sync caller that could plausibly
     * fire pre-resolution is [trackStatusEventSync] for SESSION_STOPPED on a
     * very fast lens close — and that is gated by SESSION_STARTED having
     * fired first, which itself is gated by lens composition. In normal use
     * the sync trackers never see the pre-resolution window.
     *
     * Concurrency: same atomic-decide-then-act pattern as [enqueueEvent].
     */
    private suspend fun enqueueEventSync(event: EventPayload) {
        val routedToBuffer = synchronized(pendingPreBucketEvents) {
            if (bucketResolved.get()) {
                false
            } else {
                if (pendingPreBucketEvents.size >= MAX_PENDING_PRE_BUCKET_EVENTS) {
                    logger.logDebug(
                        "⚠️  Pre-bucket buffer full ($MAX_PENDING_PRE_BUCKET_EVENTS). " +
                            "Dropping event '${event.eventName}' (sync). /lenses may have stalled."
                    )
                    return  // dropped; non-local exit from enqueueEventSync
                }
                pendingPreBucketEvents.add(event)
                true
            }
        }
        if (routedToBuffer) {
            logger.logEvent(event.eventName, event.parameters)
            logger.logEventOneLine(event.eventName, event.parameters)
            logger.logDebug(
                "⏸  Holding event '${event.eventName}' (sync) until bucket resolves " +
                    "(buffer size: ${pendingPreBucketEvents.size})"
            )
        } else {
            repository.enqueueEventSync(event)
        }
    }

    /**
     * Get the analytics session source currently in use.
     */
    fun getSessionSource(): String = buildSessionSource("Android", config.companyName, config.bucketName)
    
    /**
     * Flush pending events
     */
    suspend fun flush() {
        repository.flushEvents()
    }

    /**
     * Synchronously flush pending events with a timeout.
     * Use for critical exit paths where we need to ensure events are sent before app termination.
     *
     * The timeout bounds the caller's WAIT, not the underlying work: on timeout the
     * launched flush continues in the background and completes its cache-update
     * sequence (so events never end up stranded), while the caller is unblocked
     * after exactly `timeoutMs`. This protects callers wrapped in `runBlocking` on
     * the main thread (lifecycle handlers, Compose dispose) from blocking longer
     * than the configured timeout when the network is slow.
     *
     * @param timeoutMs Maximum time to wait for flush to complete (default 2000ms)
     * @return true if flush completed within timeout, false if timed out
     */
    suspend fun flushSync(timeoutMs: Long = 2000L): Boolean {
        logger.logDebug("🔄 [Flush] Starting synchronous flush with ${timeoutMs}ms timeout")

        // Launch the flush in our own scope so the caller's timeout bounds the WAIT,
        // not the WORK. flushEvents() uses withContext(NonCancellable) internally, so
        // the mark→POST→record state machine always runs to completion — even if the
        // launched job is later cancelled (e.g. via scope.cancel() during shutdown()).
        val flushJob = scope.launch { repository.flushEvents() }

        val completed = withTimeoutOrNull(timeoutMs) {
            flushJob.join()
            true
        } == true

        // Deliberately do NOT cancel flushJob on timeout — it continues running in the
        // background and finishes its cache-update sequence. The caller is hard-bounded
        // at timeoutMs, which is the contract the doc above advertises.
        if (completed) {
            logger.logDebug("✅ [Flush] Synchronous flush completed within ${timeoutMs}ms")
        } else {
            logger.logDebug("⏰ [Flush] Synchronous flush timed out after ${timeoutMs}ms (flush continues in background)")
        }
        return completed
    }

    /**
     * Pause all timers synchronously.
     * Use for critical exit paths where we need to ensure timers are paused before app termination.
     */
    suspend fun onAppBackgroundedSync() {
        timerManager.pauseAll()
    }

    /**
     * Cache inspection (dev mode)
     */
    suspend fun getCachedEvents(): List<EventPayload> {
        return cache.loadEvents()
    }
    
    suspend fun getCacheStats(): CacheStats {
        return repository.getCacheStats()
    }
    
    suspend fun clearCache() {
        cache.clearAll()
    }
    
    /**
     * Clear a specific imageID from the scan match deduplication state.
     * Call when the preview popup is dismissed so the next recognition of the same
     * imageID is admitted as a fresh match. The new "while-displayed" deduplicator
     * tracks only one current image at a time, so any dismiss clears the field.
     *
     * @param imageId The imageID being dismissed (used for logging only)
     */
    fun clearScanMatchDeduplication(imageId: String) {
        scope.launch {
            scanMatchDeduplicator.clear()
            logger.logDebug("Cleared scan match deduplication (popup dismissed for imageID: $imageId)")
        }
    }

    /**
     * Clear all scan match deduplication state.
     * Useful for testing or when resetting the analytics state.
     */
    fun clearAllScanMatchDeduplication() {
        scope.launch {
            scanMatchDeduplicator.clear()
            logger.logDebug("Cleared all scan match deduplication state")
        }
    }

    /**
     * Hook for the lens / preview popup lifecycle. Call when the preview popup is dismissed
     * (X press, expand-to-full transition, or any other dismiss path) so the same imageID
     * can be admitted again as a fresh match on the next recognition. This is the single
     * entry point the lens UI should call.
     */
    fun onMatchPopupDismissed() {
        scope.launch {
            scanMatchDeduplicator.clear()
            // Also clear the view/compressed consecutive-dedup so re-recognition of the same
            // imageID (after this dismiss) emits a fresh eventType=view POST. Without this,
            // the second compressed view would be silently swallowed by the consecutive guard
            // in trackViewEvent — symptom: "scanned the same image again, no view event."
            viewCompressedDeduplicator.clear()
            logger.logDebug("📊 [Scan Event] Match popup dismissed — dedup state cleared, next match will be admitted")
        }
    }
    
    /**
     * Snapshot the network / location fields that the next analytics event
     * would carry. Matches exactly what `buildEventParameters()` will write
     * into the payload for `network`, `locationLat`, and `locationLng`. The
     * `deviceLocalIp` is not sent — it's included so a debug UI can show the
     * phone's own IP. The public IP is no longer fetched or sent: the server
     * derives it from each /Statistics request's source IP.
     *
     * `locationLat` / `locationLng` may be `null` if location permission is
     * denied, a fix hasn't landed yet, or we're on an emulator with no mock
     * location.
     */
    suspend fun getAnalyticsDebugInfo(): AnalyticsDebugInfo {
        val location = locationProvider.getCurrentLocation()
        return AnalyticsDebugInfo(
            networkType = getDetectedNetworkType(),
            deviceLocalIp = getDeviceLocalIp(),
            locationLat = location?.latitude,
            locationLng = location?.longitude,
            locationUnavailableReason = locationProvider.locationUnavailableReason(),
        )
    }

    /**
     * Enumerate local network interfaces and return the first non-loopback
     * IPv4 address we can find. Used for debug surfaces only — never sent
     * to analytics, because private IPs (10.x, 192.168.x) cause the backend
     * to geolocate to garbage.
     */
    private fun getDeviceLocalIp(): String? {
        return try {
            val interfaces = java.net.NetworkInterface.getNetworkInterfaces() ?: return null
            for (netIf in interfaces) {
                if (!netIf.isUp || netIf.isLoopback) continue
                for (addr in netIf.inetAddresses) {
                    if (!addr.isLoopbackAddress && addr is java.net.Inet4Address) {
                        return addr.hostAddress
                    }
                }
            }
            null
        } catch (_: Exception) {
            null
        }
    }
    
    /**
     * Build event parameters with user context and common fields.
     * Automatically fetches location if permissions are available.
     */
    private suspend fun buildEventParameters(
        eventName: String,
        additionalParams: Map<String, Any>
    ): Map<String, Any?> {
        val params = mutableMapOf<String, Any?>()

        // bucketName: stamp ONLY when the caller supplied a per-asset value via
        // additionalParams["bucketName"] (sourced from the /lookup response on
        // the matched asset). No lens-primary default — sending config.bucketName
        // for events whose asset bucket is unknown is the misattribution we are
        // eliminating (§2.2 / §2.5 of analytics_doc_updates.md). Status events
        // never carry an asset and therefore never set this field.
        params["sessionSource"] = buildSessionSource("Android", config.companyName, config.bucketName)
        params["created"] = System.currentTimeMillis()

        // CRITICAL: userID is REQUIRED for all events per analytics spec
        // For anonymous users (no Firebase), this is a persistent UUIDv7
        // Fall back to anonymous UUID if userContext hasn't been set yet (race condition
        // where lifecycle events fire before setUserContext is called)
        params["userID"] = userContext?.userId?.let { userId ->
            UuidV7Canonicalizer.canonicalizeOrNull(userId) ?: userId
        } ?: userPreferences.getOrCreateAnonymousUserId()

        // Automatically fetch location if permissions are available
        // This happens transparently - client apps don't need to provide location
        val location = locationProvider.getCurrentLocation()
        val autoLocationLat = location?.latitude   // latitude -> locationLat (do not swap with longitude)
        val autoLocationLng = location?.longitude   // longitude -> locationLng (do not swap with latitude)

        // locationIP is intentionally NOT set here. The /Statistics backend now
        // derives the user's public IP from each request's source IP, so a
        // client-side /myip round-trip is redundant. UserContext.locationIp is
        // kept for API source-compat but is no longer forwarded.

        // CRITICAL: sessionTrackingID is REQUIRED per analytics spec (line 81)
        // Must be UUIDv7. Use currentSessionTrackingId (generated in onSessionStarted()),
        // fall back to userContext if available, or generate new one as safety net
        // IMPORTANT: Allow override from additionalParams for deferred session-ended events
        // This ensures the session-ended event uses the original session ID, not the new one
        val sessionTrackingId = (additionalParams["sessionTrackingID"] as? String)
            ?: currentSessionTrackingId?.takeIf { it.isNotEmpty() }
            ?: userContext?.sessionTrackingId?.takeIf { it.isNotEmpty() }
            ?: SessionTrackingIdGenerator.generate()
        params["sessionTrackingID"] = UuidV7Canonicalizer.canonicalizeOrNull(sessionTrackingId) ?: sessionTrackingId
        
        // Add user context
        // CRITICAL: userType is REQUIRED per analytics spec (line 83)
        // Must be one of: "anonymous", "basic", "pro", "enterprise", "creator"
        // Default to "anonymous" if not provided
        val userType = userContext?.userType?.takeIf { it.isNotEmpty() } ?: "anonymous"
        params["userType"] = userType
        
        userContext?.let { context ->
            context.username?.let { params["username"] = it }
            context.userProfileUrl?.let { params["profileUrl"] = it }
            
            // Location - use auto-detected location if not provided in UserContext
            // Priority: UserContext location > Auto-detected location
            val finalLocationLat = context.locationLat ?: autoLocationLat
            val finalLocationLng = context.locationLng ?: autoLocationLng
            finalLocationLat?.let { params["locationLat"] = it }  // latitude only
            finalLocationLng?.let { params["locationLng"] = it }  // longitude only
            
            // Location lookup: Currently not geocoding - passing null
            // Geocoding code is kept in place for future use (getSessionLocationLookup method)
            // If locationLookup is provided in UserContext, use it; otherwise pass null
            context.locationLookup?.let { params["locationLookup"] = it }
            // Note: Auto-geocoding disabled - uncomment below to enable:
            // else if (finalLocationLat != null && finalLocationLng != null) {
            //     val locationLookup = getSessionLocationLookup(finalLocationLat, finalLocationLng)
            //     locationLookup?.let { params["locationLookup"] = it }
            // }
            
            // Device info (v2.0: removed deviceManufacturer, deviceCarrier, deviceIFA, cookies)
            params["deviceModel"] = context.deviceModel
            params["deviceType"] = context.deviceType
            params["osVersion"] = context.osVersion
            context.userAgent?.let { params["userAgent"] = it }
            context.appVersion?.let { params["appVersion"] = it }
            params["appSource"] = APP_SOURCE
            context.libraryVersion?.let { params["libraryVersion"] = it }
            context.networkType?.let { params["network"] = it.value }
        }
        
        // If no userContext but we have auto-detected location, include it
        if (userContext == null) {
            // Include auto-detected location
            if (autoLocationLat != null || autoLocationLng != null) {
                autoLocationLat?.let { params["locationLat"] = it }  // latitude only
                autoLocationLng?.let { params["locationLng"] = it }   // longitude only
                
                // Location lookup: Currently not geocoding - passing null
                // Geocoding code is kept in place for future use (getSessionLocationLookup method)
                // Note: Auto-geocoding disabled - uncomment below to enable:
                // if (autoLocationLat != null && autoLocationLng != null) {
                //     val locationLookup = getSessionLocationLookup(autoLocationLat, autoLocationLng)
                //     locationLookup?.let { params["locationLookup"] = it }
                // }
            }
        }
        
        // If network was not set from userContext, detect it now
        if (!params.containsKey("network")) {
            params["network"] = getDetectedNetworkType()
        }
        
        // Add additional parameters (override common ones if needed)
        additionalParams.forEach { (key, value) ->
            val normalizedValue = if (
                (key == "scanTrackingID" || key == "sessionTrackingID" || key == "userID") &&
                    value is String
            ) {
                UuidV7Canonicalizer.canonicalizeOrNull(value) ?: value
            } else {
                value
            }
            params[key] = normalizedValue
        }
        
        // CRITICAL: Ensure network parameter is always a simple string enum value, never a JSON object
        // Per analytics_doc.md line 119: network must be one of: offline, wifi, cellular2g, 3g, 4g, 5g, ethernet, unknown
        // SessionStart and SessionEnd should both send just the active network name (e.g., "wifi"), not an object
        val networkValue = params["network"]
        params["network"] = when {
            networkValue is String -> {
                // Already a string - validate it's a valid enum value, otherwise detect actual network
                val validValues = setOf("offline", "wifi", "cellular2g", "3g", "4g", "5g", "ethernet", "unknown")
                if (networkValue.lowercase() in validValues) {
                    networkValue.lowercase()
                } else {
                    // Invalid string value - detect actual network type
                    getDetectedNetworkType()
                }
            }
            networkValue is NetworkType -> networkValue.value // Convert enum to string value
            networkValue is Map<*, *> -> {
                // If network is a Map/JSON object (e.g., {"bluetooth":false,"wifi":true,"cellular":false}),
                // extract the active network name or detect actual network type
                // Try to extract active network from map, otherwise detect it
                val map = networkValue as Map<*, *>
                when {
                    map["wifi"] == true -> "wifi"
                    map["cellular"] == true -> getDetectedNetworkType() // Detect cellular generation
                    map["bluetooth"] == true -> "unknown" // Bluetooth is not a valid network type
                    else -> getDetectedNetworkType() // Fallback to actual detection
                }
            }
            else -> {
                // If network is any other invalid type, detect actual network type
                // Also use detected network if network was not set at all
                getDetectedNetworkType()
            }
        }

        // libraryVersion is required on all /Statistics events.
        // Keep caller/userContext value when present, otherwise use the analytics module's
        // existing source-of-truth fallback used by status normalization.
        params["libraryVersion"] = (params["libraryVersion"] as? String)
            ?.takeIf { it.isNotBlank() }
            ?: userContext?.libraryVersion?.takeIf { it.isNotBlank() }
            ?: BuildConfig.ANALYTICS_LIBRARY_VERSION
        
        // Log location fields at INFO so it shows even when Debug is filtered (tag: analytics_payload).
        // locationIP is no longer sent — backend derives it from /Statistics source IP.
        Log.i(
            "analytics_payload",
            "Event params built: locationLat=${params["locationLat"]} (body), locationLng=${params["locationLng"]} (body)"
        )
        return params
    }
    
    /**
     * Detect current network type and return as string enum value.
     * Per analytics_doc.md: network must be one of: offline, wifi, cellular2g, 3g, 4g, 5g, ethernet, unknown
     */
    private fun getDetectedNetworkType(): String {
        return if (config.autoDetectDeviceInfo) {
            deviceInfoDetector.detectDeviceInfo().networkType.value
        } else {
            // Fallback to unknown if auto-detection is disabled
            NetworkType.UNKNOWN.value
        }
    }
    
    /**
     * Construct imageUrlOfScan from trackingId and bucketName.
     *
     * The imageUrlOfScan is the URL of the image submitted by the user to make the match.
     * This URL points to the query image stored on the IR Engine backend.
     *
     * @param trackingId The tracking ID from the image search result
     * @param bucketName The bucket name (defaults to config bucketName if not provided)
     * @return The URL for the scanned image, or empty string if trackingId is empty
     */
    fun getQueryImageUrlForTrackingId(trackingId: String, bucketName: String? = null): String {
        val trimmed = trackingId.trim()
        if (trimmed.isEmpty()) return ""
        val bucket = bucketName?.ifEmpty { config.bucketName } ?: config.bucketName
        val baseUrl = config.irEngineBaseUrl.trimEnd('/')
        return "$baseUrl/queries/$bucket/$trimmed/image"
    }

    @Volatile private var shutDown = false

    /**
     * Tear down the analytics client. Idempotent. Stops the fused-location
     * stream, the network-transport monitor, the auto-flush loop, and cancels
     * the client's IO scope. Call from the host application's process-level
     * shutdown path (e.g. a dedicated teardown hook) when analytics must
     * release its long-running subscribers.
     *
     * After calling this, the singleton is cleared; a fresh
     * [AnalyticsClient.initialize] is required before further use.
     */
    fun shutdown() {
        if (shutDown) return
        shutDown = true
        try { locationProvider.stopUpdates() } catch (e: Exception) {
            logger.logError("shutdown: stopUpdates failed: ${e.message}", e)
        }
        try { networkMonitor.stop() } catch (e: Exception) {
            logger.logError("shutdown: networkMonitor.stop failed: ${e.message}", e)
        }
        try { repository.shutdown() } catch (e: Exception) {
            logger.logError("shutdown: repository.shutdown failed: ${e.message}", e)
        }
        try { scope.cancel() } catch (_: Exception) { /* already cancelled */ }
        synchronized(AnalyticsClient) {
            if (instance === this) instance = null
        }
    }

    private suspend fun consumeTimeToDisplayForView(
        viewType: ViewType,
        scanTrackingId: String?,
        timeToDisplay: Long?
    ): Long? {
        return firstCompressedTimeToDisplayTracker.consumeForView(
            viewType = viewType,
            scanTrackingId = scanTrackingId,
            timeToDisplay = timeToDisplay
        )
    }

    companion object {
        /** Value for the required `appSource` field on `sessionStarted` events. */
        const val APP_SOURCE = "app"

        /**
         * Cap on the in-memory pre-bucket-resolution event buffer. Beyond
         * this, events are dropped with a logger warning. 200 ≈ 4× headroom
         * over a typical lens session's peak event count and is only ever
         * approached on the rare first-ever-launch-with-offline-backend
         * path; returning users skip the buffer entirely via the cached
         * bucket loaded in [AnalyticsClient.init].
         */
        private const val MAX_PENDING_PRE_BUCKET_EVENTS = 200

        @Volatile
        private var instance: AnalyticsClient? = null

        @JvmStatic
        fun getInstance(): AnalyticsClient {
            return instance ?: throw IllegalStateException(
                "AnalyticsClient not initialized. Call AnalyticsClient.initialize() first."
            )
        }

        fun initialize(context: Context, config: AnalyticsConfig) {
            if (instance == null) {
                synchronized(this) {
                    if (instance == null) {
                        instance = AnalyticsClient(config, context.applicationContext)
                    }
                }
            }
        }
    }
}

internal class FirstCompressedTimeToDisplayTracker {
    private val emittedTrackingIds = mutableSetOf<String>()
    private val mutex = Mutex()

    suspend fun consumeForView(
        viewType: ViewType,
        scanTrackingId: String?,
        timeToDisplay: Long?
    ): Long? = mutex.withLock {
        if (viewType != ViewType.COMPRESSED) return@withLock null
        if (scanTrackingId.isNullOrBlank()) return@withLock null
        if (timeToDisplay == null) return@withLock null
        if (!emittedTrackingIds.add(scanTrackingId)) return@withLock null
        return@withLock if (timeToDisplay <= 0L) 1L else timeToDisplay
    }

    suspend fun clear() = mutex.withLock {
        emittedTrackingIds.clear()
    }
}

private fun extractScanTrackingId(
    additionalParams: Map<String, Any>,
    fallbackTrackingId: String? = null
): String? {
    val explicitTrackingId = additionalParams["scanTrackingID"] as? String
    return when {
        !explicitTrackingId.isNullOrBlank() -> explicitTrackingId
        !fallbackTrackingId.isNullOrBlank() -> fallbackTrackingId
        else -> null
    }
}

