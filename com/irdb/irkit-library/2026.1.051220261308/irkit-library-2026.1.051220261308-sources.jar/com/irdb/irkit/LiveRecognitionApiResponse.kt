package com.irdb.irkit.models

import com.google.gson.annotations.SerializedName

// Data classes equivalent to Swift structs
data class LiveRecognitionApiResponse(
    // val content: String,
    // val image: ImageInfo,
    // val similarity: Double,
    @SerializedName("entry")
    val entry: String? = null,
    // val match: List<List<Double>>,

    @SerializedName("similarity")
    val similarity: Double? = null,

    @SerializedName("match")
    val match: List<List<Double>>? = null,

    @SerializedName("clip")
    val clip: ClipInfo? = null,

    @SerializedName("context")
    val context: String? = null,

    @SerializedName("asset")
    val asset: String? = null,
)

data class ImageInfo(
    @SerializedName("width")
    val width: Int,

    @SerializedName("height")
    val height: Int,

    @SerializedName("url")
    val url: String
)

data class ClipInfo(
    @SerializedName("time")
    val time: TimeRange? = null
)

data class TimeRange(
    @SerializedName("min")
    val min: Double? = null,

    @SerializedName("max")
    val max: Double? = null
)
