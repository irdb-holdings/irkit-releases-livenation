package com.irdb.irkitui.ui.components

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.Layout
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.irdb.irkit.ImageModel
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.enums.IRKitResourceProvider
import com.irdb.irkit.extensions.extractDomain
import com.irdb.irkitui.ui.baseComponents.ResultCardCallToActionButtonV2

/**
 * Generic ContentMetaLinksView that accepts a resource provider function
 * to handle icon mapping for different consuming applications
 *
 * Uses a simple wrapping layout: short buttons sit side by side,
 * long buttons wrap to the next line.
 */
@Composable
fun ContentMetaLinksView(
    image: ImageModel,
    onClick: (MetaContent.Link) -> Unit,
    resourceProvider: IRKitResourceProvider? = null,
    modifier: Modifier = Modifier,
    links: List<MetaContent.Link>? = null
) {
    // If explicit links provided, use them; otherwise fall back to all links from meta
    val displayLinks = links
        ?: image.metaItems.find { it.metaType == "Link" }
            ?.contentArray?.filterIsInstance<MetaContent.Link>()

    if (displayLinks.isNullOrEmpty()) return

    WrappingRow(
        modifier = modifier.padding(vertical = 4.dp, horizontal = 4.dp),
        horizontalSpacing = 10.dp,
        verticalSpacing = 10.dp
    ) {
        displayLinks.forEach { link ->
            val title = link.title
            val url = link.url

            val iconResIdRaw = resourceProvider?.let { provider ->
                link.getIconResId(provider)
            }

            val iconResId = if (iconResIdRaw == 0) null else iconResIdRaw
            // Use resolved icon if available, otherwise fall back to globe
            val hasResolvedIcon = iconResId != null && !link.useDefaultIcon()

            ResultCardCallToActionButtonV2(
                text = title.ifEmpty { url.extractDomain() },
                linkIcon = if (hasResolvedIcon) iconResId else null,
                iconVector = if (!hasResolvedIcon) Icons.Default.Language else null,
                onClick = { onClick(link) },
                showIcon = hasResolvedIcon
            )
        }
    }
}

/**
 * A simple wrapping row layout. Children are placed left-to-right and wrap
 * to the next line when they don't fit. No experimental APIs required.
 */
@Composable
private fun WrappingRow(
    modifier: Modifier = Modifier,
    horizontalSpacing: Dp = 0.dp,
    verticalSpacing: Dp = 0.dp,
    content: @Composable () -> Unit
) {
    Layout(
        content = content,
        modifier = modifier
    ) { measurables, constraints ->
        val hSpacingPx = horizontalSpacing.roundToPx()
        val vSpacingPx = verticalSpacing.roundToPx()

        val placeables = measurables.map { it.measure(constraints.copy(minWidth = 0)) }

        val positions = mutableListOf<Pair<Int, Int>>()
        var rowWidth = 0
        var rowHeight = 0
        var totalHeight = 0

        placeables.forEach { placeable ->
            if (rowWidth > 0 && rowWidth + hSpacingPx + placeable.width > constraints.maxWidth) {
                // Wrap to next row
                totalHeight += rowHeight + vSpacingPx
                rowWidth = 0
                rowHeight = 0
            }
            positions.add(rowWidth to totalHeight)
            rowWidth += placeable.width + hSpacingPx
            rowHeight = maxOf(rowHeight, placeable.height)
        }
        totalHeight += rowHeight

        layout(constraints.maxWidth, totalHeight) {
            placeables.forEachIndexed { index, placeable ->
                val (x, y) = positions[index]
                placeable.placeRelative(x, y)
            }
        }
    }
}
