package com.irdb.irkitui

/**
 * BASELINE camera modes for IRKit-UI.
 * Includes Live, Snapshot, and Creator modes for compatibility with main app.
 */
enum class CameraMode {
    /**
     * Live mode: Continuous recognition at 3 frames per second
     */
    LIVE,

    /**
     * Snapshot mode: Manual capture and recognition
     */
    SNAPSHOT,

    /**
     * Creator mode: Content creation mode
     */
    CREATOR;

    /**
     * Display name for UI components
     */
    val displayName: String
        get() = when (this) {
            LIVE -> "LIVE+"
            SNAPSHOT -> "SNAPSHOT"
            CREATOR -> "CREATOR"
        }
}
