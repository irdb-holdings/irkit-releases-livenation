package com.irdb.irkit

fun IREngine.uploadImageForIRCode(image: ImageModel) {
}
