package com.irdb.irkit.response

import com.google.gson.annotations.SerializedName

data class DeleteIRCodeResponse(
    @SerializedName("ImageRemoved")
    val imageRemoved: Boolean
)

//{
//    "Completed": true,
//    "Time": "2025-8-7 10:56:44.617",
//    "TimeUsed": 492,
//    "GCRLog": "development-v1-43-4247193631-116158",
//    "NextOffset": 0,
//    "Total": 0,
//    "Count": 0,
//    "Pages": 0,
//    "Environment": "DEV",
//    "GCFVersion": "development-v1-43-00858-kih",
//    "Results": {
//    "ImageRemoved": true
//}
//}

data class RestoreIRCodeResponse(
    @SerializedName("ImageRestored")
    val imageRestored: Boolean
)
