package com.irdb.irkitui.ui.baseComponents

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.irdb.irkitui.theme.IRKitThemeAccessor

@Composable
fun FormLabel(
    text: String,
    modifier: Modifier = Modifier,
    color: Color? = null, // null means use theme color
    bottomPadding: Int = 8
) {
    val colors = IRKitThemeAccessor.colors
    val typography = IRKitThemeAccessor.typography

    Text(
        text = text,
        color = color ?: colors.textSecondary,
        style = typography.bodySmall,
        modifier = modifier.padding(bottom = bottomPadding.dp)
    )
}
