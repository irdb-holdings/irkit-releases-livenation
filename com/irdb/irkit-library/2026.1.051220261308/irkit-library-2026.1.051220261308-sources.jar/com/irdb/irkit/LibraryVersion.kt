package com.irdb.irkit

/**
 * IRKit Library version information.
 * Version format: MainRelease.PointRelease (e.g., "2026.1")
 * 
 * - MainRelease: Year of major release
 * - PointRelease: Incremental release number within the year
 * 
 * This information is automatically included in all analytics events.
 */
object LibraryVersion {
    /**
     * Full library version (e.g., "2026.1")
     */
    val version: String = BuildConfig.LIBRARY_VERSION
    
    /**
     * Main release version (e.g., "2026")
     */
    val mainRelease: String = BuildConfig.LIBRARY_MAIN_RELEASE
    
    /**
     * Point release version (e.g., "1")
     */
    val pointRelease: String = BuildConfig.LIBRARY_POINT_RELEASE
    
    /**
     * Get version information as a map for analytics
     */
    fun toMap(): Map<String, String> = mapOf(
        "libraryVersion" to version,
        "libraryMainRelease" to mainRelease,
        "libraryPointRelease" to pointRelease
    )
    
    override fun toString(): String = version
}

