package com.irdb.irkit.shared

import com.irdb.irkit.ImageModel
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.getMetaContent
import com.irdb.irkit.getTags

data class ImageModelShared(
    val imageID: String,
    val previewTitle: String,
    val previewSubTitle: String,
    val tags: List<String>,
    val products: List<ProductLinkShared>,
    val displayUrl: String?,
    val title: String?,
    val subtitle: String?,
    val imageDescription: String?,
    val category: String?,
    val artistName: String?,
    val firstName: String?,
    val lastName: String?,
    val company: String?,
    val jobTitle: String?,
    val email: String?,
    val phone: String?,
    val address: String?,
    val campaignID: Int,
    val campaignName: String,
)

fun ImageModel.toShared(): ImageModelShared {
    val metaTitle = getMetaContent<MetaContent.Title>("Title")?.value

    return ImageModelShared(
        imageID = imageId,
        previewTitle = metaTitle?.takeIf { it.isNotBlank() }
            ?: line1.takeIf { it.isNotBlank() }
            ?: imageId,
        previewSubTitle = line2,
        tags = getTags(),
        products = products.map { it.toShared() },
        displayUrl = displayImageUrl.takeIf { it.isNotBlank() },
        title = metaTitle?.takeIf { it.isNotBlank() },
        subtitle = null,
        imageDescription = description.takeIf { it.isNotBlank() },
        category = null,
        artistName = getMetaContent<MetaContent.ArtistName>("ArtistName")?.artistName?.takeIf { it.isNotBlank() },
        firstName = getMetaContent<MetaContent.FirstName>("FirstName")?.firstName?.takeIf { it.isNotBlank() },
        lastName = getMetaContent<MetaContent.LastName>("LastName")?.lastName?.takeIf { it.isNotBlank() },
        company = getMetaContent<MetaContent.Company>("Company")?.company?.takeIf { it.isNotBlank() },
        jobTitle = getMetaContent<MetaContent.JobTitle>("JobTitle")?.jobTitle?.takeIf { it.isNotBlank() },
        email = getMetaContent<MetaContent.Email>("Email")?.email?.takeIf { it.isNotBlank() },
        phone = getMetaContent<MetaContent.Phone>("Phone")?.phone?.takeIf { it.isNotBlank() },
        address = getMetaContent<MetaContent.Address>("Address")?.address?.takeIf { it.isNotBlank() },
        campaignID = campaignId,
        campaignName = campaignName ?: "",
    )
}
