package com.irdb.irkit.dto

import com.google.gson.annotations.SerializedName

data class MetaContentDto(
    @SerializedName("title")
    val title: String = ""
)
