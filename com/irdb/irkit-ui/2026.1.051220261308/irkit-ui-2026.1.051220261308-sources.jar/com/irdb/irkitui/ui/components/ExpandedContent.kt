package com.irdb.irkitui.ui.components

import android.annotation.SuppressLint
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.irdb.analytics.ViewSource
import com.irdb.irkit.ImageModel
import com.irdb.irkit.dto.MetaContent
import com.irdb.irkit.dto.ParsedMetaItem
import com.irdb.irkit.enums.CardTypes
import com.irdb.irkit.enums.MetaTypes
import com.irdb.irkit.extensions.extractValueFromParentheses
import com.irdb.irkit.getCardTypeEmum
import com.irdb.irkit.getLinks
import com.irdb.irkit.getMetaContent
import com.irdb.irkitui.IRKitUI
import com.irdb.irkitui.CameraMode
import com.irdb.irkitui.ui.baseComponents.AppWebView
import com.irdb.irkitui.ui.baseComponents.ContentDescription
import com.irdb.irkitui.ui.baseComponents.ContentTitle
import com.irdb.irkitui.ui.baseComponents.EmailLink
import com.irdb.irkitui.ui.baseComponents.PhoneLink
import com.irdb.irkitui.ui.components.FullSizeImage
import com.irdb.irkitui.ui.components.LoadingIndicatorView
import com.irdb.irkitui.ui.dimens.ExpandedContentDimens

// Generic analytics interface that consuming apps can implement
interface AnalyticsInterface {
    fun trackEvent(event: String, properties: Map<String, Any> = emptyMap())
}

@Composable
fun ExpandedContentMetaTableRow(label: String, data: ParsedMetaItem?) {
    data ?: return

    val value = data.content.toString().extractValueFromParentheses()

    if (value.isEmpty()) {
        return
    }

    val metaType = data.metaTypeEnum()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ExpandedContentDimens.metaRowVerticalPadding),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )

        when (metaType) {
            MetaTypes.Phone -> PhoneLink(value, modifier = Modifier.weight(1f))
            MetaTypes.Email -> EmailLink(value, modifier = Modifier.weight(1f))
            else -> Text(
                text = value,
                modifier = Modifier.weight(1f),
                color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun ExpandedContentMetaTableRowStrings(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = ExpandedContentDimens.metaRowVerticalPadding),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            modifier = Modifier.weight(1f),
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = value,
            modifier = Modifier.weight(1f),
            color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface
        )
    }
}

@Composable
fun ExpandedContentMetaTable(image: ImageModel) {
    val ignoredMetaTypes = setOf(
        MetaTypes.CardType,
        MetaTypes.EmbeddedVideo,
        MetaTypes.ProductLink,
        MetaTypes.Description,
        MetaTypes.Title,
        MetaTypes.Link,
        MetaTypes.Tags,
        MetaTypes.Year,
        MetaTypes.Medium,
        MetaTypes.Size
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(ExpandedContentDimens.metaTablePadding)
    ) {
        image.metaItems.filter { item ->
            !ignoredMetaTypes.contains(item.metaTypeEnum())
        }.sortedBy { item ->
            item.order
        }.forEach { item ->
            if (item.metaTypeEnum() != MetaTypes.Custom) {
                ExpandedContentMetaTableRow(
                    item.metaTypeEnum().title,
                    image.getMetaItemForType(item.metaType)
                )
            } else {
                val str = image.getMetaItemForType(item.metaType)
                val value = str?.content.toString().extractValueFromParentheses()

                // Extract the custom map from the value string
                val customMapString = value.substringAfter("custom=").trim('{', '}')

                // Split into key-value pairs
                customMapString.split(",").forEach { pair ->
                    val keyValue = pair.trim().split("=")
                    if (keyValue.size == 2) {
                        val key = keyValue[0].trim()
                        val customValue = keyValue[1].trim()
                        ExpandedContentMetaTableRowStrings(key, customValue)
                    }
                }
            }
        }
    }
}

@SuppressLint("ResourceAsColor")
@Composable
fun ExpandedContent(
    image: ImageModel,
    onClick: (MetaContent.Link) -> Unit,
    contentMetaLinksViewResourceProvider: com.irdb.irkit.enums.IRKitResourceProvider? = null,
    analyticsInterface: AnalyticsInterface? = null,
    webViewBackgroundColor: Color = Color.DarkGray,
    webViewPrimaryColor: Color = Color.Blue,
    webViewSecondaryColor: Color = Color.Gray,
    debugLogging: Boolean = false,
    onImageTap: (() -> Unit)? = null,
    viewSource: ViewSource? = null,
    viewType: String? = "expanded",
    cameraMode: CameraMode? = null
) {
    val isExpanded = true
    val links = image.getLinks()
    var isWebViewLoading by remember { mutableStateOf(true) }

    LaunchedEffect(Unit) {
        analyticsInterface?.trackEvent(
            event = "view_expanded",
            properties = mapOf(
                "image_id" to image.imageId,
                "view_source" to "live_scan"
            )
        )
    }

    // For WebView, don't use Column scroll (WebView handles its own scrolling)
    // For regular content, use Column scroll
    // When showSmartView is true (microsite/webview), show ONLY the web page, no image
    if (image.showSmartView) {
        links?.fullURLString?.let { url ->
            // WebView fills whatever space the parent Card provides
            Box(
                modifier = Modifier.fillMaxSize()
            ) {
                AppWebView(
                    url = url,
                    onLoadingChanged = { isLoading ->
                        isWebViewLoading = isLoading
                    },
                    backgroundColor = webViewBackgroundColor,
                    primaryColor = webViewPrimaryColor,
                    secondaryColor = webViewSecondaryColor,
                    debugLogging = debugLogging
                )

                if (isWebViewLoading) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(webViewBackgroundColor),
                        contentAlignment = Alignment.Center
                    ) {
                        LoadingIndicatorView()
                    }
                }
            }
        }
    } else {
        // When NOT a microsite/webview, show the image and card-type-specific content
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            // Always show the image at the top (only when not a microsite/webview)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(
                        horizontal = ExpandedContentDimens.horizontalPadding,
                        vertical = ExpandedContentDimens.verticalPadding
                    )
            ) {
                FullSizeImage(image, isExpanded, onImageTap)
            }

            // Card-type-specific content area
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = ExpandedContentDimens.cardHorizontalPadding)
            ) {
                Spacer(modifier = Modifier.height(ExpandedContentDimens.sectionSpacing))

                when (image.getCardTypeEmum()) {
                    CardTypes.Contact -> ExpandedContactCardContent(
                        image = image,
                        onClick = onClick,
                        viewSource = viewSource,
                        viewType = viewType,
                        cameraMode = cameraMode,
                        resourceProvider = contentMetaLinksViewResourceProvider
                    )
                    CardTypes.ArtCard -> ExpandedArtCardContent(
                        image = image,
                        onClick = onClick,
                        viewSource = viewSource,
                        viewType = viewType,
                        cameraMode = cameraMode,
                        resourceProvider = contentMetaLinksViewResourceProvider
                    )
                    else -> ExpandedDefaultContent(
                        image = image,
                        onClick = onClick,
                        viewSource = viewSource,
                        viewType = viewType,
                        cameraMode = cameraMode,
                        resourceProvider = contentMetaLinksViewResourceProvider
                    )
                }
            }
        }
    }
}

// --- Contact card: name heading, job/company subtitles, filtered meta table ---

private val contactGray = Color.White.copy(alpha = 0.45f)

private val contactExcludedMetaTypes = setOf(
    MetaTypes.FirstName,
    MetaTypes.LastName,
    MetaTypes.Company,
    MetaTypes.JobTitle,
    MetaTypes.CardType,
    MetaTypes.Description,
    MetaTypes.Title,
    MetaTypes.Link,
    MetaTypes.Tags,
    MetaTypes.Custom,
    MetaTypes.Year,
    MetaTypes.Medium,
    MetaTypes.Size,
    MetaTypes.ProductLink,
    MetaTypes.EmbeddedVideo,
    MetaTypes.ContactInfo
)

@Composable
private fun ExpandedContactCardContent(
    image: ImageModel,
    onClick: (MetaContent.Link) -> Unit,
    viewSource: ViewSource?,
    viewType: String?,
    cameraMode: CameraMode?,
    resourceProvider: com.irdb.irkit.enums.IRKitResourceProvider?
) {
    val firstName = image.getMetaContent<MetaContent.FirstName>("FirstName")?.firstName
    val lastName = image.getMetaContent<MetaContent.LastName>("LastName")?.lastName
    val fullName = listOfNotNull(
        firstName?.takeIf { it.isNotBlank() },
        lastName?.takeIf { it.isNotBlank() }
    ).joinToString(" ").takeIf { it.isNotBlank() }

    val jobTitle = image.getMetaContent<MetaContent.JobTitle>("JobTitle")?.jobTitle
        ?.takeIf { it.isNotBlank() }
    val company = image.getMetaContent<MetaContent.Company>("Company")?.company
        ?.takeIf { it.isNotBlank() }

    // Full name heading
    fullName?.let { name ->
        Text(
            text = name,
            color = Color.White,
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            lineHeight = 34.sp
        )
    }

    // Job title
    jobTitle?.let { title ->
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = title,
            color = contactGray,
            fontSize = 18.sp,
            fontWeight = FontWeight.Normal
        )
    }

    // Company
    company?.let { co ->
        Text(
            text = co,
            color = contactGray,
            fontSize = 18.sp,
            fontWeight = FontWeight.Normal
        )
    }

    // Description
    if (image.description.isNotBlank()) {
        Spacer(modifier = Modifier.height(12.dp))
        ContentDescription(image.description, maxLines = 99)
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Filtered meta table — excludes name/job/company fields
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(ExpandedContentDimens.metaTablePadding)
    ) {
        image.metaItems
            .filter { !contactExcludedMetaTypes.contains(it.metaTypeEnum()) }
            .sortedBy { it.order }
            .forEach { item ->
                val data = image.getMetaItemForType(item.metaType) ?: return@forEach
                val value = data.content.toString().extractValueFromParentheses()
                if (value.isEmpty()) return@forEach

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = item.metaTypeEnum().title,
                        modifier = Modifier.weight(0.35f),
                        color = contactGray,
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp
                    )
                    when (data.metaTypeEnum()) {
                        MetaTypes.Phone -> PhoneLink(value, modifier = Modifier.weight(0.65f), fontSize = 14.sp)
                        MetaTypes.Email -> EmailLink(value, modifier = Modifier.weight(0.65f), fontSize = 14.sp)
                        else -> Text(
                            text = value,
                            modifier = Modifier.weight(0.65f),
                            color = Color.White,
                            fontSize = 14.sp
                        )
                    }
                }
            }
    }
}

// --- Art card: artist name, title, year/medium/size, meta table ---

@Composable
private fun ExpandedArtCardContent(
    image: ImageModel,
    onClick: (MetaContent.Link) -> Unit,
    viewSource: ViewSource?,
    viewType: String?,
    cameraMode: CameraMode?,
    resourceProvider: com.irdb.irkit.enums.IRKitResourceProvider?
) {
    val artistName = image.getMetaContent<MetaContent.ArtistName>("ArtistName")?.artistName
        ?.takeIf { it.isNotBlank() }

    // Artist name
    artistName?.let { name ->
        Text(
            text = name,
            color = Color.White.copy(alpha = 0.7f),
            fontSize = 14.sp,
            fontWeight = FontWeight.Normal,
            maxLines = 1
        )
        Spacer(modifier = Modifier.height(4.dp))
    }

    // Title
    ContentTitle(image.getImageTitle())
    Spacer(modifier = Modifier.height(2.dp))

    // Year • Medium • Size
    val yearMediumSize = listOfNotNull(
        image.getMetaTypeValue(MetaTypes.Year).takeIf { it.isNotEmpty() },
        image.getMetaTypeValue(MetaTypes.Medium).takeIf { it.isNotEmpty() },
        image.getMetaTypeValue(MetaTypes.Size).takeIf { it.isNotEmpty() }
    ).joinToString(" • ")
    if (yearMediumSize.isNotEmpty()) {
        Text(
            text = yearMediumSize,
            color = Color.White.copy(alpha = 0.6f),
            fontSize = 14.sp,
            fontWeight = FontWeight.Normal,
            maxLines = 1
        )
        Spacer(modifier = Modifier.height(ExpandedContentDimens.sectionSpacing))
    }

    // Description
    ContentDescription(image.description, maxLines = 99)
    Spacer(modifier = Modifier.height(ExpandedContentDimens.sectionSpacing))

    // Metadata Table
    ExpandedContentMetaTable(image)
}

// --- Default content: owner name, title, links, description, meta table ---

@Composable
private fun ExpandedDefaultContent(
    image: ImageModel,
    onClick: (MetaContent.Link) -> Unit,
    viewSource: ViewSource?,
    viewType: String?,
    cameraMode: CameraMode?,
    resourceProvider: com.irdb.irkit.enums.IRKitResourceProvider?
) {
    // Owner name intentionally hidden — iOS does not show it in live scan cards
    // image.imageUser?.userName?.takeIf { it.isNotEmpty() }?.let { ownerName ->
    //     Text(
    //         text = ownerName,
    //         color = Color.White.copy(alpha = 0.7f),
    //         fontSize = 14.sp,
    //         fontWeight = FontWeight.Normal,
    //         maxLines = 1
    //     )
    //     Spacer(modifier = Modifier.height(4.dp))
    // }

    // Title
    ContentTitle(image.getImageTitle())
    Spacer(modifier = Modifier.height(2.dp))

    // Description
    ContentDescription(image.description, maxLines = 99)
    Spacer(modifier = Modifier.height(ExpandedContentDimens.sectionSpacing))

    // Metadata Table
    ExpandedContentMetaTable(image)
}

@Preview(showBackground = true)
@Composable
private fun ExpandedContentPreview() {
    // This preview would require mock implementations
    // Implementing a basic preview without deep dependencies
}
