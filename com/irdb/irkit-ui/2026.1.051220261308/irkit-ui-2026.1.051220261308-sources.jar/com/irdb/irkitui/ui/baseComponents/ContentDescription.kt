package com.irdb.irkitui.ui.baseComponents

import androidx.compose.foundation.clickable
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.sp
import com.irdb.irkitui.theme.IRKitUITheme

@Composable
fun ContentDescription(
    description: String,
    modifier: Modifier = Modifier,
    maxLines: Int = 2,
    fontSize: Int? = null,
    color: Color = Color(0xFFABABAB),
    maxChars: Int = 240
) {
    // Don't render empty descriptions
    if (description.isEmpty()) {
        return
    }

    // Expandable with "See more" / "See less" when text exceeds maxChars
    var expanded by remember { mutableStateOf(false) }
    val shouldShowExpand = description.length > maxChars
    val displayText = if (expanded || !shouldShowExpand) {
        description
    } else {
        description.take(maxChars) + "..."
    }

    // When showing " See more", don't use maxLines constraint - let text wrap naturally
    // The character limit already handles truncation, similar to ExpandableDescription
    // Only apply maxLines when text doesn't need expansion
    val effectiveMaxLines = if (expanded) {
        Int.MAX_VALUE
    } else if (shouldShowExpand) {
        null // No maxLines constraint - let it wrap naturally so " See more" is always visible
    } else {
        maxLines
    }

    Text(
        text = buildAnnotatedString {
            append(displayText)
            if (shouldShowExpand) {
                withStyle(
                    style = SpanStyle(
                        color = MaterialTheme.colorScheme.primary // Match ExpandableDescription styling
                    )
                ) {
                    append(if (expanded) " See less" else " See more")
                }
            }
        },
        style = androidx.compose.ui.text.TextStyle(
            fontSize = with(fontSize) {
                when {
                    fontSize != null -> fontSize.sp
                    maxLines == 2 -> 12.sp
                    else -> 18.sp
                }
            },
            fontWeight = androidx.compose.ui.text.font.FontWeight.Normal,
            color = color
        ),
        maxLines = effectiveMaxLines ?: Int.MAX_VALUE,
        overflow = TextOverflow.Clip,
        modifier = modifier.clickable(enabled = shouldShowExpand) {
            expanded = !expanded
        }
    )
}

@Preview(showBackground = true)
@Composable
fun ContentDescriptionPreview() {
    IRKitUITheme {
        ContentDescription(
            description = "This is a sample description for the image model that demonstrates how the ContentDescription composable renders text with proper styling and overflow handling.",
            maxLines = 2
        )
    }
}

@Preview(showBackground = true)
@Composable
fun ContentDescriptionExtendedPreview() {
    IRKitUITheme {
        ContentDescription(
            description = "This is a longer description that shows how the component handles multiple lines when maxLines is set to 5.",
            maxLines = 5
        )
    }
}
