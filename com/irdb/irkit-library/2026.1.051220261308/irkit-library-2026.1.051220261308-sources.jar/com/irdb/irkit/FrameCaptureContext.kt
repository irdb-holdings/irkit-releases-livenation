package com.irdb.irkit

/**
 * Snapshot of when-and-which-session a Live+ frame was captured in.
 *
 * The Live+ match pipeline is async: a frame leaves [IREngine.processFrame] /
 * [IREngine.makeFullImageQuery], gets uploaded to IREngine, and the match
 * response can land tens or hundreds of milliseconds later. If the user backs
 * out of the lens between capture and response, the resulting `scan` event
 * would otherwise emit AFTER `sessionStopped` on the same `sessionTrackingID`,
 * appearing in the timeline as a scan that happened after the session ended.
 *
 * The fix: at frame-capture time, snapshot
 *   - the wall-clock for `created`
 *   - the active `sessionTrackingID`
 * and carry this object through the async pipeline. The scan event is then
 * stamped with these captured values instead of "now" at emit time, so it
 * sorts correctly by `created` and is attributed to the correct session.
 *
 * Everything else on the scan event (imageID, bucketName, scanTrackingID,
 * match-data block) still comes from the match response and is filled in at
 * response time — only `created` and `sessionTrackingID` move earlier.
 *
 * Defensive nullability: if `sessionTrackingID` cannot be determined at
 * capture time (no active session), callers should pass `null` for the whole
 * context and the analytics layer falls back to emit-time stamping. The fix
 * never blocks or drops events.
 */
data class FrameCaptureContext(
    val capturedAtMs: Long,
    val sessionTrackingID: String,
)
