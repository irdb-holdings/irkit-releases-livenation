package com.irdb.irkit

import android.util.Log
import com.irdb.irkit.ImageModel.Companion.fromImageDto
import com.irdb.irkit.models.ClipInfoData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

suspend fun ImageModel.Companion.fetchImageFromAsset(clipInfoData: ClipInfoData, trackingId: String, bucketName: String): ImageModel? {

    return withContext(Dispatchers.IO) {
        try {
            val response = BackendService.getImageFromAsset(clipInfoData)
            fromImageDto(response, trackingId, bucketName, isFromManualCapture = false)
        }catch (e: Exception){
            Log.e("network", e.toString())
            null
        }
    }
}
